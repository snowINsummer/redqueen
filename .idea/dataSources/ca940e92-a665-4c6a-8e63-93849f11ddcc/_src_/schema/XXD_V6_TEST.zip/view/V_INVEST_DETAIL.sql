CREATE VIEW V_INVEST_DETAIL AS with dt as  --地推用户
(select a.userid, a.partnerid, b.partnername
  from (select pu.userid, pu.partnerid from xxd_partner_userinfo pu) a
 inner join (select p.partnerid, p.partnername, p.fpartnerid
               from xxd_partner p
              where p.type = 4) b
    on a.partnerid = b.partnerid
),
tz as --用户投资情况
(select t.userid, g.addtime rq, g.effectivemoney je, '散标' tzcp,
        decode(bow.type,1,'信用标',2,'推荐标',3,'净值标',4,'秒还标',5,'调剂标',6,'抵押标',7,'新新宝',8,'新生贷',9,'新商贷',10,'新房贷',11,'菁英贷',12,'信网贷',13,'票小宝',14,'新车贷',15,'分期贷',16,'新手标', 17, '七天大胜、月进斗金') type,
        bow.apr, bow.timelimit, nvl(g.terminalver, 'pc') terminalver, bow.borrowid
  from xxd_borrow_tenderdetail g, xxd_borrow_tender t, xxd_borrow bow
 where t.tenderid = g.tenderid
   and t.borrowid = bow.borrowid
   --and g.addtime >= to_date('2015-12-24', 'yyyy-mm-dd')
   --and g.addtime < to_date('2016-01-18', 'yyyy-mm-dd')
   and t.status in ('0', '1', '2')
   and t.isoptimize = '0'
union all
select p.userid, p.addtime, r.amount - r.funds, '债权转让', '',
       r.apr, p.terms, '', ''
  from xxd_trade_pack p, xxd_trade_request r
 where r.requestid = p.requestid
   and p.inmethod = 1
   --and p.addtime >= to_date('2015-12-24', 'yyyy-mm-dd')
   --and p.addtime < to_date('2016-01-18', 'yyyy-mm-dd')
union all
select o.userid, op.addtime, op.account, '新元宝',
       decode(os.closeterm, 3, '新元宝季季盈', 6, '新元宝双季盈', 12, '新元宝年年盈'),
       os.minapr, os.closeterm, decode(o.channel, 1, 'pc', 3, 'app', 4, 'webapp'), os.schemeid
  from xxd_optimize_userscheme o, xxd_optimize_userdetail op, xxd_optimize_scheme os
 where o.userschemeid = op.userschemeid
   and o.schemeid = os.schemeid
   and o.status in ('1', '6', '7')
   --and op.addtime >= to_date('2015-12-24', 'yyyy-mm-dd')
   --and op.addtime < to_date('2016-01-18', 'yyyy-mm-dd')
union all
select f.userid, f.createdate, decode(f.type, 1, f.tradenum, 2, -1 * f.tradenum), '日日盈',
       decode(f.type, 1, '申购', 2, '赎回'),
       case when instr(f.terminalver, 'pc') > 0 and f.type = 1 then 8 when f.type = 1 then 9 end,
       null, f.terminalver, ''
  from xxd_fund_usertrade f
 where f.initiator = 1
   --and f.createdate >= to_date('2015-12-24', 'yyyy-mm-dd')
   --and f.createdate  < to_date('2016-01-18', 'yyyy-mm-dd')
),
v as (
select distinct userid, servicenum
  from xxd_vip_appro
 where status = '1'
)
select tz.userid , case when substr(v.servicenum, 1, 2) = 'FD' then '是' else '否' end isFD, nvl2(dt.userid, '是', '否') isdt,
       tz.tzcp, tz.type, tz.je,
       tz.apr, tz.timelimit, tz.terminalver,
       tz.rq, tz.borrowid
from tz
left join dt
on tz.userid = dt.userid
left join v
on tz.userid = v.userid
where not exists
(
select *
from xxd_account_cashprohibit c
where tz.userid = c.userid
)
--and tz.rq >= to_date('2015-12-24', 'yyyy-mm-dd')
--and tz.rq  < to_date('2016-01-18', 'yyyy-mm-dd')
order by tz.rq, tz.userid
/
