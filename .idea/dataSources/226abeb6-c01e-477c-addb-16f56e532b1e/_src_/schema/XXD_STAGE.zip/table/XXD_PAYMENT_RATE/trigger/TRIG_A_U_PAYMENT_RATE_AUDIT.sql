CREATE TRIGGER TRIG_A_U_PAYMENT_RATE_AUDIT
AFTER UPDATE
  ON XXD_PAYMENT_RATE
FOR EACH ROW
  begin
  insert into xxd_payment_rate_audit
     (  auditid    ,  auditdate  ,  payrateid  ,  bankcode   ,  partnerid  ,
        paycode    ,  rate       ,  right_rate ,  right_conn ,  createdate ,
        createip   ,  creator    ,  lastmodify ,  modifydate )
  values
    (seq_payment_rate_audit.nextval,sysdate,  :old.payrateid  ,  :old.bankcode   ,  :old.partnerid  ,
     :old.paycode    ,  :old.rate       ,  :old.right_rate ,  :old.right_conn ,  :old.createdate ,
     :old.createip   ,  :old.creator    ,  :old.lastmodify ,  :old.modifydate );
end ;
/
