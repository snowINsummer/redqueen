CREATE TRIGGER TRIG_A_U_HPPROPERTY_AUDIT
AFTER UPDATE
  ON XXD_HOMEPAGE_PROPERTY
FOR EACH ROW
  begin
   insert into xxd_homepage_property_audit
    (auditid    ,  audittime  ,  id         ,  type       ,
     value      ,  modifytime ,  lastmodify)
  values
    (seq_homepage_property_audit.nextval,sysdate,:old.id         ,:old.type      ,
     :old.value      ,:old.modifytime      ,:old.lastmodify  );
end ;
/
