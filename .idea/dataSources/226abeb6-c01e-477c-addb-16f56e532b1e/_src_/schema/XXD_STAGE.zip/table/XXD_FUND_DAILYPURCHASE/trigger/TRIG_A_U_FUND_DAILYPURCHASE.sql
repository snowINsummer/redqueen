CREATE TRIGGER TRIG_A_U_FUND_DAILYPURCHASE
AFTER UPDATE
  ON XXD_FUND_DAILYPURCHASE
FOR EACH ROW
  begin
  insert into xxd_fund_dailypurchase_audit
(
auditid,  auditdate, purchaseid, userid,     fcode,
realdate, tradenum,  status,     createdate, creator,
createip,type
)
  values
(
seq_fund_dailypurchase_audit.nextval, sysdate,       :old.purchaseid, :old.userid,     :old.fcode,
:old.realdate,                        :old.tradenum, :old.status,     :old.createdate, :old.creator,
:old.createip,:old.type
);
end ;
/
