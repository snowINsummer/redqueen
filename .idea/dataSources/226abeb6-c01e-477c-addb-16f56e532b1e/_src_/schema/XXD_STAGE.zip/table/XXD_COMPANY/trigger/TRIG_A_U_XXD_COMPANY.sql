CREATE TRIGGER TRIG_A_U_XXD_COMPANY
AFTER UPDATE
  ON XXD_COMPANY
FOR EACH ROW
  begin
    insert into xxd_company_his(auditid,auditdate,id,property1,property2)
    values (seq_company_his.nextval,sysdate,:old.id,:old.property1,:old.property2);
end ;
/
