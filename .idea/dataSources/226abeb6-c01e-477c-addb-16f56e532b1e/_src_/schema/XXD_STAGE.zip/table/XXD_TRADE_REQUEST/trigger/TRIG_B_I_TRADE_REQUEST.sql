CREATE TRIGGER TRIG_B_I_TRADE_REQUEST
BEFORE INSERT
  ON XXD_TRADE_REQUEST
FOR EACH ROW
  begin
  if :new.funds >= 0 and :new.addtime <= to_date('20150820 18:00:00', 'YYYYMMDD HH24:MI:SS') and
     :new.addtime >= to_date('20150818 09:00:00', 'YYYYMMDD HH24:MI:SS') then
    :new.rate     := 0;
    :new.transfee := 0;
    :new.note     := '818活动3天免手续费';
  end if;
end;
/
