CREATE TRIGGER TRIG_A_U_PAYMENT_LIMIT_AUDIT
AFTER UPDATE
  ON XXD_PAYMENT_LIMIT
FOR EACH ROW
  begin
  insert into xxd_payment_limit_audit
     (  auditid    ,  auditdate  ,  limitid   ,    partnerid  ,  bankcode   ,
        limit      ,  daylimit   ,  monthlimit ,   createdate ,
        createip   ,  creator    ,  lastmodify ,  modifydate )
  values
    (seq_payment_limit_audit.nextval,sysdate, :old.limitid ,  :old.partnerid  ,  :old.bankcode   ,
     :old.limit    ,  :old.daylimit   ,  :old.monthlimit ,   :old.createdate ,
     :old.createip ,  :old.creator    ,  :old.lastmodify ,  :old.modifydate );
end ;
/
