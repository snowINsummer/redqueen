CREATE TRIGGER TRIG_A_U_XXD_ACCOUNT
AFTER UPDATE
  ON XXD_ACCOUNT
FOR EACH ROW
  begin
  insert into xxd_account_audit
    (  auditid                  ,  auditdate                ,  userid                   ,  pcode                    ,  usable                   ,
       frozen                   ,  collection               ,  repayment                ,  accounttotal             ,  innerinsum               ,
       inneroutsum              ,  rechargesum              ,  monthrecharge            ,  yearrecharge             ,  rechargefeesum           ,
       monthrechargefee         ,  yearrechargefee          ,  cashsum                  ,  monthcash                ,  yearcash                 ,
       cashfeesum               ,  monthcashfee             ,  yearcashfee              ,  tendersum                ,  monthtender              ,
       yeartender               ,  tenderfundsum            ,  monthtenderfund          ,  yeartenderfund           ,  borrowfundsum            ,
       monthborrowfund          ,  yearborrowfund           ,  investreturnsum          ,  monthinvestreturn        ,  yearinvestreturn         ,
       interestsum              ,  monthinterest            ,  yearinterest             ,  interestmanagingfeesum   ,  monthinterestmanagingfee ,
       yearinterestmanagingfee  ,  repaymentsum             ,  monthrepaymentsum        ,  yearrepaymentsum         ,  loansum                  ,
       monthloan                ,  yearloan                 ,  loanmanagingfeesum       ,  monthloanmanagingfee     ,  yearloanmanagingfee      ,
       latepayfinesumdebtor     ,  monthlatepayfinedebtor   ,  yearlatepayfinedebtor    ,  latepayfinesumcreditor   ,  monthlatepayfinecreditor ,
       yearlatepayfinecreditor  ,  consumesum               ,  monthconsume             ,  yearconsume              ,  xincoinexchangesum       ,
       monthxincoinexchange     ,  yearxincoinexchange      ,  rewardsum                ,  monthreward              ,  yearreward               ,
       otherfeesum              ,  monthotherfee            ,  yearotherfee             ,  tradeinsum               ,  monthintrade             ,
       yearintrade              ,  tradesum                 ,  monthtrade               ,  yeartrade                ,  othermulationneg         ,
       othermulationpos         ,  lastyearmonth            )
  values
    (seq_account_audit.nextval     ,sysdate                       ,:old.userid                   ,:old.pcode                    ,:old.usable                   ,
     :old.frozen                   ,:old.collection               ,:old.repayment                ,:old.accounttotal             ,:old.innerinsum               ,
     :old.inneroutsum              ,:old.rechargesum              ,:old.monthrecharge            ,:old.yearrecharge             ,:old.rechargefeesum           ,
     :old.monthrechargefee         ,:old.yearrechargefee          ,:old.cashsum                  ,:old.monthcash                ,:old.yearcash                 ,
     :old.cashfeesum               ,:old.monthcashfee             ,:old.yearcashfee              ,:old.tendersum                ,:old.monthtender              ,
     :old.yeartender               ,:old.tenderfundsum            ,:old.monthtenderfund          ,:old.yeartenderfund           ,:old.borrowfundsum            ,
     :old.monthborrowfund          ,:old.yearborrowfund           ,:old.investreturnsum          ,:old.monthinvestreturn        ,:old.yearinvestreturn         ,
     :old.interestsum              ,:old.monthinterest            ,:old.yearinterest             ,:old.interestmanagingfeesum   ,:old.monthinterestmanagingfee ,
     :old.yearinterestmanagingfee  ,:old.repaymentsum             ,:old.monthrepaymentsum        ,:old.yearrepaymentsum         ,:old.loansum                  ,
     :old.monthloan                ,:old.yearloan                 ,:old.loanmanagingfeesum       ,:old.monthloanmanagingfee     ,:old.yearloanmanagingfee      ,
     :old.latepayfinesumdebtor     ,:old.monthlatepayfinedebtor   ,:old.yearlatepayfinedebtor    ,:old.latepayfinesumcreditor   ,:old.monthlatepayfinecreditor ,
     :old.yearlatepayfinecreditor  ,:old.consumesum               ,:old.monthconsume             ,:old.yearconsume              ,:old.xincoinexchangesum       ,
     :old.monthxincoinexchange     ,:old.yearxincoinexchange      ,:old.rewardsum                ,:old.monthreward              ,:old.yearreward               ,
     :old.otherfeesum              ,:old.monthotherfee            ,:old.yearotherfee             ,:old.tradeinsum               ,:old.monthintrade             ,
     :old.yearintrade              ,:old.tradesum                 ,:old.monthtrade               ,:old.yeartrade                ,:old.othermulationneg         ,
     :old.othermulationpos         ,:old.lastyearmonth            );
end ;
/
