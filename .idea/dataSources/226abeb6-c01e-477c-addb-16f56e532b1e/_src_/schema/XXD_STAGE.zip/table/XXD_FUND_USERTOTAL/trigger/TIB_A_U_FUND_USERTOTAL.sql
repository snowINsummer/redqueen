CREATE TRIGGER TIB_A_U_FUND_USERTOTAL
AFTER UPDATE
  ON XXD_FUND_USERTOTAL
FOR EACH ROW
  begin
  insert into xxd_fund_usertotal_audit
    (auditid,
     auditdate,
     userid,
     fcode,
     account,
     accountamount,
     status,
     totalpurchase,
     totalredeem,
     totalearnings,
     createdate,
     createip,
     floatamount)

  values
    (seq_fund_usertotal_audit.nextval,
     sysdate,
     :old.userid,
     :old.fcode,
     :old.account,
     :old.accountamount,
     :old.status,
     :old.totalpurchase,
     :old.totalredeem,
     :old.totalearnings,
     :old.createdate,
     :old.createip,
     :old.floatamount);
end;
/
