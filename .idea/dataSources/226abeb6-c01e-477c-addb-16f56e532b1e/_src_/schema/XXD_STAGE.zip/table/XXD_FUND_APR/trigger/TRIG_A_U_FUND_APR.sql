CREATE TRIGGER TRIG_A_U_FUND_APR
AFTER UPDATE
  ON XXD_FUND_APR
FOR EACH ROW
  begin
  insert into xxd_fund_apr_audit
    (auditid,     auditdate,     id,     fcode,     startdate,
     enddate,     apr,     createdate,     creator,     createip,
     modifydate,     lastmodify,     modifyip,     floatapr)
  values
    (seq_fund_apr_audit.nextval,     sysdate,     :old.id,     :old.fcode,     :old.startdate,
     :old.enddate,     :old.apr,     :old.createdate,     :old.creator,     :old.createip,
     :old.modifydate,     :old.lastmodify,     :old.modifyip,     :old.floatapr);
end;
/
