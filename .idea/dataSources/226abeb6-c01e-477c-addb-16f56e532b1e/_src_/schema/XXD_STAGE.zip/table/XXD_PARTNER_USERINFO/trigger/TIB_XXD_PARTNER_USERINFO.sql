CREATE TRIGGER TIB_XXD_PARTNER_USERINFO
BEFORE INSERT
  ON XXD_PARTNER_USERINFO
FOR EACH ROW
  declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    --  column "partneruserid" uses sequence seq_partner_userinfor
    select seq_partner_userinfor.nextval into :new.partneruserid from dual;

--  errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
/
