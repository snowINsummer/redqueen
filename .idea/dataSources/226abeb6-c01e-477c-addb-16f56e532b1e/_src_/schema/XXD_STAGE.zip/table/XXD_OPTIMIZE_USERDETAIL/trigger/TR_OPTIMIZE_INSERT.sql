CREATE TRIGGER TR_OPTIMIZE_INSERT
AFTER INSERT
  ON XXD_OPTIMIZE_USERDETAIL
FOR EACH ROW
  declare
  v_userid number(22);
  v_servicenum varchar2(20);
  v_dept4 varchar2(100);
  v_dept3 varchar2(100);
  v_dept2 varchar2(100);
  v_dept1 varchar2(100);
  v_dept4_parentno varchar2(50);
  v_count number(10);
  v_employeeid number(28);
  v_terms number(10);
  v_dept4id number(22);
  v_expectedinterest NUMBER(16,2);
  v_plannedtime date;
begin
  select us.userid,s.closeterm,s.closeterm*:new.account*:new.apr/12/100,add_months(:new.addtime,s.closeterm) into v_userid,v_terms,v_expectedinterest,v_plannedtime from xxd_optimize_userscheme us,xxd_optimize_scheme s where us.schemeid = s.schemeid and us.userschemeid = :new.userschemeid;
  select count(1) into v_count from xxd_vip_appro where userid = v_userid and status =1 and rownum = 1;
  if (v_count > 0) then
    select servicenum into v_servicenum from xxd_vip_appro where userid = v_userid and status =1 and rownum = 1;
    select count(1) into v_count from xxd_employee where status in (1,3,4) and employeeid not in (1127,1084,522) and (jobnum = v_servicenum or servicenum = v_servicenum) and rownum = 1;
    if (v_count > 0) then
      select employeeid,departmentid into v_employeeid,v_dept4id from xxd_employee where status in (1,3,4) and employeeid not in (1127,1084,522) and (jobnum = v_servicenum or servicenum = v_servicenum) and rownum = 1;
    end if;
    select count(1) into v_count from xxd_department d where d.id = v_dept4id and rownum = 1;
    if (v_count > 0) then
           select d.depname,d.parentdepno into v_dept4,v_dept4_parentno from xxd_department d where d.id = v_dept4id and rownum = 1;
           select count(1) into v_count from xxd_department t3,xxd_department t2,xxd_department t1 
           where t3.parentdepno = t2.depno(+) and t2.parentdepno = t1.depno(+) and t3.depno = v_dept4_parentno and t3.status = 1 and rownum = 1;
             if (v_count > 0) then 
             select t3.depname,t2.depname,t1.depname into v_dept3,v_dept2,v_dept1 from xxd_department t3,xxd_department t2,xxd_department t1 
             where t3.parentdepno = t2.depno(+) and t2.parentdepno = t1.depno(+) and t3.depno = v_dept4_parentno and t3.status = 1 and rownum = 1;
             end if;
    end if;
  end if;
  insert into XXD_ORDER_RECORD
    (id, orderno, userid, ptype, addtime, addaccount,servicenum,dept4,dept3,dept2,dept1,employeeid,initiator,terms,dept4id,plannedinterest,plannedtime,apr,addip)
  values(SEQ_ORDER_RECORD.nextval,:new.userdetailid,v_userid,98,:new.addtime,:new.account,v_servicenum,v_dept4,v_dept3,v_dept2,v_dept1,v_employeeid,1,v_terms,v_dept4id,v_expectedinterest,v_plannedtime,:new.apr,:new.addip);
exception
   when others then
      begin
        insert into XXD_ORDER_ERRORS(id,orderno,addtime,ptype) values(SEQ_ORDER_ERRORS.nextval,:new.userdetailid,sysdate,98);
      end;
end tr_optimize_insert;
/
