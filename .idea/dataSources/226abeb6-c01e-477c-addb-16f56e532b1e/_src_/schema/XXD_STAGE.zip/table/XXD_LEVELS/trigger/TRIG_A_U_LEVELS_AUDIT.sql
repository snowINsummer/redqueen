CREATE TRIGGER TRIG_A_U_LEVELS_AUDIT
AFTER UPDATE
  ON XXD_LEVELS
FOR EACH ROW
  begin
   insert into xxd_levels_audit
    (auditid        ,  auditdate      ,  userid         ,  coins          ,
     creditlevel    ,  creditintegral ,  investlevel    ,  investintegral )
  values
    (seq_levels_audit.nextval,sysdate,:old.userid        ,:old.coins         ,
     :old.creditlevel   ,:old.creditintegral,:old.investlevel   ,:old.investintegral );
end  ;
/
