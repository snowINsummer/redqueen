CREATE TRIGGER TRIG_A_U_D_SYSCONFIG
AFTER UPDATE OR DELETE
  ON XXD_SYSCONFIG
FOR EACH ROW
  begin
  if updating then
  insert into xxd_sysconfig_his
    (  auditid    ,auditdate  ,audittype  ,syskey     ,syskeyvalue,
       notes      ,reserved1  ,reserved2  ,reserved3  ,
       addtime    ,adduserid  ,modifydate ,lastmodify  )
  values
    (  SEQ_SYSCONFIG_HIS.Nextval,sysdate ,'U'             ,:old.syskey     ,:old.syskeyvalue,
        :old.notes      ,:old.reserved1  ,:old.reserved2  ,:old.reserved3  ,
        :old.addtime    ,:old.adduserid  ,:old.modifydate ,:old.lastmodify );
   end if;
  if deleting then
  insert into xxd_sysconfig_his
    (  auditid    ,auditdate  ,audittype  ,syskey     ,syskeyvalue,
       notes      ,reserved1  ,reserved2  ,reserved3  ,
       addtime    ,adduserid  ,modifydate ,lastmodify  )
  values
    (  SEQ_SYSCONFIG_HIS.Nextval,sysdate ,'D'             ,:old.syskey     ,:old.syskeyvalue,
        :old.notes      ,:old.reserved1  ,:old.reserved2  ,:old.reserved3  ,
        :old.addtime    ,:old.adduserid  ,:old.modifydate ,:old.lastmodify );
   end if;
end ;
/
