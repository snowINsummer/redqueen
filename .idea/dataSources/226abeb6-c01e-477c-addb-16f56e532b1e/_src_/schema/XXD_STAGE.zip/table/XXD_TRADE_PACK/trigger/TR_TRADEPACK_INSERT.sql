CREATE TRIGGER TR_TRADEPACK_INSERT
AFTER INSERT
  ON XXD_TRADE_PACK
FOR EACH ROW
  declare
  v_type  varchar2(20);
  v_servicenum varchar2(20);
  v_dept4 varchar2(100);
  v_dept3 varchar2(100);
  v_dept2 varchar2(100);
  v_dept1 varchar2(100);
  v_dept4_parentno varchar2(50);
  v_count number(10);
  v_employeeid number(28);
  v_dept4id number(22);
  v_terms number;
  v_expectedinterest NUMBER(16,2);
  v_plannedtime date;
  v_apr number;
begin
  if (:new.inmethod=1) then
    select decode(b.type,17,decode(b.content,'sevengold',94,'monthgold',95),type),
    case when b.PERIODUNIT='DAY' then b.PERIOD/30 - (:new.addtime - b.successtime)/30 
         when b.PERIODUNIT='MONTH' then b.PERIOD - (:new.addtime - b.successtime)/30 
         when PERIODUNIT='SEASON' then b.PERIOD*3 - (:new.addtime - b.successtime)/30 
         when PERIODUNIT='YEAR' then b.PERIOD*12 - (:new.addtime - b.successtime)/30 
    else b.PERIOD end,
    btd.suminterest,
    case when b.PERIODUNIT='DAY' then nvl(b.successtime,b.addtime)+b.period
         when b.PERIODUNIT='MONTH' then decode(type,16,add_months(nvl(b.successtime,b.addtime)+1,b.period),add_months(nvl(b.successtime,b.addtime),b.period))
         when b.PERIODUNIT='SEASON' then add_months(nvl(b.successtime,b.addtime),b.period*3)
         when b.PERIODUNIT='YEAR' then add_months(nvl(b.successtime,b.addtime),b.period*12)
    end,b.apr into v_type,v_terms,v_expectedinterest,v_plannedtime,v_apr
    from xxd_borrow b,xxd_trade_request tr,xxd_borrow_tender bt 
    inner join (select sum(REPAYINTEREST) suminterest,tenderid from xxd_borrow_collection where repaytime > :new.addtime group by tenderid) btd on bt.tenderid=btd.tenderid 
    where tr.tenderid = bt.tenderid and bt.borrowid = b.borrowid and tr.requestid = :new.requestid and rownum = 1;
    if (v_type is null or v_terms is null) then
      insert into XXD_ORDER_ERRORS(id,orderno,addtime,ptype) values(SEQ_ORDER_ERRORS.nextval,:new.packid,sysdate,v_type);
    end if;

    select count(1) into v_count from xxd_vip_appro where userid = :new.userid and status =1 and rownum = 1;
    if (v_count > 0) then
      select servicenum into v_servicenum from xxd_vip_appro where userid = :new.userid and status =1 and rownum = 1;
      select count(1) into v_count from xxd_employee where status in (1,3,4) and employeeid not in (1127,1084,522) and (jobnum = v_servicenum or servicenum = v_servicenum) and rownum = 1;
      if (v_count > 0) then
        select employeeid,departmentid into v_employeeid,v_dept4id from xxd_employee where status in (1,3,4) and employeeid not in (1127,1084,522) and (jobnum = v_servicenum or servicenum = v_servicenum) and rownum = 1;
      end if;
      select count(1) into v_count from xxd_department d where d.id = v_dept4id and rownum = 1;    
      if (v_count > 0) then
             select d.depname,d.parentdepno into v_dept4,v_dept4_parentno from xxd_department d where d.id = v_dept4id and rownum = 1;
             select count(1) into v_count from xxd_department t3,xxd_department t2,xxd_department t1 
             where t3.parentdepno = t2.depno(+) and t2.parentdepno = t1.depno(+) and t3.depno = v_dept4_parentno and t3.status = 1 and rownum = 1;
               if (v_count > 0) then 
               select t3.depname,t2.depname,t1.depname into v_dept3,v_dept2,v_dept1 from xxd_department t3,xxd_department t2,xxd_department t1 
               where t3.parentdepno = t2.depno(+) and t2.parentdepno = t1.depno(+) and t3.depno = v_dept4_parentno and t3.status = 1 and rownum = 1;
               end if;
      end if;
    end if;
          insert into XXD_ORDER_RECORD
            (id, orderno, userid, ptype, addtime, addaccount,servicenum,dept4,dept3,dept2,dept1,employeeid,initiator,terms,dept4id,plannedinterest,plannedtime,apr,addip)
          values(SEQ_ORDER_RECORD.nextval,:new.packid,:new.userid,v_type,:new.addtime,:new.collectamount - :new.collectinterest,v_servicenum,v_dept4,v_dept3,v_dept2,v_dept1,v_employeeid,:new.inmethod,v_terms,v_dept4id,v_expectedinterest,v_plannedtime,v_apr,:new.addip);
  end if;          
exception
   when others then
      begin
        insert into XXD_ORDER_ERRORS(id,orderno,addtime,ptype) values(SEQ_ORDER_ERRORS.nextval,:new.packid,sysdate,v_type);
      end;
end tr_tradepack_insert;
/
