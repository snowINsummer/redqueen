CREATE TRIGGER TRIG_A_U_XXBAO_BORROW
AFTER UPDATE
  ON XXD_XXBAO_BORROW
FOR EACH ROW
  begin
if :new.lastmodfy<>0 then
insert into xxd_xxbao_borrow_audit
(auditid , audittime , xxbdeployid , cname , totalaccount ,
numcount , subaccount , apr , timelimit , lowesttender ,
mosttender , style , validdays , status , operator ,
addtime , deploytime , lastmodfy , modifytime , tendnum ,
tendsum , untendnum , untendsum , flownum , flowsum ,
notice_id1 , notice_id2 , notice_id3 , notice_id4 , notice_id5 ,
isstatistics , btype)
values(
seq_xxbao_borrow_audit.nextval,sysdate,:old.xxbdeployid ,:old.cname ,:old.totalaccount ,
:old.numcount ,:old.subaccount ,:old.apr ,:old.timelimit ,:old.lowesttender ,
:old.mosttender ,:old.style ,:old.validdays ,:old.status ,:old.operator ,
:old.addtime ,:old.deploytime ,:old.lastmodfy ,:old.modifytime ,:old.tendnum ,
:old.tendsum ,:old.untendnum ,:old.untendsum ,:old.flownum ,:old.flowsum ,
:old.notice_id1 ,:old.notice_id2 ,:old.notice_id3 ,:old.notice_id4 ,:old.notice_id5 ,
:old.isstatistics ,:old.btype
);
end if;
end;
/
