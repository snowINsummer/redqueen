CREATE TRIGGER TRIG_A_U_BORROW_AUTO_AUDIT
AFTER UPDATE
  ON XXD_BORROW_AUTO
FOR EACH ROW
  begin
  insert into xxd_borrow_auto_audit
    (  auditid      ,  auditdate,
       id           ,  userid       ,  tendertype  ,
       borrowtype   ,  moneymin     ,  moneymax     ,  awardflag    ,  minapr       ,
       maxapr       ,  mintimelimit ,  maxtimelimit ,  settime      ,  setip        ,
       status )
  values
    (seq_borrow_auto_audit.nextval,sysdate,
     :old.id           ,  :old.userid       ,  :old.tendertype   ,
     :old.borrowtype   ,  :old.moneymin     ,  :old.moneymax     ,  :old.awardflag    ,  :old.minapr       ,
     :old.maxapr       ,  :old.mintimelimit ,  :old.maxtimelimit ,  :old.settime      ,  :old.setip        ,
     :old.status        );
end ;
/
