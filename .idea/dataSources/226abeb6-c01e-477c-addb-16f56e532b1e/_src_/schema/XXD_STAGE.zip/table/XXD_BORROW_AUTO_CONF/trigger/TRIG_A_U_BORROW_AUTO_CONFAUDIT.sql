CREATE TRIGGER TRIG_A_U_BORROW_AUTO_CONFAUDIT
AFTER UPDATE
  ON XXD_BORROW_AUTO_CONF
FOR EACH ROW
  begin
  insert into xxd_borrow_auto_confaudit
    (auditid             ,auditdate           ,autoconfid          ,userid              ,timesswitch         ,
     times               ,dayamountswitch     ,dayamount           ,daydate             ,remamount           ,
     multipleswitch      ,multipleamount      ,addtime             ,addip               ,modifydate          ,
     modifyip
    )
  values
    (seq_borrow_auto_confaudit.nextval,sysdate,:old.autoconfid      , :old.userid          , :old.timesswitch     ,
     :old.times           , :old.dayamountswitch , :old.dayamount       , :old.daydate         , :old.remamount       ,
     :old.multipleswitch  , :old.multipleamount  , :old.addtime         , :old.addip           , :old.modifydate      ,
     :old.modifyip
 );
end  ;
/
