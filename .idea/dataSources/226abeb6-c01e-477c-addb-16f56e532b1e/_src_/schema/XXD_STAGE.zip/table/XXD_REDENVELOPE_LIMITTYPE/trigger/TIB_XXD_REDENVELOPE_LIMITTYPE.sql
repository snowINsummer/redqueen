CREATE TRIGGER TIB_XXD_REDENVELOPE_LIMITTYPE
BEFORE INSERT
  ON XXD_REDENVELOPE_LIMITTYPE
FOR EACH ROW
  declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    --  column "id" uses sequence seq_redenvelope_limittype
    select seq_redenvelope_limittype.nextval into :new.id from dual;

--  errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
/
