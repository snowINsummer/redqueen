CREATE VIEW V_TEMP_MARKETUSER_MOBILE AS select m.mobile,e.employeeid from xinxindb.marketuser_mobile m
left join xinxindb.xxd_user u on u.mobile = m.mobile
left join xinxindb.xxd_vip_appro v on v.userid = u.userid and v.status=1
left join xinxindb.xxd_employee e on (e.jobnum = v.servicenum or e.servicenum = v.servicenum)
/
