CREATE VIEW V_MARKETUSER_MOBILE AS select mobile,employeeid from xinxindb.v_temp_marketuser_mobile
/
