CREATE VIEW V_EUROCUP AS select tender.userid,u.username,tender.tenderSum,euro.championid,team.name as championName,euro.runnerid,team2.name as runnerName,euro.submittime
from
        (select scheme.userid,sum(detail.account) as tenderSum
        from XXD_OPTIMIZE_USERSCHEME scheme
        inner join XXD_OPTIMIZE_USERDETAIL detail on scheme.userschemeid=detail.userschemeid
        where detail.addtime
>=to_date((select syskeyvalue from xxd_sysconfig where syskey='EURO_CUP_START_TIME'), 'yyyy-mm-dd hh24:mi:ss')
        and detail.addtime<=to_date((select syskeyvalue from xxd_sysconfig where syskey='EURO_CUP_END_TIME'), 'yyyy-mm-dd hh24:mi:ss')
        group by scheme.userid) tender
inner join XXD_EUROCUP euro on tender.userid=euro.userid
inner join xxd_user u on u.userid=euro.userid
INNER JOIN XXD_EUROCUP_TEAM  TEAM ON TEAM.ID=EURO.CHAMPIONID
INNER JOIN XXD_EUROCUP_TEAM  TEAM2 ON TEAM2.ID=EURO.RUNNERID
/
