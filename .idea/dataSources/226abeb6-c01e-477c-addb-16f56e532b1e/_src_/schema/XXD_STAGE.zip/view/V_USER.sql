CREATE VIEW V_USER AS select userid,username,addtime from xxd_user where to_char(addtime, 'yyyy-mm-dd')>to_char(add_months(sysdate,-1), 'yyyy-mm-dd') order by addtime desc
/
