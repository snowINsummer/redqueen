CREATE VIEW V_XXD_ACCOUNT_RECHARGE AS select
rechargeid,
userid,
type,
partnerid,
bankcode,
orderno,
amount,
fee,
terminalver,
addtime,
rechargeip,
verifyuserid,
verifydate,
verifyip,
status,
isiocard,
rechargetype
from xxd_account_recharge
/
