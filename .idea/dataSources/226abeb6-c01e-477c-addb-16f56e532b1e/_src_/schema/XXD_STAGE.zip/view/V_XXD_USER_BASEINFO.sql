CREATE VIEW V_XXD_USER_BASEINFO AS select USERID,
       IDCARDTYPE,
       substr(IDCARDNO,0,3) IDCARDNO,
       (case (case
          when idcardtype = 1 then
           (case
             when length(idcardno) = 18 then
              mod(substr(idcardno, 17, 1), 2)
             when length(idcardno) = 15 then
              mod(substr(idcardno, 15, 1), 2)
              else to_number(gender)
           end)
          else
           to_number(gender)
        end)
         when 1 then
          '男'
         when 0 then
          '女'
         else
          '未知'
       end) as sex,
       (case
         when idcardtype = 1 then
          (case
            when length(idcardno) = 18 then
             substr(idcardno, 7, 4) || '-' || substr(idcardno, 11, 2) || '-' ||
             substr(idcardno, 13, 2)
            when length(idcardno) = 15 then
             '19'||substr(idcardno, 7, 2) || '-' || substr(idcardno, 9, 2) || '-' ||
             substr(idcardno, 11, 2)
            else to_char(birthday,'yyyy-mm-dd')
          end)
         else
          to_char(birthday,'yyyy-mm-dd')
       end) as birthday,
       NATIVEPLACE,
       ISVIP,
       ABILITY,
       COMPANYINDUSTRY,
       INTEREST,
       NOTE,
       CREATEDATE,
       CREATEIP,
       MODIFYDATE,
       OCCUPATION,
       USERTYPE
  from xinxindb.xxd_user_baseinfo
/
