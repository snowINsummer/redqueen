CREATE procedure DT_PROC_SCOTT is
cursor cur_OFFLINE_PERFORMANCE     is select a.*,b.id empid from XXDAI_OFFLINE_PERFORMANCE a left join xxdai_employee b on a.jobNUM=b.jobNUM   ;row_cur_OFFLINE_PERFORMANCE     cur_OFFLINE_PERFORMANCE%rowtype;
cursor cur_OFFLINE_PRODUCT         is select * from XXDAI_OFFLINE_PRODUCT        ;row_cur_OFFLINE_PRODUCT         cur_OFFLINE_PRODUCT%rowtype;
cursor cur_QUESTION_USER           is select * from XXDAI_QUESTION_USER          ;row_cur_QUESTION_USER           cur_QUESTION_USER%rowtype;
cursor cur_QUESTION_USERDETAIL     is select * from XXDAI_QUESTION_USERDETAIL    ;row_cur_QUESTION_USERDETAIL     cur_QUESTION_USERDETAIL%rowtype;
cursor cur_TENDER_COUPON           is select * from XXDAI_TENDER_COUPON          ;row_cur_TENDER_COUPON           cur_TENDER_COUPON%rowtype;
cursor cur_THRIDPARTY_CODE         is select * from XXDAI_THRIDPARTY_CODE        ;row_cur_THRIDPARTY_CODE         cur_THRIDPARTY_CODE%rowtype;
cursor cur_USER_ACTIVITY           is select * from XXDAI_USER_ACTIVITY          ;row_cur_USER_ACTIVITY           cur_USER_ACTIVITY%rowtype;
cursor cur_USER_APP_TENDER         is select * from XXDAI_USER_APP_TENDER        ;row_cur_USER_APP_TENDER         cur_USER_APP_TENDER%rowtype;
cursor cur_USER_CODEGROUP          is select * from XXDAI_USER_CODEGROUP         ;row_cur_USER_CODEGROUP          cur_USER_CODEGROUP%rowtype;
cursor cur_USER_COUPONCODE         is select * from XXDAI_USER_COUPONCODE        ;row_cur_USER_COUPONCODE         cur_USER_COUPONCODE%rowtype;
cursor cur_USER_INVIT_MAPPING      is select * from XXDAI_USER_INVITATION_MAPPING;row_cur_USER_INVIT_MAPPING      cur_USER_INVIT_MAPPING%rowtype;
cursor cur_USER_MOBILE_TENDER      is select * from XXDAI_USER_MOBILE_TENDER     ;row_cur_USER_MOBILE_TENDER      cur_USER_MOBILE_TENDER%rowtype;
cursor cur_USER_SHARE              is select * from XXDAI_USER_SHARE             ;row_cur_USER_SHARE              cur_USER_SHARE%rowtype;
cursor cur_USER_STATISTICS         is select * from XXDAI_USER_STATISTICS        ;row_cur_USER_STATISTICS         cur_USER_STATISTICS%rowtype;
cursor cur_USER_SUPERIOR_MAPPING   is select * from XXDAI_USER_SUPERIOR_MAPPING  ;row_cur_USER_SUPERIOR_MAPPING   cur_USER_SUPERIOR_MAPPING%rowtype;
cursor cur_USER_TRIGGER_MAPPING    is select * from XXDAI_USER_TRIGGER_MAPPING   ;row_cur_USER_TRIGGER_MAPPING    cur_USER_TRIGGER_MAPPING%rowtype;
cursor cur_WX_ACCESS_TOKEN         is select * from XXDAI_WX_ACCESS_TOKEN        ;row_cur_WX_ACCESS_TOKEN         cur_WX_ACCESS_TOKEN%rowtype;
cursor cur_WX_ACCOUNT              is select * from XXDAI_WX_ACCOUNT             ;row_cur_WX_ACCOUNT              cur_WX_ACCOUNT%rowtype;
cursor cur_WX_USER                 is select * from XXDAI_WX_USER                ;row_cur_WX_USER                 cur_WX_USER%rowtype;
cursor cur_WX_USER_BIND            is select * from XXDAI_WX_USER_BIND           ;row_cur_WX_USER_BIND            cur_WX_USER_BIND%rowtype;
--开始创建游标
cursor cur_xxd_achievemen_info_log is select
 t.ID,t.USERID,t.MONTHCFTMONEY,t.MONTHCREDITMONEY,t.CFTCOMMISSIONMONEY,t.CREDITCOMMISSIONMONEY,t.CREDITCOMMISSIONFREEZEMONEY,t.CREDITMENTIONMONEY,t.STATISTICSTIME,t.ADDTIME
 from xxdai_achievemen_info t;   --创建游标
  row_cur_xxd_achievemeninfolog cur_xxd_achievemen_info_log%rowtype;

  cursor cur_xxd_activity is select
 t.ID,t.ACTIVITYNAME,t.ACTIVITYCODE,t.STARTTIME,t.ENDTIME,t.ACTIVITYTYPE,t.PROMOTIONTYPE,t.STATUS,t.ONLINESTARTTIME,t.ONLINEENDTIME,t.OFFLINESTARTTIME,t.OFFLINEENDTIME,t.ADDTIME,t.ADDEMPID,t.MODIFYTIME,t.MODIFYEMPID,t.ACTIVITYLOGO,t.REWARDENDTIME
 from xxdai_activity t;   --创建游标
  row_cur_xxd_activity cur_xxd_activity%rowtype;

  cursor cur_xxd_activity_action is select
 t.ID,t.TRIGGERID,t.ACTIONNAME,t.REWARDTYPE,t.REWARDVALUE,t.REWARDUSERTYPE,t.ACTIONOPERATSTEP
 from xxdai_activity_action t;   --创建游标
  row_cur_xxd_activity_action cur_xxd_activity_action%rowtype;

  cursor cur_xxd_activity_info is select
 t.ID,t.ACTIVITYID,t.ACTIVITYEXPLAIN,t.ACTIVITYABSTRACT,t.PREVIOUSPAGE,t.NEXTPAGE,t.TITLESUCCEED,t.PREVIOUSPAGELINK,t.PREVIOUSPAGEGOTOLINK,t.NEXTPAGELINK,t.TITLEFAIL,t.ACTIVITYEXPLAINLINK
 from xxdai_activity_info t;   --创建游标
  row_cur_xxd_activity_info cur_xxd_activity_info%rowtype;

  cursor cur_xxd_activity_trigger is select
 t.ID,t.ACTIVITYID,t.TRIGGERNAME,t.LOGIC,t.STATUS,t.LOGICSQL
 from xxdai_activity_trigger t;   --创建游标
  row_cur_xxd_activity_trigger cur_xxd_activity_trigger%rowtype;

  cursor cur_xxd_activitymobile is select
 t.ID,t.MOBILE,t.ACTIVITYID,t.ADDTIME,t.BACK1,t.BACK2,t.BACK3,t.BACK4,t.BACK5
 from xxdai_activity_used_mobile t;   --创建游标
  row_cur_xxd_activitymobile cur_xxd_activitymobile%rowtype;

  cursor cur_xxd_activityprohibit is select
 t.ID,t.ACTIVITYID,t.USERID,t.ADDTIME
 from xxdai_activity_user_prohibit t;   --创建游标
  row_cur_xxd_activityprohibit cur_xxd_activityprohibit%rowtype;

 cursor cur_xxd_invitation_code is select
 t.ID,t.ACTIVITYID,t.INVITATIONCODE,t.ADDTIME
 from xxdai_invitation_code t;   --创建游标
  row_cur_xxd_invitation_code cur_xxd_invitation_code%rowtype;

cursor cur_xxd_invitation_item is select
 t.ID,t.ITEMCODE,t.ITEMNAME,t.ITEMVALUE
 from xxdai_invitation_item t;   --创建游标
  row_cur_xxd_invitation_item cur_xxd_invitation_item%rowtype;

cursor cur_xxd_invitation_type is select
 t.ID,t.TYPENAME,t.TYPECODE,t.PORDER
 from xxdai_invitation_type t;   --创建游标
  row_cur_xxd_invitation_type cur_xxd_invitation_type%rowtype;

 cursor cur_xxd_login_logs is select
 t.ID,t.USERID,t.OPERATETYPE,t.OPERATERESULT,t.OPERATETIME,t.OPERATEIP
 from xxdai_login_logs t;   --创建游标
  row_cur_xxd_login_logs cur_xxd_login_logs%rowtype;

  cursor cur_xxdai_app_promotion is select
 t.ID,t.CLICKDEVICENO,t.SIGNUPDEVICENO,t.CLICKDATE,t.SIGNUPDATE,t.CHANNEL,t.STATUS,t.SOURCE,t.OS,t.REMARK,t.BROWSER,t.CREATEDATE,t.CREATEIP,t.MODIFIEDDATE,t.APPID
 from xxdai_app_promotion t;   --创建游标
  row_cur_xxdai_app_promotion cur_xxdai_app_promotion%rowtype;

  cursor cur_xxd_achievemen_apply is select
 ID,TIME,USERID,ACHIEVEMENMONEY,TYPE,RECHARGEID,ACTIVITYID
 from xxdai_achievemen_apply;
  row_cur_xxd_achievemen_apply cur_xxd_achievemen_apply%rowtype;

cursor cur_xxd_achievemen_info is select
 t.ID,t.USERID,t.TIME,t.MONTHCFTMONEY,t.MONTHCREDITMONEY,t.CFTCOMMISSIONMONEY,t.CREDITCOMMISSIONMONEY,t.CREDITCOMMISSIONFREEZEMONEY,t.CREDITMENTIONMONEY,t.STATISTICSTIME,t.ADDTIME,t.MODIFYTIME
 from xxdai_achievemen_info t;   --创建游标
  row_cur_xxd_achievemen_info cur_xxd_achievemen_info%rowtype;

cursor cur_XXD_COUPON_COPYWRITING   is select
 ID,TITLE,PDESC
 from xxdai_coupon_copywriting;  --创建游标
  row_cur_XXD_COUPON_COPYWRITING   cur_XXD_COUPON_COPYWRITING%rowtype;

cursor cur_xxd_coupon_log is select
 ID,USERID,OPERATETIME,OPERATETYPE,BORROWID,CODEID
 from xxdai_coupon_log;   --创建游标
  row_cur_xxd_coupon_log cur_xxd_coupon_log%rowtype;

cursor cur_xxd_couponcodegroup is  select
 t.ID,t.CODEID,t.CODEVALUE,t.CODEGROUPID
  from xxdai_couponcodegroup t ;   --创建游标
 row_cur_xxd_couponcodegroup cur_xxd_couponcodegroup%rowtype;

cursor cur_xxd_coupongroup is  select
 t.ID,t.TYPE,t.ADDTIME,t.CODE
  from xxdai_coupongroup t ;  --创建游标
 row_cur_xxd_coupongroup cur_xxd_coupongroup%rowtype;

cursor cur_xxd_user_matchcreate is  select
 t.MATCHID,t.INACCOUNT,t.SUCCESSNUM,t.FAILNUM,t.ADDTIME,t.ADDIP,t.CREATOR,t.PARTNER
  from xxdai_createuser_match t ; --创建游标
 row_cur_xxd_user_matchcreate cur_xxd_user_matchcreate%rowtype;
 --创建游标
cursor cur_xxd_user_match_detai is  select
 t.DETAILID,t.MATCHID,t.PNAME,t.USERNAME,t.MOBILE,t.EMAIL,t.PASSWORD,t.PAYPASSWORD,t.STATUS,t.REASON
  from xxdai_createuser_match_detail t ;
 row_cur_xxd_user_match_detai cur_xxd_user_match_detai%rowtype;

 m_count  integer;--计数器
begin
-- XXD_OFFLINE_PERFORMANCE
EXECUTE IMMEDIATE 'truncate table XXD_OFFLINE_PERFORMANCE';
open cur_OFFLINE_PERFORMANCE          ;
loop
fetch cur_OFFLINE_PERFORMANCE          into row_cur_OFFLINE_PERFORMANCE          ;
exit when cur_OFFLINE_PERFORMANCE%notfound;
insert into XXD_OFFLINE_PERFORMANCE
       (ID,EMPLOYEEID,YEARMONTH,OFFLINESPERFORMANCE,
       OFFLINEYPERFORMANCE,ONLINESJZPERFORMANCE,ONLINEYJZPERFORMANCE,ONLINESPERFORMANCE,
       ONLINEYPERFORMANCE,ADDTIME)
VALUES(
       row_cur_OFFLINE_PERFORMANCE.ID                  ,to_number(row_cur_OFFLINE_PERFORMANCE.EMPID)   ,replace(row_cur_OFFLINE_PERFORMANCE.YEARMONTH,'-',''),row_cur_OFFLINE_PERFORMANCE.OFFLINESPERFORMANCE ,
       row_cur_OFFLINE_PERFORMANCE.OFFLINEYPERFORMANCE ,row_cur_OFFLINE_PERFORMANCE.ONLINESJZPERFORMANCE,row_cur_OFFLINE_PERFORMANCE.ONLINEYJZPERFORMANCE,row_cur_OFFLINE_PERFORMANCE.ONLINESPERFORMANCE  ,
       row_cur_OFFLINE_PERFORMANCE.ONLINEYPERFORMANCE  ,to_date(row_cur_OFFLINE_PERFORMANCE.ADDTIME,'yyyy-mm-dd hh24:mi:ss') );
end loop;
commit;
close cur_OFFLINE_PERFORMANCE;
-- XXD_OFFLINE_PRODUCT
EXECUTE IMMEDIATE 'truncate table XXD_OFFLINE_USERPRODUCT';
open cur_OFFLINE_PRODUCT          ;
loop
fetch cur_OFFLINE_PRODUCT          into row_cur_OFFLINE_PRODUCT          ;
exit when cur_OFFLINE_PRODUCT%notfound;
insert into XXD_OFFLINE_USERPRODUCT
       (ID,TYPE,USERID,MONEY,
       STARTTIME,ENDTIME,ACCOUNTDEBIT,BANKDEBIT,
       ACCOUNTRECEIVE,BANKRECEIVE,STATUS,CREATOR,
       ADDTIME,ADDIP,LASTMODFY,MODIFYTIME)
VALUES(
       row_cur_OFFLINE_PRODUCT.ID,row_cur_OFFLINE_PRODUCT.TYPE,row_cur_OFFLINE_PRODUCT.USERID,row_cur_OFFLINE_PRODUCT.MONEY,
       from_unixtime(row_cur_OFFLINE_PRODUCT.STARTTIME),from_unixtime(row_cur_OFFLINE_PRODUCT.ENDTIME),row_cur_OFFLINE_PRODUCT.ACCOUNTDEBIT,row_cur_OFFLINE_PRODUCT.BANKDEBIT,
       row_cur_OFFLINE_PRODUCT.ACCOUNTRECEIVE,row_cur_OFFLINE_PRODUCT.BANKRECEIVE,row_cur_OFFLINE_PRODUCT.STATUS,row_cur_OFFLINE_PRODUCT.USERID,
       from_unixtime(row_cur_OFFLINE_PRODUCT.ADDTIME),'127.0.0.1',row_cur_OFFLINE_PRODUCT.UPDATEUSERID,from_unixtime(row_cur_OFFLINE_PRODUCT.UPDATETIME));
end loop;
commit;
close cur_OFFLINE_PRODUCT;
-- XXD_QUESTION_USER
EXECUTE IMMEDIATE 'truncate table XXD_QUESTION_USER';
open cur_QUESTION_USER          ;
loop
fetch cur_QUESTION_USER          into row_cur_QUESTION_USER          ;
exit when cur_QUESTION_USER%notfound;
insert into XXD_QUESTION_USER
(ID,
USERID,
TERMID,
TOTALSCORE,
CONFIRMSTATUS,
ADDTIME,
ADDIP)
VALUES(
row_cur_QUESTION_USER.ID           ,
row_cur_QUESTION_USER.USERID       ,
decode(row_cur_QUESTION_USER.TERMID,1,20)       ,
row_cur_QUESTION_USER.TOTALSCORE   ,
row_cur_QUESTION_USER.CONFIRMSTATUS,
from_unixtime(row_cur_QUESTION_USER.ADDTIME)      ,
row_cur_QUESTION_USER.ADDIP        );
end loop;
commit;
close cur_QUESTION_USER;
-- XXD_QUESTION_USERDETAIL
EXECUTE IMMEDIATE 'truncate table XXD_QUESTION_USERDETAIL'    ;
open cur_QUESTION_USERDETAIL    ;
loop
fetch cur_QUESTION_USERDETAIL    into row_cur_QUESTION_USERDETAIL    ;
exit when cur_QUESTION_USERDETAIL%notfound;
insert into XXD_QUESTION_USERDETAIL(
ID,
QUID,
QUESTIONID,
QUESTIONDETAILID,
QUESTIONDESC,
ADDTIME,
ADDIP
)
VALUES(
row_cur_QUESTION_USERDETAIL.ID              ,
row_cur_QUESTION_USERDETAIL.QUID            ,
row_cur_QUESTION_USERDETAIL.QUESTIONID      ,
row_cur_QUESTION_USERDETAIL.QUESTIONDETAILID,
row_cur_QUESTION_USERDETAIL.QUESTIONDESC    ,
from_unixtime(row_cur_QUESTION_USERDETAIL.ADDTIME)         ,
row_cur_QUESTION_USERDETAIL.ADDIP
);
end loop;
commit;
close cur_QUESTION_USERDETAIL    ;
-- XXD_TENDER_COUPON
EXECUTE IMMEDIATE 'truncate table XXD_TENDER_COUPON'          ;
open cur_TENDER_COUPON          ;
loop
fetch cur_TENDER_COUPON          into row_cur_TENDER_COUPON          ;
exit when cur_TENDER_COUPON%notfound;
insert into XXD_TENDER_COUPON
(
ID      ,
TENDERID,
CODEID  ,
ADDTIME ,
USERID
)
VALUES(
row_cur_tender_COUPON.ID      ,
row_cur_tender_COUPON.TENDERID,
row_cur_tender_COUPON.CODEID  ,
from_unixtime(row_cur_tender_COUPON.ADDTIME),
row_cur_tender_COUPON.USERID
);
end loop;
commit;
close cur_TENDER_COUPON          ;
-- XXD_THRIDPARTY_CODE
EXECUTE IMMEDIATE 'truncate table XXD_THRIDPARTY_CODE'        ;
open cur_THRIDPARTY_CODE        ;
loop
fetch cur_THRIDPARTY_CODE        into row_cur_THRIDPARTY_CODE        ;
exit when cur_THRIDPARTY_CODE%notfound;
insert into XXD_THRIDPARTY_CODE
(
ID            ,
THRIDPARTYCODE,
PARTNER       ,
ADDTIME
)
VALUES(
row_cur_THRIDPARTY_CODE.ID            ,
row_cur_THRIDPARTY_CODE.THRIDPARTYCODE,
row_cur_THRIDPARTY_CODE.PARTNER       ,
to_date(row_cur_THRIDPARTY_CODE.ADDTIME,'yyyy-mm-dd hh24:mi:ss')
);
end loop;
commit;
close cur_THRIDPARTY_CODE        ;
-- XXDAI_USER_ACTIVITY
EXECUTE IMMEDIATE 'truncate table XXD_USER_ACTIVITY'          ;
open cur_USER_ACTIVITY          ;
loop
fetch cur_USER_ACTIVITY          into row_cur_USER_ACTIVITY          ;
exit when cur_USER_ACTIVITY%notfound;
insert into XXD_USER_ACTIVITY
(
ID        ,
USERID    ,
ACTIVITYID,
UUID      ,
JOINTIME  ,
SERVICENUM
)
VALUES(
row_cur_USER_ACTIVITY.ID        ,
row_cur_USER_ACTIVITY.USERID    ,
row_cur_USER_ACTIVITY.ACTIVITYID,
row_cur_USER_ACTIVITY.UUID      ,
from_unixtime(row_cur_USER_ACTIVITY.JOINTIME)  ,
row_cur_USER_ACTIVITY.SERVICENUM
);
end loop;
commit;
close cur_USER_ACTIVITY          ;
-- XXD_USER_APP_TENDER
EXECUTE IMMEDIATE 'truncate table XXD_USER_APP_TENDER'        ;
open cur_USER_APP_TENDER        ;
loop
fetch cur_USER_APP_TENDER        into row_cur_USER_APP_TENDER        ;
exit when cur_USER_APP_TENDER%notfound;
insert into XXD_USER_APP_TENDER
(
ID,
APPTENDERMONEY,
USERID
)
VALUES(
row_cur_USER_APP_TENDER.ID,
row_cur_USER_APP_TENDER.APPTENDERMONEY,
row_cur_USER_APP_TENDER.USERID
);
end loop;
commit;
close cur_USER_APP_TENDER        ;
-- XXD_USER_AUTOBORROW
-- XXD_USER_CODEGROUP
EXECUTE IMMEDIATE 'truncate table XXD_USER_CODEGROUP'         ;
open cur_USER_CODEGROUP         ;
loop
fetch cur_USER_CODEGROUP         into row_cur_USER_CODEGROUP         ;
exit when cur_USER_CODEGROUP%notfound;
insert into XXD_USER_CODEGROUP
(
ID         ,
USERID     ,
GROUPCODEID,
UPDATETIME ,
DESCRIPTION,
STATUS
)
VALUES
(
row_cur_USER_CODEGROUP.ID         ,
row_cur_USER_CODEGROUP.USERID     ,
row_cur_USER_CODEGROUP.GROUPCODEID,
from_unixtime(row_cur_USER_CODEGROUP.UPDATETIME) ,
row_cur_USER_CODEGROUP.PDESC      ,
row_cur_USER_CODEGROUP.STATUS
);
end loop;
commit;
close cur_USER_CODEGROUP         ;
-- XXD_USER_COUPONCODE
EXECUTE IMMEDIATE 'truncate table XXD_USER_COUPONCODE'        ;
open cur_USER_COUPONCODE        ;
loop
fetch cur_USER_COUPONCODE        into row_cur_USER_COUPONCODE        ;
exit when cur_USER_COUPONCODE%notfound;
insert into XXD_USER_COUPONCODE
(
ID,
USERID,
CODEID,
ADDTIME,
DESCRIPTION,
ACQUIRE,
STATUS
)
VALUES
(
row_cur_USER_COUPONCODE.ID         ,
row_cur_USER_COUPONCODE.USERID     ,
row_cur_USER_COUPONCODE.CODEID     ,
from_unixtime(row_cur_USER_COUPONCODE.ADDTIME)    ,
row_cur_USER_COUPONCODE.PDESC,
row_cur_USER_COUPONCODE.ACQUIRE    ,
row_cur_USER_COUPONCODE.STATUS
);
end loop;
commit;
close cur_USER_COUPONCODE        ;
-- XXD_USER_INVITATION_MAPPING
EXECUTE IMMEDIATE 'truncate table XXD_USER_INVITATION_MAPPING';
open cur_USER_INVIT_MAPPING;
loop
fetch cur_USER_INVIT_MAPPING into row_cur_USER_INVIT_MAPPING;
exit when cur_USER_INVIT_MAPPING%notfound;
insert into XXD_USER_INVITATION_MAPPING
(
ID,
USERID,
CODEID,
STATUS,
ADDTIME,
USETIME
)
VALUES(
row_cur_USER_INVIT_MAPPING.ID     ,
row_cur_USER_INVIT_MAPPING.USERID ,
row_cur_USER_INVIT_MAPPING.CODEID ,
row_cur_USER_INVIT_MAPPING.STATUS ,
from_unixtime(row_cur_USER_INVIT_MAPPING.ADDTIME),
from_unixtime(row_cur_USER_INVIT_MAPPING.USETIME)
);
end loop;
commit;
close cur_USER_INVIT_MAPPING;
-- XXD_USER_MOBILE_TENDER
EXECUTE IMMEDIATE 'truncate table XXD_USER_MOBILE_TENDER'     ;
open cur_USER_MOBILE_TENDER     ;
loop
fetch cur_USER_MOBILE_TENDER     into row_cur_USER_MOBILE_TENDER     ;
exit when cur_USER_MOBILE_TENDER%notfound;
insert into XXD_USER_MOBILE_TENDER
(
ID,
TENDERID,
TENDERMONEY,
ADDTIME
)
VALUES(
row_cur_USER_MOBILE_TENDER.ID         ,
row_cur_USER_MOBILE_TENDER.TENDERID   ,
row_cur_USER_MOBILE_TENDER.TENDERMONEY,
from_unixtime(row_cur_USER_MOBILE_TENDER.ADDTIME)
);
end loop;
commit;
close cur_USER_MOBILE_TENDER     ;
-- XXD_USER_SHARE
EXECUTE IMMEDIATE 'truncate table XXD_USER_SHARE'             ;
open cur_USER_SHARE             ;
loop
fetch cur_USER_SHARE             into row_cur_USER_SHARE             ;
exit when cur_USER_SHARE%notfound;
insert into XXD_USER_SHARE
(
ID,
CODEGROUPID,
SHARETIME,
CODEID,
USERID,
WXUSERID
)
VALUES(
row_cur_USER_SHARE.ID         ,
row_cur_USER_SHARE.CODEGROUPID,
from_unixtime(row_cur_USER_SHARE.SHARETIME)  ,
row_cur_USER_SHARE.CODEID     ,
row_cur_USER_SHARE.USERID     ,
row_cur_USER_SHARE.WXUSERID
);
end loop;
commit;
close cur_USER_SHARE             ;
-- XXD_USER_STATISTICS
EXECUTE IMMEDIATE 'truncate table XXD_USER_STATISTICS'        ;
open cur_USER_STATISTICS        ;
loop
fetch cur_USER_STATISTICS        into row_cur_USER_STATISTICS        ;
exit when cur_USER_STATISTICS%notfound;
insert into XXD_USER_STATISTICS
(
ID,
USERID,
SUCCBORROW,
LOSTBORROW,
OVERDUE,
WAITREPAY,
SUCCTEND,
LOSTTEND,
WAITCOLLECTION,
LOGINTIMES,
LASTTIME,
LASTIP
)
VALUES(
row_cur_USER_STATISTICS.ID            ,
row_cur_USER_STATISTICS.USERID        ,
row_cur_USER_STATISTICS.SUCCBORROW    ,
row_cur_USER_STATISTICS.LOSTBORROW    ,
row_cur_USER_STATISTICS.OVERDUE       ,
row_cur_USER_STATISTICS.WAITREPAY     ,
row_cur_USER_STATISTICS.SUCCTEND      ,
row_cur_USER_STATISTICS.LOSTTEND      ,
row_cur_USER_STATISTICS.WAITCOLLECTION,
row_cur_USER_STATISTICS.LOGINTIMES    ,
nvl(from_unixtime(row_cur_USER_STATISTICS.LASTTIME),sysdate)      ,
nvl(row_cur_USER_STATISTICS.LASTIP,'127.0.0.1')
);
end loop;
commit;
close cur_USER_STATISTICS        ;
-- XXD_USER_SUPERIOR_MAPPING
EXECUTE IMMEDIATE 'truncate table XXD_USER_SUPERIOR_MAPPING'  ;
open cur_USER_SUPERIOR_MAPPING  ;
loop
fetch cur_USER_SUPERIOR_MAPPING  into row_cur_USER_SUPERIOR_MAPPING  ;
exit when cur_USER_SUPERIOR_MAPPING%notfound;
insert into XXD_USER_SUPERIOR_MAPPING
(
ID,
USERID,
SUPERIORID,
ACTIVITYID,
ADDTIME
)
VALUES(
row_cur_USER_SUPERIOR_MAPPING.ID        ,
row_cur_USER_SUPERIOR_MAPPING.USERID    ,
row_cur_USER_SUPERIOR_MAPPING.SUPERIORID,
row_cur_USER_SUPERIOR_MAPPING.ACTIVITYID,
from_unixtime(row_cur_USER_SUPERIOR_MAPPING.ADDTIME)
);
end loop;
commit;
close cur_USER_SUPERIOR_MAPPING  ;
-- XXD_USER_TRIGGER_MAPPING
EXECUTE IMMEDIATE 'truncate table XXD_USER_TRIGGER_MAPPING'   ;
open cur_USER_TRIGGER_MAPPING   ;
loop
fetch cur_USER_TRIGGER_MAPPING   into row_cur_USER_TRIGGER_MAPPING   ;
exit when cur_USER_TRIGGER_MAPPING%notfound;
insert into XXD_USER_TRIGGER_MAPPING
(
ID,
USERID,
TRIGGERID,
STATUS,
ADDTIME,
MODIFYTIME
)
VALUES(
row_cur_USER_TRIGGER_MAPPING.ID       ,
row_cur_USER_TRIGGER_MAPPING.USERID   ,
row_cur_USER_TRIGGER_MAPPING.TRIGGERID,
row_cur_USER_TRIGGER_MAPPING.STATUS   ,
from_unixtime(row_cur_USER_TRIGGER_MAPPING.ADDTIME)  ,
from_unixtime(row_cur_USER_TRIGGER_MAPPING.MODIFYTIME)
);
end loop;
commit;
close cur_USER_TRIGGER_MAPPING   ;
-- XXD_WX_ACCESS_TOKEN
EXECUTE IMMEDIATE 'truncate table XXD_WX_ACCESS_TOKEN'        ;
open cur_WX_ACCESS_TOKEN        ;
loop
fetch cur_WX_ACCESS_TOKEN        into row_cur_WX_ACCESS_TOKEN        ;
exit when cur_WX_ACCESS_TOKEN%notfound;
insert into XXD_WX_ACCESS_TOKEN
(
ID,
WXACCOUNTID,
ACCESS_TOKEN,
UPDATETIME,
EXPIRES_IN
)
VALUES(
row_cur_WX_ACCESS_TOKEN.ID          ,
row_cur_WX_ACCESS_TOKEN.WXACCOUNTID ,
row_cur_WX_ACCESS_TOKEN.ACCESS_TOKEN,
from_unixtime(row_cur_WX_ACCESS_TOKEN.UPDATETIME)  ,
row_cur_WX_ACCESS_TOKEN.EXPIRES_IN
);
end loop;
commit;
close cur_WX_ACCESS_TOKEN        ;
-- XXD_WX_ACCOUNT
EXECUTE IMMEDIATE 'truncate table XXD_WX_ACCOUNT'             ;
open cur_WX_ACCOUNT             ;
loop
fetch cur_WX_ACCOUNT             into row_cur_WX_ACCOUNT             ;
exit when cur_WX_ACCOUNT%notfound;
insert into XXD_WX_ACCOUNT(
ID,
CODE,
Name,
type,
APPID,
APPSECRET
)
VALUES(
row_cur_WX_ACCOUNT.ID       ,
row_cur_WX_ACCOUNT.CODE     ,
row_cur_WX_ACCOUNT.NAME     ,
row_cur_WX_ACCOUNT.TYPE     ,
row_cur_WX_ACCOUNT.APPID    ,
row_cur_WX_ACCOUNT.APPSECRET
);
end loop;
commit;
close cur_WX_ACCOUNT             ;
-- XXD_WX_USER
EXECUTE IMMEDIATE 'truncate table XXD_WX_USER'                ;
open cur_WX_USER                ;
loop
fetch cur_WX_USER                into row_cur_WX_USER                ;
exit when cur_WX_USER%notfound;
insert into XXD_WX_USER
(
ID,
WXACCOUNTID,
OPENID,
NICKNAME,
SEX,
CITY,
COUNTRY,
PROVINCE,
LANGUAGE,
HEADIMGURL,
SUBSCRIBETIME,
UNIONID,
UNSUBSCRIBETIME,
STATUS
)
VALUES(
row_cur_WX_USER.ID             ,
row_cur_WX_USER.WXACCOUNTID    ,
row_cur_WX_USER.OPENID         ,
row_cur_WX_USER.NICKNAME       ,
row_cur_WX_USER.SEX            ,
row_cur_WX_USER.CITY           ,
row_cur_WX_USER.COUNTRY        ,
row_cur_WX_USER.PROVINCE       ,
row_cur_WX_USER.LANGUAGE       ,
row_cur_WX_USER.HEADIMGURL     ,
from_unixtime(row_cur_WX_USER.SUBSCRIBETIME)  ,
row_cur_WX_USER.UNIONID        ,
from_unixtime(row_cur_WX_USER.UNSUBSCRIBETIME),
row_cur_WX_USER.STATUS
);
end loop;
commit;
close cur_WX_USER                ;
-- XXD_WX_USER_BIND
EXECUTE IMMEDIATE 'truncate table XXD_WX_USER_BIND'                ;
open cur_WX_USER_BIND           ;
loop
fetch cur_WX_USER_BIND           into row_cur_WX_USER_BIND           ;
exit when cur_WX_USER_BIND%notfound;
insert into XXD_WX_USER_BIND
(
ID,
WXUSERID,
USERID,
BINDTIME
)
VALUES
(
row_cur_WX_USER_BIND.ID      ,
row_cur_WX_USER_BIND.WXUSERID,
row_cur_WX_USER_BIND.USERID  ,
from_unixtime(row_cur_WX_USER_BIND.BINDTIME)
);
end loop;
commit;
close cur_WX_USER_BIND           ;
----处理xxd_achievemen_info_log表
  delete from xxd_achievemen_info_log t;
  commit;
  open cur_xxd_achievemen_info_log;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_xxd_achievemen_info_log
      into row_cur_xxd_achievemeninfolog;
    exit when cur_xxd_achievemen_info_log%notfound;
    insert into  xxd_achievemen_info_log
    ( ID,                USERID,              MONTHCFTMONEY,           MONTHCREDITMONEY,
     CFTCOMMISSIONMONEY,  CREDITCOMMISSIONMONEY,  CREDITCOMMISSIONFREEZEMONEY,         CREDITMENTIONMONEY,
      STATISTICSTIME,       ADDTIME )
    values
      (row_cur_xxd_achievemeninfolog.ID,   row_cur_xxd_achievemeninfolog.USERID,   row_cur_xxd_achievemeninfolog.MONTHCFTMONEY,    row_cur_xxd_achievemeninfolog.MONTHCREDITMONEY,
      row_cur_xxd_achievemeninfolog.CFTCOMMISSIONMONEY,   row_cur_xxd_achievemeninfolog.CREDITCOMMISSIONMONEY,     row_cur_xxd_achievemeninfolog.CREDITCOMMISSIONFREEZEMONEY,  row_cur_xxd_achievemeninfolog.CREDITMENTIONMONEY,
      nvl(FROM_UNIXTIME(row_cur_xxd_achievemeninfolog.STATISTICSTIME),sysdate),     nvl(FROM_UNIXTIME(row_cur_xxd_achievemeninfolog.ADDTIME),sysdate) );
     if mod(m_count,2000)=0 then
     commit;
     end if;
  end loop;
  commit;
  close cur_xxd_achievemen_info_log;
  --处理xxd_activity表
  --delete from xxd_activity t;
  --commit;
  open cur_xxd_activity;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_xxd_activity
      into row_cur_xxd_activity;
    exit when cur_xxd_activity%notfound;
    insert into  xxd_activity
    (ID,      ACTIVITYNAME,   ACTIVITYCODE,   STARTTIME,
    ENDTIME,  ACTIVITYTYPE,  PROMOTIONTYPE,      STATUS,
    ONLINESTARTTIME,  ONLINEENDTIME,  OFFLINESTARTTIME,  OFFLINEENDTIME,
    ADDTIME,    ADDEMPID,        MODIFYTIME,      MODIFYEMPID,
    ACTIVITYLOGO,    REWARDENDTIME
    )
    values
      (row_cur_xxd_activity.ID,       row_cur_xxd_activity.ACTIVITYNAME,         row_cur_xxd_activity.ACTIVITYCODE,    nvl(FROM_UNIXTIME(row_cur_xxd_activity.STARTTIME),sysdate),
      nvl(FROM_UNIXTIME(row_cur_xxd_activity.ENDTIME),sysdate),   row_cur_xxd_activity.ACTIVITYTYPE,         row_cur_xxd_activity.PROMOTIONTYPE,    row_cur_xxd_activity.STATUS,
      nvl(FROM_UNIXTIME(row_cur_xxd_activity.ONLINESTARTTIME),sysdate),      nvl(FROM_UNIXTIME(row_cur_xxd_activity.ONLINEENDTIME),sysdate),     nvl(FROM_UNIXTIME(row_cur_xxd_activity.OFFLINESTARTTIME),sysdate),      nvl(FROM_UNIXTIME(row_cur_xxd_activity.OFFLINEENDTIME),sysdate),
      nvl(FROM_UNIXTIME(row_cur_xxd_activity.ADDTIME),sysdate),     row_cur_xxd_activity.ADDEMPID,      nvl(FROM_UNIXTIME(row_cur_xxd_activity.MODIFYTIME),sysdate),       row_cur_xxd_activity.MODIFYEMPID,
      row_cur_xxd_activity.ACTIVITYLOGO,   nvl(FROM_UNIXTIME(row_cur_xxd_activity.REWARDENDTIME),sysdate)
      );
     if mod(m_count,2000)=0 then
     commit;
     end if;
  end loop;
  commit;
  close cur_xxd_activity;
  ----处理xxd_activity_action表
   delete from xxd_activity_action t;
  commit;
  open cur_xxd_activity_action;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_xxd_activity_action
      into row_cur_xxd_activity_action;
    exit when cur_xxd_activity_action%notfound;
    insert into  xxd_activity_action
    (ID,TRIGGERID,ACTIONNAME,REWARDTYPE,
    REWARDVALUE,REWARDUSERTYPE,ACTIONOPERATSTEP
    )
    values
      (row_cur_xxd_activity_action.ID,row_cur_xxd_activity_action.TRIGGERID,row_cur_xxd_activity_action.ACTIONNAME,row_cur_xxd_activity_action.REWARDTYPE,
      row_cur_xxd_activity_action.REWARDVALUE,row_cur_xxd_activity_action.REWARDUSERTYPE,row_cur_xxd_activity_action.ACTIONOPERATSTEP  );
     if mod(m_count,2000)=0 then
     commit;
     end if;
  end loop;
  commit;
  close cur_xxd_activity_action;
  ----处理xxd_activity_info表
  delete from xxd_activity_info t;
  commit;
  open cur_xxd_activity_info;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_xxd_activity_info
      into row_cur_xxd_activity_info;
    exit when cur_xxd_activity_info%notfound;
    insert into  xxd_activity_info
    (ID,        ACTIVITYID,     ACTIVITYEXPLAIN,     ACTIVITYABSTRACT,
    PREVIOUSPAGE,   NEXTPAGE,     TITLESUCCEED,     PREVIOUSPAGELINK,
    PREVIOUSPAGEGOTOLINK,   NEXTPAGELINK,   TITLEFAIL,   ACTIVITYEXPLAINLINK
    )
    values
      (row_cur_xxd_activity_info.ID,row_cur_xxd_activity_info.ACTIVITYID,row_cur_xxd_activity_info.ACTIVITYEXPLAIN,row_cur_xxd_activity_info.ACTIVITYABSTRACT,
      row_cur_xxd_activity_info.PREVIOUSPAGE,row_cur_xxd_activity_info.NEXTPAGE,row_cur_xxd_activity_info.TITLESUCCEED,row_cur_xxd_activity_info.PREVIOUSPAGELINK,
      row_cur_xxd_activity_info.PREVIOUSPAGEGOTOLINK,row_cur_xxd_activity_info.NEXTPAGELINK,row_cur_xxd_activity_info.TITLEFAIL,row_cur_xxd_activity_info.ACTIVITYEXPLAINLINK );
     if mod(m_count,2000)=0 then
     commit;
     end if;
  end loop;
  commit;
  close cur_xxd_activity_info;
  ----处理xxd_activity_trigger表
  delete from xxd_activity_trigger t;
  commit;
  open cur_xxd_activity_trigger;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_xxd_activity_trigger
      into row_cur_xxd_activity_trigger;
    exit when cur_xxd_activity_trigger%notfound;
    insert into  xxd_activity_trigger
    ( ID,      ACTIVITYID,   TRIGGERNAME,  LOGIC,
    STATUS,    LOGICSQL
    )
    values
      (row_cur_xxd_activity_trigger.ID,   row_cur_xxd_activity_trigger.ACTIVITYID,   row_cur_xxd_activity_trigger.TRIGGERNAME,   row_cur_xxd_activity_trigger.LOGIC,
      row_cur_xxd_activity_trigger.STATUS,   row_cur_xxd_activity_trigger.LOGICSQL );
     if mod(m_count,2000)=0 then
     commit;
     end if;
  end loop;
  commit;
  close cur_xxd_activity_trigger;
  ----处理xxd_activity_used_mobile表
   delete from xxd_activity_used_mobile t;
  commit;
  open cur_xxd_activitymobile;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_xxd_activitymobile
      into row_cur_xxd_activitymobile;
    exit when cur_xxd_activitymobile%notfound;
    insert into  xxd_activity_used_mobile
    ( ID,    MOBILE,   ACTIVITYID,    ADDTIME,
    BACK1,    BACK2,     BACK3,      BACK4,
    BACK5
    )
    values
      (row_cur_xxd_activitymobile.ID,   row_cur_xxd_activitymobile.MOBILE,   row_cur_xxd_activitymobile.ACTIVITYID,   nvl(FROM_UNIXTIME(row_cur_xxd_activitymobile.ADDTIME),sysdate),
      row_cur_xxd_activitymobile.BACK1,     row_cur_xxd_activitymobile.BACK2,     row_cur_xxd_activitymobile.BACK3,   row_cur_xxd_activitymobile.BACK4,
      row_cur_xxd_activitymobile.BACK5  );
     if mod(m_count,2000)=0 then
     commit;
     end if;
  end loop;
  commit;
  close cur_xxd_activitymobile;
  ----处理xxd_activity_user_prohibit表
  delete from xxd_activity_user_prohibit t;
  commit;
  open cur_xxd_activityprohibit;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_xxd_activityprohibit
      into row_cur_xxd_activityprohibit;
    exit when cur_xxd_activityprohibit%notfound;
    insert into  xxd_activity_user_prohibit
    (ID,ACTIVITYID,USERID,ADDTIME
    )
    values
      (row_cur_xxd_activityprohibit.ID,row_cur_xxd_activityprohibit.ACTIVITYID,row_cur_xxd_activityprohibit.USERID,nvl(FROM_UNIXTIME(row_cur_xxd_activityprohibit.ADDTIME),sysdate)
      );
     if mod(m_count,2000)=0 then
     commit;
     end if;
  end loop;
  commit;
  close cur_xxd_activityprohibit;
  ----处理xxd_invitation_code表
  delete from xxd_invitation_code t;
  commit;
  open cur_xxd_invitation_code;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_xxd_invitation_code
      into row_cur_xxd_invitation_code;
    exit when cur_xxd_invitation_code%notfound;
    insert into  xxd_invitation_code
    ( ID,ACTIVITYID,INVITATIONCODE,ADDTIME
    )
    values
      (row_cur_xxd_invitation_code.ID,row_cur_xxd_invitation_code.ACTIVITYID,row_cur_xxd_invitation_code.INVITATIONCODE,nvl(FROM_UNIXTIME(row_cur_xxd_invitation_code.ADDTIME),sysdate) );
     if mod(m_count,2000)=0 then
     commit;
     end if;
  end loop;
  commit;
  close cur_xxd_invitation_code;
  ----处理xxd_invitation_item表
  delete from xxd_invitation_item t;
  commit;
  open cur_xxd_invitation_item;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_xxd_invitation_item
      into row_cur_xxd_invitation_item;
    exit when cur_xxd_invitation_item%notfound;
    insert into  xxd_invitation_item
    ( ID,ITEMCODE,ITEMNAME,ITEMVALUE
    )
    values
      (row_cur_xxd_invitation_item.ID,row_cur_xxd_invitation_item.ITEMCODE,row_cur_xxd_invitation_item.ITEMNAME,row_cur_xxd_invitation_item.ITEMVALUE
      );
     if mod(m_count,2000)=0 then
     commit;
     end if;
  end loop;
  commit;
  close cur_xxd_invitation_item;
  ----处理xxd_invitation_type表
  delete from xxd_invitation_type t;
  commit;
  open cur_xxd_invitation_type;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_xxd_invitation_type
      into row_cur_xxd_invitation_type;
    exit when cur_xxd_invitation_type%notfound;
    insert into  xxd_invitation_type
    ( ID,TYPENAME,TYPECODE,PORDER
    )
    values
      (row_cur_xxd_invitation_type.ID,row_cur_xxd_invitation_type.TYPENAME,row_cur_xxd_invitation_type.TYPECODE,row_cur_xxd_invitation_type.PORDER
      );
     if mod(m_count,2000)=0 then
     commit;
     end if;
  end loop;
  commit;
  close cur_xxd_invitation_type;
  ----处理xxd_login_logs表
   delete from xxd_user_logins t;
  commit;
  open cur_xxd_login_logs;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_xxd_login_logs
      into row_cur_xxd_login_logs;
    exit when cur_xxd_login_logs%notfound;
    insert into  xxd_user_logins
    (   recordid  ,  userid    ,  type      ,  logintime ,
        loginip   ,  issuccess ,  browser   ,  csystem
    )
    values
      (row_cur_xxd_login_logs.ID,     row_cur_xxd_login_logs.USERID,  1,from_unixtime(row_cur_xxd_login_logs.operatetime),
       nvl(row_cur_xxd_login_logs.operateip,'127.0.0.1'),decode(row_cur_xxd_login_logs.operateresult,1,1,2,0,0),'V5迁移','V5迁移'
      );
     if mod(m_count,2000)=0 then
     commit;
     end if;
  end loop;
  commit;
  close cur_xxd_login_logs;
  ----处理xxd_app_promotion表
   delete from xxd_app_promotion t;
  commit;
  open cur_xxdai_app_promotion;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_xxdai_app_promotion
      into row_cur_xxdai_app_promotion;
    exit when cur_xxdai_app_promotion%notfound;
    insert into  xxd_app_promotion
    ( ID,      CLICKDEVICENO,     SIGNUPDEVICENO,     CLICKDATE,
    SIGNUPDATE,      CHANNEL,            STATUS,        SOURCE,
            OS,       REMARK,            BROWSER,       CREATEDATE,
     CREATEIP,    MODIFIEDDATE,          APPID
    )
    values
      (row_cur_xxdai_app_promotion.ID,      row_cur_xxdai_app_promotion.CLICKDEVICENO,    row_cur_xxdai_app_promotion.SIGNUPDEVICENO,   nvl(FROM_UNIXTIME(row_cur_xxdai_app_promotion.CLICKDATE),sysdate),
      nvl(FROM_UNIXTIME(row_cur_xxdai_app_promotion.SIGNUPDATE),sysdate),     row_cur_xxdai_app_promotion.CHANNEL,            row_cur_xxdai_app_promotion.STATUS,    row_cur_xxdai_app_promotion.SOURCE,
      row_cur_xxdai_app_promotion.OS,              row_cur_xxdai_app_promotion.REMARK,            row_cur_xxdai_app_promotion.BROWSER,    nvl(FROM_UNIXTIME(row_cur_xxdai_app_promotion.CREATEDATE),sysdate),
      row_cur_xxdai_app_promotion.CREATEIP,    nvl(FROM_UNIXTIME(row_cur_xxdai_app_promotion.MODIFIEDDATE),sysdate),           nvl(row_cur_xxdai_app_promotion.APPID,0)
      );
     if mod(m_count,2000)=0 then
     commit;
     end if;
  end loop;
  commit;
  close cur_xxdai_app_promotion;
  ----处理xxd_achievemen_apply表
   delete from xxd_achievemen_apply t;
  commit;
  open cur_xxd_achievemen_apply;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_xxd_achievemen_apply
      into row_cur_xxd_achievemen_apply;
    exit when cur_xxd_achievemen_apply%notfound;
    insert into  xxd_achievemen_apply
    ( ID,      TIME,     USERID,   ACHIEVEMENMONEY,     TYPE,
    RECHARGEID,    ACTIVITYID)
    values
      (row_cur_xxd_achievemen_apply.ID,    row_cur_xxd_achievemen_apply.TIME,    row_cur_xxd_achievemen_apply.USERID,      row_cur_xxd_achievemen_apply.ACHIEVEMENMONEY,     row_cur_xxd_achievemen_apply.TYPE,
      row_cur_xxd_achievemen_apply.RECHARGEID,   row_cur_xxd_achievemen_apply.ACTIVITYID
      );
     if mod(m_count,2000)=0 then
     commit;
     end if;
  end loop;
  commit;
  close cur_xxd_achievemen_apply;
  ----处理xxd_achievemen_info表
  delete from xxd_achievemen_info t;
  commit;
  open cur_xxd_achievemen_info;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_xxd_achievemen_info
      into row_cur_xxd_achievemen_info;
    exit when cur_xxd_achievemen_info%notfound;
    insert into  xxd_achievemen_info
    ( ID,                     USERID,          TIME,         MONTHCFTMONEY,
    MONTHCREDITMONEY,    CFTCOMMISSIONMONEY,     CREDITCOMMISSIONMONEY,   CREDITCOMMISSIONFREEZEMONEY,
     CREDITMENTIONMONEY,       STATISTICSTIME,   ADDTIME,          MODIFYTIME
    )
    values
      (row_cur_xxd_achievemen_info.ID,                   row_cur_xxd_achievemen_info.USERID,               nvl(FROM_UNIXTIME(row_cur_xxd_achievemen_info.TIME),sysdate),        row_cur_xxd_achievemen_info.MONTHCFTMONEY,
       row_cur_xxd_achievemen_info.MONTHCREDITMONEY,     row_cur_xxd_achievemen_info.CFTCOMMISSIONMONEY,     row_cur_xxd_achievemen_info.CREDITCOMMISSIONMONEY,     row_cur_xxd_achievemen_info.CREDITCOMMISSIONFREEZEMONEY,
       row_cur_xxd_achievemen_info.CREDITMENTIONMONEY,       nvl(FROM_UNIXTIME(row_cur_xxd_achievemen_info.STATISTICSTIME),sysdate),     nvl(FROM_UNIXTIME(row_cur_xxd_achievemen_info.ADDTIME),sysdate),     nvl(FROM_UNIXTIME(row_cur_xxd_achievemen_info.MODIFYTIME),sysdate)
      );
     if mod(m_count,2000)=0 then
     commit;
     end if;
  end loop;
  commit;
  close cur_xxd_achievemen_info;
 ----处理XXD_COUPON_COPYWRITING表
  --- delete from XXD_COUPON_COPYWRITING   t;
 --- commit;
  open cur_XXD_COUPON_COPYWRITING;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_XXD_COUPON_COPYWRITING
      into row_cur_XXD_COUPON_COPYWRITING;
    exit when cur_XXD_COUPON_COPYWRITING%notfound;
    insert into  XXD_COUPON_COPYWRITING
    ( ID,TITLE,DESCRIPTION)
    values
      (row_cur_XXD_COUPON_COPYWRITING.ID,row_cur_XXD_COUPON_COPYWRITING.TITLE,row_cur_XXD_COUPON_COPYWRITING.pdesc
      );
     if mod(m_count,2000)=0 then
     commit;
     end if;
  end loop;
  commit;
  close cur_XXD_COUPON_COPYWRITING;
----处理XXD_coupon_log表
delete from xxd_coupon_log t;
  commit;
  open cur_xxd_coupon_log;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_xxd_coupon_log
      into row_cur_xxd_coupon_log;
    exit when cur_xxd_coupon_log%notfound;
    insert into  xxd_coupon_log
    (ID,   USERID,   OPERATETIME,   OPERATETYPE,
    BUSIID,    CODEID)
    values
      (row_cur_xxd_coupon_log.ID,  row_cur_xxd_coupon_log.USERID,   nvl(FROM_UNIXTIME(row_cur_xxd_coupon_log.OPERATETIME),sysdate),   row_cur_xxd_coupon_log.OPERATETYPE,
      row_cur_xxd_coupon_log.BORROWID,  row_cur_xxd_coupon_log.CODEID
      );
     if mod(m_count,2000)=0 then
     commit;
     end if;
  end loop;
  commit;
  close cur_xxd_coupon_log;
 ----处理xxd_couponcodegroup表
 delete from xxd_couponcodegroup t;
  commit;
  open cur_xxd_couponcodegroup;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_xxd_couponcodegroup
      into row_cur_xxd_couponcodegroup;
    exit when cur_xxd_couponcodegroup%notfound;
    insert into  xxd_couponcodegroup
    (ID,CODEID,CODEVALUE,CODEGROUPID)
    values
      (row_cur_xxd_couponcodegroup.ID,row_cur_xxd_couponcodegroup.CODEID,row_cur_xxd_couponcodegroup.CODEVALUE,row_cur_xxd_couponcodegroup.CODEGROUPID);
     if mod(m_count,2000)=0 then
     commit;
     end if;
  end loop;
  commit;
  close cur_xxd_couponcodegroup;
 ----处理xxd_couponcodegroup表
  delete from xxd_coupongroup t;
  commit;
  open cur_xxd_coupongroup;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_xxd_coupongroup
      into row_cur_xxd_coupongroup;
    exit when cur_xxd_coupongroup%notfound;
    insert into  xxd_coupongroup
    (ID,TYPE,ADDTIME,CODE)
    values
      ( row_cur_xxd_coupongroup.ID,row_cur_xxd_coupongroup.TYPE,nvl(FROM_UNIXTIME(row_cur_xxd_coupongroup.ADDTIME),sysdate),row_cur_xxd_coupongroup.CODE);
     if mod(m_count,2000)=0 then
     commit;
     end if;
  end loop;
  commit;
  close cur_xxd_coupongroup;
 ----处理xxd_user_matchcreate表
 delete from xxd_user_matchcreate  t;
  commit;
  open cur_xxd_user_matchcreate;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_xxd_user_matchcreate
      into row_cur_xxd_user_matchcreate;
    exit when cur_xxd_user_matchcreate%notfound;
    insert into  xxd_user_matchcreate
    (MATCHID,   INCOUNT,   SUCCESSCOUNT,   FAILCOUNT,
    ADDTIME,      ADDIP,      PARTNERID)
    values
      (row_cur_xxd_user_matchcreate.MATCHID,  row_cur_xxd_user_matchcreate.INACCOUNT,   row_cur_xxd_user_matchcreate.SUCCESSNUM,  row_cur_xxd_user_matchcreate.FAILNUM,
      nvl(FROM_UNIXTIME(row_cur_xxd_user_matchcreate.ADDTIME),sysdate),   row_cur_xxd_user_matchcreate.ADDIP,        nvl(row_cur_xxd_user_matchcreate.PARTNER,' ')
      );
     if mod(m_count,2000)=0 then
     commit;
     end if;
  end loop;
  commit;
  close cur_xxd_user_matchcreate;
  --处理xxd_user_matchcreatedetail表
  delete from xxd_user_matchcreatedetail t;
  commit;
  update xxdai_createuser_match_detail set pname=substr(pname,0,10);
  open cur_xxd_user_match_detai;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_xxd_user_match_detai
      into row_cur_xxd_user_match_detai;
    exit when cur_xxd_user_match_detai%notfound;
    insert into  xxd_user_matchcreatedetail
    (DETAILID,    MATCHID,   PNAME,     USERNAME,
     MOBILE,      EMAIL,     PASSWORD,  PAYPASSWORD,
     STATUS,      FAILREASON)
    values
      (row_cur_xxd_user_match_detai.DETAILID,   row_cur_xxd_user_match_detai.MATCHID,   nvl(row_cur_xxd_user_match_detai.PNAME,' '),     nvl(row_cur_xxd_user_match_detai.USERNAME,' '),
       row_cur_xxd_user_match_detai.MOBILE,     row_cur_xxd_user_match_detai.EMAIL,     nvl(row_cur_xxd_user_match_detai.PASSWORD,' '),  nvl(row_cur_xxd_user_match_detai.PAYPASSWORD,' '),
       row_cur_xxd_user_match_detai.STATUS,     row_cur_xxd_user_match_detai.REASON);
     if mod(m_count,2000)=0 then
     commit;
     end if;
  end loop;
  commit;
  close cur_xxd_user_match_detai;

end DT_PROC_SCOTT;



/
