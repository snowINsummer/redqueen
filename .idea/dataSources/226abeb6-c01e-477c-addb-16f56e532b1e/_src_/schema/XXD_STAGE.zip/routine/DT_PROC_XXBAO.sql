CREATE procedure DT_PROC_XXBAO is
CURSOR cur_xxbao_notice IS SELECT * from xxdai_xxbao_notice;
row_cur_xxbao_notice cur_xxbao_notice%rowtype;

CURSOR cur_xxbao_borrow IS SELECT * from xxdai_XXBAO_BORROW;
row_cur_xxbao_borrow cur_xxbao_borrow%rowtype;

CURSOR cur_xxbao_borrow_audit IS SELECT * from xxdai_xxbao_borrow_audit;
row_cur_xxbao_borrow_audit cur_xxbao_borrow_audit%rowtype;

CURSOR cur_borrow_xxbmapping IS
SELECT a.id,a.borrowid,a.xxbaodeployid,b.addtime from xxdai_maping_xxbao_borrow a
left join xxdai_borrow b on a.borrowid=b.id;
row_cur_borrow_xxbmapping cur_borrow_xxbmapping%rowtype;
m_count INTEGER ;

begin
-- xxbao_notice
EXECUTE IMMEDIATE 'truncate table xxd_xxbao_notice';

  OPEN cur_xxbao_notice;
  m_count:= 0;
  loop
  m_count:= m_count+1;
FETCH cur_xxbao_notice INTO row_cur_xxbao_notice;
exit when cur_xxbao_notice%notfound;
INSERT INTO xxd_xxbao_notice (
 id,  type,  addtime,
 deploytime, notes ,status

)
VALUES
  (
  row_cur_xxbao_notice.id,          row_cur_xxbao_notice.type,   from_unixtime(row_cur_xxbao_notice.addtime),
  from_unixtime(row_cur_xxbao_notice.deploytime),  row_cur_xxbao_notice.notes,  row_cur_xxbao_notice.status
);
 end loop;
    commit;
  close cur_xxbao_notice;
-- xxbao_borrow
EXECUTE IMMEDIATE 'truncate table xxd_XXBAO_BORROW';

 OPEN cur_xxbao_borrow;
  m_count:= 0;
  loop
  m_count:= m_count+1;
FETCH cur_xxbao_borrow INTO row_cur_xxbao_borrow;
exit when cur_xxbao_borrow%notfound;
INSERT INTO xxd_XXBAO_BORROW (
 XXBDEPLOYID, Cname, Totalaccount, Numcount,
 Subaccount, Apr, Timelimit, Lowesttender,
 Mosttender,  Style,  Validdays,  Status,
 Operator,  Addtime,  Deploytime,   Lastmodfy,
 Modifytime,  Tendnum,  Tendsum,  Untendnum,
 Untendsum,  Flownum,  Flowsum,  Notice_Id1,
 Notice_Id2,  Notice_Id3,  Notice_Id4,  Notice_Id5,
 Isstatistics
)
VALUES
  (
row_cur_xxbao_borrow.id,  row_cur_xxbao_borrow.cname,  row_cur_xxbao_borrow.account,  row_cur_xxbao_borrow.numcount,
row_cur_xxbao_borrow.subaccount,  row_cur_xxbao_borrow.apr,  row_cur_xxbao_borrow.timeLimit,  row_cur_xxbao_borrow.lowesttender,
row_cur_xxbao_borrow.mosttender,  row_cur_xxbao_borrow.style,  from_unixtime(row_cur_xxbao_borrow.endtime)-to_date('19700101 08:00','yyyymmdd hh24:mi'),  row_cur_xxbao_borrow.status,
row_cur_xxbao_borrow.operator,  from_unixtime(row_cur_xxbao_borrow.addtime),  from_unixtime(row_cur_xxbao_borrow.deploytime),  row_cur_xxbao_borrow.lastmodfy,
from_unixtime(row_cur_xxbao_borrow.modifytime),  row_cur_xxbao_borrow.tendnum,  row_cur_xxbao_borrow.tendsum,  row_cur_xxbao_borrow.untendnum,
row_cur_xxbao_borrow.untendsum,  row_cur_xxbao_borrow.flownum,  row_cur_xxbao_borrow.flowsum,  row_cur_xxbao_borrow.notice_id1,
row_cur_xxbao_borrow.notice_id2,  row_cur_xxbao_borrow.notice_id3,  row_cur_xxbao_borrow.notice_id4,  row_cur_xxbao_borrow.notice_id5,
row_cur_xxbao_borrow.isstatistics

);
 end loop;
    commit;
  close cur_xxbao_borrow;
-- xxbao_borrow_audit
EXECUTE IMMEDIATE 'truncate table xxd_xxbao_borrow_audit';
OPEN cur_xxbao_borrow_audit;
  m_count:= 0;
  loop
  m_count:= m_count+1;
FETCH cur_xxbao_borrow_audit INTO row_cur_xxbao_borrow_audit;
exit when cur_xxbao_borrow_audit%notfound;
INSERT INTO xxd_xxbao_borrow_audit (
 auditid,audittime,
 XXBDEPLOYID, Cname, Totalaccount, Numcount,
 Subaccount, Apr, Timelimit, Lowesttender,
 Mosttender,  Style,  Validdays,  Status,
 Operator,  Addtime,  Deploytime,   Lastmodfy,
 Modifytime,  Tendnum,  Tendsum,  Untendnum,
 Untendsum,  Flownum,  Flowsum,  Notice_Id1,
 Notice_Id2,  Notice_Id3,  Notice_Id4,  Notice_Id5,
 Isstatistics
)
VALUES
  (
row_cur_xxbao_borrow_audit.auditid,row_cur_xxbao_borrow_audit.audittime,
row_cur_xxbao_borrow_audit.id,  row_cur_xxbao_borrow_audit.cname,  row_cur_xxbao_borrow_audit.account,  row_cur_xxbao_borrow_audit.numcount,
row_cur_xxbao_borrow_audit.subaccount,  row_cur_xxbao_borrow_audit.apr,  row_cur_xxbao_borrow_audit.timeLimit,  row_cur_xxbao_borrow_audit.lowesttender,
row_cur_xxbao_borrow_audit.mosttender,  row_cur_xxbao_borrow_audit.style, from_unixtime(row_cur_xxbao_borrow_audit.endtime)-to_date('19700101 08:00','yyyymmdd hh24:mi'),  row_cur_xxbao_borrow_audit.status,
row_cur_xxbao_borrow_audit.operator,  from_unixtime(row_cur_xxbao_borrow_audit.addtime),  from_unixtime(row_cur_xxbao_borrow_audit.deploytime),  row_cur_xxbao_borrow_audit.lastmodfy,
from_unixtime(row_cur_xxbao_borrow_audit.modifytime),  row_cur_xxbao_borrow_audit.tendnum,  row_cur_xxbao_borrow_audit.tendsum,  row_cur_xxbao_borrow_audit.untendnum,
row_cur_xxbao_borrow_audit.untendsum,  row_cur_xxbao_borrow_audit.flownum,  row_cur_xxbao_borrow_audit.flowsum,  row_cur_xxbao_borrow_audit.notice_id1,
row_cur_xxbao_borrow_audit.notice_id2,  row_cur_xxbao_borrow_audit.notice_id3,  row_cur_xxbao_borrow_audit.notice_id4,  row_cur_xxbao_borrow_audit.notice_id5,
row_cur_xxbao_borrow_audit.isstatistics

);
end loop;
    commit;
  close cur_xxbao_borrow_audit;
-- xxd_borrow_xxbmaping
EXECUTE IMMEDIATE 'truncate table xxd_borrow_xxbmaping';
OPEN cur_borrow_xxbmapping;
  m_count:= 0;
  loop
  m_count:= m_count+1;
FETCH cur_borrow_xxbmapping INTO row_cur_borrow_xxbmapping;
exit when cur_borrow_xxbmapping%notfound;
INSERT INTO xxd_borrow_xxbmaping (
XXBMAPINGID,XXBDEPLOYID,BORROWID,ADDDATE,
ADDIP)
VALUES
(
row_cur_borrow_xxbmapping.id,row_cur_borrow_xxbmapping.xxbaodeployid,row_cur_borrow_xxbmapping.borrowid,nvl(from_unixtime(row_cur_borrow_xxbmapping.addtime),sysdate),
'127.0.0.1');
end loop;
    commit;
  close cur_borrow_xxbmapping;
end DT_PROC_XXBAO;



/
