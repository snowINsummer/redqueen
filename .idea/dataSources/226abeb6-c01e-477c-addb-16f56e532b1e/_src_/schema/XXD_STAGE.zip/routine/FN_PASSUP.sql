CREATE function fn_passup(p_oldpaddword in varchar2) return varchar2 is
 m_newpassword varchar2(32);
 --  密码升级函数
  m_md5_2  char(32);-- 二次md5串
  m_md5_36 varchar2(36);-- 密码拼接后36为密码
  m_last_1 char(1);
  m_last_2 char(1);
  m_last_3 char(1);
  m_last_4 char(1);

begin
  m_md5_2:=fn_md5(p_oldpaddword);
  m_last_1:=substr(m_md5_2,29,1);
  m_last_2:=substr(m_md5_2,30,1);
  m_last_3:=substr(m_md5_2,31,1);
  m_last_4:=substr(m_md5_2,32,1);
  m_md5_36:=substr(m_md5_2,1,mod(ascii(m_last_1),32)) ||m_last_1||substr(m_md5_2,mod(ascii(m_last_1),32)+1);
  m_md5_36:=substr(m_md5_36,1,mod(ascii(m_last_2),32)) ||m_last_2||substr(m_md5_36,mod(ascii(m_last_2),32)+1);
  m_md5_36:=substr(m_md5_36,1,mod(ascii(m_last_3),32)) ||m_last_3||substr(m_md5_36,mod(ascii(m_last_3),32)+1);
  m_md5_36:=substr(m_md5_36,1,mod(ascii(m_last_4),32)) ||m_last_4||substr(m_md5_36,mod(ascii(m_last_4),32)+1);
  m_newpassword:=fn_md5(m_md5_36);
  return(m_newpassword);
end fn_passup;



/
