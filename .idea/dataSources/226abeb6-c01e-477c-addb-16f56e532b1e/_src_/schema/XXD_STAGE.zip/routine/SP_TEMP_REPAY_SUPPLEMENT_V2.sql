CREATE procedure SP_TEMP_REPAY_SUPPLEMENT_V2(P_BORROWID      in VARCHAR2,
                                                        P_USERID        in INTEGER,
                                                        P_OFFLINEPORDER in NUMBER,
                                                        P_RESULT        OUT NUMBER) is

  P_PORDER  NUMBER;
  P_VERSION VARCHAR2(50);

begin

  select max(br.porder)
    into P_PORDER
    from xxd_borrow_repayment br
   where borrowid = P_BORROWID
     and userid = P_USERID
     and trunc(br.repaymenttime) <= trunc(sysdate);

  if P_OFFLINEPORDER < P_PORDER then
    P_PORDER := P_OFFLINEPORDER;
  end if;

  SELECT VERSION
    INTO P_VERSION
    from xxd_borrow
   where borrowid = P_BORROWID;

  if P_VERSION <> '20160119' then


    --部分还款版本还款
    SP_TEMP_REPAYOPE_OLD_V2(P_BORROWID, P_USERID, P_PORDER, P_RESULT);

  end if;

  ---标记结果集（成功或不予处理）
  IF P_RESULT = 1 THEN

    UPDATE TEMP_REPAY_USERINFO_V2 t
       SET REMARK = '处理成功,还款至' || P_PORDER || '期', flag = 1
     WHERE t.borrowid = P_BORROWID
       and flag = 0;
    if P_PORDER < P_OFFLINEPORDER then
      update TEMP_REPAY_USERINFO_V2 t
         set flag   = 5,
             remark = '处理成功,还款至' || P_PORDER || '期,财务线下还款多余线上还款'
       where t.BORROWID = P_BORROWID;

    end if;

  ELSE

    UPDATE TEMP_REPAY_USERINFO_V2 t
       SET REMARK = '截止' || to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss') ||
                    '已还，不予处理'
     WHERE t.BORROWID = P_BORROWID;

  END IF;

end;

/
