CREATE PROCEDURE P_UPT_SEQ
Authid Current_User AS
  V_SEQNAME VARCHAR2(100);
  V_NEWNUM  NUMBER;
  V_CACHE   NUMBER;
  V_ERROR   VARCHAR2(1000);
  LDEBUG    VARCHAR2(200);
  V_CURRVAL NUMBER;

BEGIN
  FOR I IN (SELECT T.SEQUENCE_NAME, T.LAST_NUMBER, T.CACHE_SIZE
  FROM USER_SEQUENCES@dblinkto7050 T
  LEFT JOIN USER_SEQUENCES M
    ON T.SEQUENCE_NAME = M.SEQUENCE_NAME
 WHERE T.LAST_NUMBER>M.LAST_NUMBER ) LOOP

    V_SEQNAME := I.SEQUENCE_NAME;
    V_NEWNUM  := I.LAST_NUMBER;
    V_CACHE   := I.CACHE_SIZE;

    EXECUTE IMMEDIATE 'select ' || V_SEQNAME || '.nextval from dual' INTO V_CURRVAL;
    EXECUTE IMMEDIATE 'alter sequence ' || V_SEQNAME || ' nocache';
    EXECUTE IMMEDIATE 'alter SEQUENCE ' || V_SEQNAME || ' increment by ' ||TO_CHAR(V_NEWNUM - V_CURRVAL  ) || ' nocache';
    EXECUTE IMMEDIATE 'select ' || V_SEQNAME || '.nextval from dual' INTO V_CURRVAL;
    EXECUTE IMMEDIATE 'alter SEQUENCE ' || V_SEQNAME || ' increment by  1 ' || CASE
                        WHEN V_CACHE > 0 THEN
                         'cache ' || V_CACHE
                        ELSE
                         'nocache'
                      END;
  END LOOP;

EXCEPTION
  WHEN OTHERS THEN
    V_ERROR := SQLERRM;
    DBMS_OUTPUT.PUT_LINE(V_ERROR);
END;

/
