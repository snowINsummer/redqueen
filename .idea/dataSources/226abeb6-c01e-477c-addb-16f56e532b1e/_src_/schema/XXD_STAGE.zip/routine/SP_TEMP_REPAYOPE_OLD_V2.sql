CREATE procedure SP_TEMP_REPAYOPE_OLD_V2(P_BORROWID in VARCHAR2,
                                                    P_USERID   in INTEGER,
                                                    p_PORDER   in INTEGER,
                                                    P_RESULT   OUT NUMBER) is

  /********************************************************
        功能：补录还款
              1.充值记录，2.还款记录，3.账户日志
        日期：20151019
  ********************************************************/

  L_COUNT                  NUMBER;
  L_COUNT_FROZEN           NUMBER;
  L_COUNT_BF               NUMBER;
  L_REPAYMENTACCOUNT_TOTAL XXD_BORROW_REPAYMENT.REPAYMENTACCOUNT%TYPE;
  /*L_VERSION                XXD_BORROW.VERSION%TYPE;*/
  /*L_RATIO_BASE              XXD_ACCOUNT_FROZEN.FROZEN%TYPE;*/
  L_DEPOSIT_BASE            XXD_ACCOUNT_FROZEN.FROZEN%TYPE;
  L_DEPOSIT_RECHARGE        XXD_ACCOUNT_FROZEN.FROZEN%TYPE;
  L_DEPOSIT_ACCOUT_FROZEN   XXD_ACCOUNT_FROZEN.FROZEN%TYPE;
  L_DEPOSIT_ACCOUT_USERABLE XXD_ACCOUNT_FROZEN.FROZEN%TYPE;
  L_DEPOSIT_ACCOUT_TOTAL    XXD_ACCOUNT_FROZEN.FROZEN%TYPE;
  L_RECHARGEID              XXD_ACCOUNT_RECHARGE.RECHARGEID%TYPE;
  L_TIMELIMIT               XXD_BORROW.TIMELIMIT%TYPE;
  L_STATUS                  XXD_BORROW_REPAYMENT.STATUS%TYPE;
  L_REPAYMENTID             XXD_BORROW_REPAYMENT.REPAYMENTID%TYPE;
  L_REPAYMENTACCOUNT        XXD_BORROW_REPAYMENT.REPAYMENTACCOUNT%TYPE;
  L_REPAYMENTINTEREST       XXD_BORROW_REPAYMENT.REPAYMENTINTEREST%TYPE;
  L_REPAYMENTCAPITAL        XXD_BORROW_REPAYMENT.REPAYMENTCAPITAL%TYPE;
  L_OPERATORTYPE            XXD_ACCOUNT_LOG.OPERATORTYPE%TYPE;
  L_MONEYTYPE               XXD_ACCOUNT_LOG.MONEYTYPE%TYPE;
  L_DEPOSIT_REMARK          XXD_ACCOUNT_LOG.REMARK%TYPE;
  L_BORROW_NAME             XXD_BORROW.NAME%TYPE;
  L_BORROW_ACOUNT           XXD_BORROW.ACCOUNT%TYPE;
  BORROW_INTEREST           NUMBER;
  L_COUNT_INTEREST_FROZEN   NUMBER;

begin

  --预处理，再次核对用户标的信息,标记已经还款的记录
  SELECT COUNT(*)
    INTO L_COUNT
    FROM XXD_BORROW B, XXD_BORROW_REPAYMENT BR
   WHERE B.BORROWID = BR.BORROWID
     AND B.BORROWID = P_BORROWID
     AND B.USERID = P_USERID
     AND BR.PORDER <= P_PORDER
     AND BR.STATUS = 0;

  IF L_COUNT > 0 THEN

    /*************************************提取相关基数，计算需扣除保证金的相关因子**************************************/
    ---提取还款金额(本金+利息)
    SELECT NVL(SUM(REPAYMENTACCOUNT), 0)
      INTO L_REPAYMENTACCOUNT_TOTAL
      FROM XXD_BORROW_REPAYMENT
     WHERE STATUS = 0
       AND BORROWID = P_BORROWID
       AND USERID = P_USERID
       AND PORDER <= P_PORDER;

    ---提取还款期数,标的名称，标的金额
    SELECT NVL(XXD_BORROW.TIMELIMIT, 0),
           NVL(XXD_BORROW.NAME, '0'),
           NVL(XXD_BORROW.ACCOUNT, 0)
      INTO L_TIMELIMIT, L_BORROW_NAME, L_BORROW_ACOUNT
      FROM XXD_BORROW
     WHERE BORROWID = P_BORROWID
       AND USERID = P_USERID;

    ---提取保证金
    SELECT COUNT(*)
      INTO L_COUNT_FROZEN
      FROM XXD_ACCOUNT_FROZEN
     WHERE STATUS = 1
       AND BUSIID = P_BORROWID
       AND USERID = P_USERID
       AND TYPE = 'cash_deposit';

    IF L_COUNT_FROZEN > 0 AND L_TIMELIMIT = P_PORDER THEN

      SELECT NVL(FROZEN, 0)
        INTO L_DEPOSIT_BASE
        FROM XXD_ACCOUNT_FROZEN
       WHERE STATUS = 1
         AND BUSIID = P_BORROWID
         AND USERID = P_USERID
         AND TYPE = 'cash_deposit';

    ELSE

      L_DEPOSIT_BASE := 0;

    END IF;

    ---提取保证金
    SELECT COUNT(*)
      INTO L_COUNT_INTEREST_FROZEN
      FROM XXD_ACCOUNT_FROZEN
     WHERE STATUS = 1
       AND BUSIID = P_BORROWID
       AND TYPE = 'repay_money';

    IF L_COUNT_INTEREST_FROZEN > 0 AND L_TIMELIMIT = P_PORDER THEN

      SELECT NVL(FROZEN, 0)
        INTO BORROW_INTEREST
        FROM XXD_ACCOUNT_FROZEN
       WHERE STATUS = 1
         AND BUSIID = P_BORROWID
         AND TYPE = 'repay_money';

    ELSE

      BORROW_INTEREST := 0;

    END IF;

    L_DEPOSIT_RECHARGE        := NVL(L_DEPOSIT_BASE, 0); --充值全额减去保证金
    L_DEPOSIT_ACCOUT_FROZEN   := NVL(L_DEPOSIT_BASE, 0);
    L_DEPOSIT_ACCOUT_USERABLE := NVL(L_DEPOSIT_BASE, 0);
    L_DEPOSIT_ACCOUT_TOTAL    := 0;
    L_OPERATORTYPE            := 'reback_desposit';
    L_MONEYTYPE               := 2;
    L_DEPOSIT_REMARK          := '您发布的借款标<a href=""http://www.xinxindai.com/borrow/detail/' ||
                                 P_BORROWID || '.html"">' || L_BORROW_NAME ||
                                 '</a>还款结束，退回保证金,￥' || L_DEPOSIT_BASE;

    /*************************************充值处理******************************************/
    ---获取充值ID
    SELECT ('AR' || TO_CHAR(SYSDATE, 'YYYYMMDD') ||
           LPAD(SEQ_ACCOUNT_RECHARGE.NEXTVAL, 5, 0))
      INTO L_RECHARGEID
      FROM DUAL;

    --充值记录
    INSERT INTO XXD_ACCOUNT_RECHARGE
      (RECHARGEID,
       USERID,
       TYPE,
       BANKCODE,
       ORDERNO,
       AMOUNT,
       FEE,
       ADDTIME,
       RECHARGEIP,
       VERIFYUSERID,
       VERIFYDATE,
       VERIFYIP,
       STATUS,
       REMARK,
       TERMINALVER,
       PARTNERID)
    values
      (L_RECHARGEID,
       P_USERID,
       1,
       'FYYX',
       'SJXF_' || TO_CHAR(systimestamp, 'YYYYMMDDHH24MISSff6'),
       L_REPAYMENTACCOUNT_TOTAL - L_DEPOSIT_RECHARGE - BORROW_INTEREST, -- 充值金额 = 需还还款总金额 - 需要退还的保证金 - 冻结利息
       0,
       sysdate,
       '127.0.0.1',
       0,
       sysdate,
       '127.0.0.1',
       1,
       '批量补录还款历史数据，充值￥' ||
       (L_REPAYMENTACCOUNT_TOTAL - L_DEPOSIT_RECHARGE - BORROW_INTEREST),
       'PC',
       0);

    --账户记录
    UPDATE XXD_ACCOUNT
       SET XXD_ACCOUNT.USABLE       = XXD_ACCOUNT.USABLE +
                                      (L_REPAYMENTACCOUNT_TOTAL -
                                      L_DEPOSIT_RECHARGE - BORROW_INTEREST),
           XXD_ACCOUNT.ACCOUNTTOTAL = XXD_ACCOUNT.ACCOUNTTOTAL +
                                      (L_REPAYMENTACCOUNT_TOTAL -
                                      L_DEPOSIT_RECHARGE - BORROW_INTEREST)
     WHERE XXD_ACCOUNT.USERID = P_USERID
       AND XXD_ACCOUNT.PCODE = '1001';

    --日志记录
    INSERT INTO XXD_ACCOUNT_LOG
      (ID,
       USERID,
       PCODE,
       USABLE,
       FROZEN,
       COLLECTION,
       REPAYMENT,
       ADDTIME,
       BUSITIME,
       OPERATORTYPE,
       MONEYTYPE,
       WORKMONEY,
       BUSIID,
       ADDIP,
       ACCOUNTTOTAL,
       SCHEMEID,
       REMARK,
       STATUS,
       ISSHOW)
      select seq_account_log.nextval,
             USERID,
             PCODE,
             USABLE,
             FROZEN,
             COLLECTION,
             REPAYMENT,
             systimestamp,
             sysdate,
             'recharge_success',
             2,
             L_REPAYMENTACCOUNT_TOTAL - L_DEPOSIT_RECHARGE -
             BORROW_INTEREST, --充值金额
             L_RECHARGEID, --充值记录
             '127.0.0.1',
             ACCOUNTTOTAL,
             '0',
             '批量补录还款历史数据，￥' || (L_REPAYMENTACCOUNT_TOTAL -
             L_DEPOSIT_RECHARGE - BORROW_INTEREST),
             0,
             0
        from XXD_ACCOUNT
       where USERID = P_USERID
         and PCODE = '1001';

    /******************************************还款处理**************************************/

    --更改账户

    FOR i IN 1 .. P_PORDER LOOP

      --判断是否已还款
      SELECT STATUS
        INTO L_STATUS
        FROM XXD_BORROW_REPAYMENT
       WHERE BORROWID = P_BORROWID
         AND USERID = P_USERID
         AND PORDER = i;

      --如果还款，则更改账户信息，还款
      IF L_STATUS = 0 THEN

        SELECT REPAYMENTID,
               NVL(REPAYMENTACCOUNT, 0),
               NVL(REPAYMENTINTEREST, 0),
               NVL(REPAYMENTCAPITAL, 0)
          INTO L_REPAYMENTID,
               L_REPAYMENTACCOUNT,
               L_REPAYMENTINTEREST,
               L_REPAYMENTCAPITAL
          FROM XXD_BORROW_REPAYMENT
         WHERE BORROWID = P_BORROWID
           AND USERID = P_USERID
           AND PORDER = i;

        IF i = L_TIMELIMIT THEN

          ---------------------------------处理保证金--------------------------
          IF L_DEPOSIT_BASE > 0 THEN

            --解冻保证金的冻结记录
            update xxd_account_frozen t
               set status       = 2,
                   UNFROZENTIME = SYSDATE,
                   UNFROZENIP   = '127.0.0.1'
             where t.busiid = P_BORROWID
               and t.busiid2 = '0'
               and t.status = 1
               and type = 'cash_deposit';

            UPDATE XXD_BORROW_FEE BF
               SET BF.REALRETURNFEE = BF.RETURNFEE, BF.STATUS = 4
             WHERE BF.BORROWID = P_BORROWID
               AND BF.PORDER = 0
               AND BF.FEETYPE = 1;

            --变更资金账户 【冻结金额】
            UPDATE XXD_ACCOUNT
               SET XXD_ACCOUNT.FROZEN       = XXD_ACCOUNT.FROZEN -
                                              L_DEPOSIT_ACCOUT_FROZEN,
                   XXD_ACCOUNT.USABLE       = XXD_ACCOUNT.USABLE +
                                              L_DEPOSIT_ACCOUT_USERABLE,
                   XXD_ACCOUNT.ACCOUNTTOTAL = XXD_ACCOUNT.ACCOUNTTOTAL -
                                              L_DEPOSIT_ACCOUT_TOTAL
             WHERE XXD_ACCOUNT.USERID = P_USERID
               AND PCODE = '1001';

            ---记录资金日志(保证金变动)
            INSERT INTO XXD_ACCOUNT_LOG
              (ID,
               USERID,
               PCODE,
               USABLE,
               FROZEN,
               COLLECTION,
               REPAYMENT,
               ADDTIME,
               BUSITIME,
               OPERATORTYPE,
               MONEYTYPE,
               WORKMONEY,
               BUSIID,
               ADDIP,
               ACCOUNTTOTAL,
               SCHEMEID,
               REMARK,
               STATUS,
               ISSHOW)
              select SEQ_ACCOUNT_LOG.NEXTVAL,
                     USERID,
                     PCODE,
                     USABLE,
                     FROZEN,
                     COLLECTION,
                     REPAYMENT,
                     systimestamp,
                     sysdate,
                     L_OPERATORTYPE,
                     L_MONEYTYPE,
                     L_DEPOSIT_BASE,
                     P_BORROWID,
                     '127.0.0.1',
                     ACCOUNTTOTAL,
                     '0',
                     L_DEPOSIT_REMARK,
                     0,
                     0
                from XXD_ACCOUNT
               where USERID = P_USERID
                 and PCODE = '1001';
          END IF;
        END IF;

        -- 处理冻结利息期数
        update xxd_account_frozen
           set busiid2 = i
         where busiid = P_BORROWID
           and status = 1
           AND TYPE = 'repay_money';

        if L_TIMELIMIT = i then
          --处理冻结利息
          update xxd_account_frozen
             set status = 2
           where busiid = P_BORROWID
             and status = 1
             AND TYPE = 'repay_money';

          /*********************/

          UPDATE XXD_ACCOUNT
             SET FROZEN = FROZEN - BORROW_INTEREST,
                 USABLE = USABLE + BORROW_INTEREST
           where userid = P_USERID
             and pcode = '1001';

          insert into XXD_ACCOUNT_LOG
            (ID,
             USERID,
             PCODE,
             USABLE,
             FROZEN,
             COLLECTION,
             REPAYMENT,
             ADDTIME,
             BUSITIME,
             OPERATORTYPE,
             MONEYTYPE,
             WORKMONEY,
             BUSIID,
             ADDIP,
             ACCOUNTTOTAL,
             SCHEMEID,
             REMARK,
             STATUS,
             ISSHOW)
            select seq_account_log.nextval,
                   USERID,
                   PCODE,
                   USABLE,
                   FROZEN,
                   COLLECTION,
                   REPAYMENT,
                   systimestamp,
                   sysdate,
                   'unfrozen_repay_money_interest',
                   1,
                   BORROW_INTEREST,
                   P_BORROWID,
                   '127.0.0.1',
                   ACCOUNTTOTAL,
                   '0',
                   '您发布的借款标<a href=""http://www.xinxindai.com/borrow/detail/' ||
                 P_BORROWID || '.html"">' || L_BORROW_NAME ||
                 '</a>第<font style=''color:green;font-weight:600''>' || i || '/' ||
                 L_TIMELIMIT || '</font>还款，退回储备利息：￥' || BORROW_INTEREST || '元。',
                   0,
                   0
              from XXD_ACCOUNT
             where USERID = P_USERID
               and PCODE = '1001';
          /*********************/

          --更新标的状态
          update xxd_borrow
             set status = 5
           where status = 4
             and borrowid = P_BORROWID;
        END IF;

        UPDATE XXD_ACCOUNT
           SET REPAYMENT = REPAYMENT - L_REPAYMENTACCOUNT,
               USABLE    = USABLE - L_REPAYMENTACCOUNT
         where userid = P_USERID
           and pcode = '1001';

        --记录资金日志 [busitime是否需要取repayment的应还时间？]
        insert into XXD_ACCOUNT_LOG
          (ID,
           USERID,
           PCODE,
           USABLE,
           FROZEN,
           COLLECTION,
           REPAYMENT,
           ADDTIME,
           BUSITIME,
           OPERATORTYPE,
           MONEYTYPE,
           WORKMONEY,
           BUSIID,
           ADDIP,
           ACCOUNTTOTAL,
           SCHEMEID,
           REMARK,
           STATUS,
           ISSHOW)
          select seq_account_log.nextval,
                 USERID,
                 PCODE,
                 USABLE,
                 FROZEN,
                 COLLECTION,
                 REPAYMENT,
                 systimestamp,
                 sysdate,
                 'repay_money',
                 1,
                 L_REPAYMENTACCOUNT,
                 P_BORROWID,
                 '127.0.0.1',
                 ACCOUNTTOTAL,
                 '0',
                 '您发布的借款标<a href=""http://www.xinxindai.com/borrow/detail/' ||
                 P_BORROWID || '.html"">' || L_BORROW_NAME ||
                 '</a>第<font style=''color:green;font-weight:600''>' || i || '/' ||
                 L_TIMELIMIT || '</font>期已还款，还款本息：￥' || L_REPAYMENTACCOUNT || '元。',
                 0,
                 0
            from XXD_ACCOUNT
           where USERID = P_USERID
             and PCODE = '1001';

        update XXD_BORROW_REPAYMENT
           set REPAYMENTYESACCOUNT  = L_REPAYMENTACCOUNT,
               REPAYMENTYESINTEREST = L_REPAYMENTINTEREST,
               REPAYMENTYESCAPITAL  = L_REPAYMENTCAPITAL,
               repaymentyestime     = SYSDATE,
               STATUS               = 1
         where STATUS = 0
           and REPAYMENTID = L_REPAYMENTID
           and USERID = P_USERID;

      end if;

    END LOOP;

    ---修改费率状态
    SELECT COUNT(*)
      INTO L_COUNT_BF
      FROM XXD_BORROW_FEE BF
     WHERE BF.BORROWID = P_BORROWID
       AND BF.FEETYPE IN (1, 2, 3, 4);

    UPDATE XXD_BORROW_FEE BF
       SET BF.REALFEE = BF.FEE, BF.STATUS = 1
     WHERE BF.BORROWID = P_BORROWID
       AND BF.PORDER > 0
       and bf.porder <= p_PORDER
       AND BF.FEETYPE IN (2, 3, 4);

    P_RESULT := 1;

  ELSE
    P_RESULT := 0;

  END IF;

end;

/
