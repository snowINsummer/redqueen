CREATE procedure tbcnt as
cursor ttt is select 'insert into tb_rec select ''XINXINDB'','''||table_name||''',count(1),sysdate from '||table_name||' as of timestamp to_date('''||to_char(sysdate,'yyyymmddhh24')||'0000'',''yyyymmddhh24miss'')'
                from user_tables
               where table_name not in ('TB_REC','TB_REC_ERROR','XXD_ACCOUNT_AUDIT','XXD_FIFO_DAILY','XXD_FIFO_TEMP','XXD_IP_EXT')
                 and table_name not like 'TEMP%';
stext varchar2(200);
begin
open ttt;
loop
fetch ttt into stext;
exit when ttt%notfound;
execute immediate stext;
commit;
end loop;
EXCEPTION when others then
 insert into tb_rec_error values (stext);
close ttt;
end;
/
