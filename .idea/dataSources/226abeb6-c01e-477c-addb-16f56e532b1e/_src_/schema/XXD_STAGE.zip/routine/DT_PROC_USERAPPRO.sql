CREATE procedure DT_PROC_USERAPPRO is
CURSOR cur_user_appro IS
select a.id,b.ispassed ISPASSED1,c.ispassed ISPASSED2,d.ispassed ISPASSED3,
        e.ispassed ISPASSED4,f.status ISPASSED5,a.addtime createdate,a.addip createip,
        b.approtime approtime1,c.applytime APPROTIME2,d.approtime APPROTIME3,e.approtime APPROTIME4,f.addtime APPROTIME5
from XXDAI_USER a
LEFT JOIN XXDAI_VIP_APPRO b on a.id = b.USERID
LEFT JOIN XXDAI_REALNAME_APPRO c on a.id =c.USERID
LEFT JOIN XXDAI_EMAIL_APPRO d on a.id=d.USERID
LEFT JOIN XXDAI_MOBILE_APPRO e on a.id=e.USERID
LEFT JOIN (select q.id,p.userid,q.status,q.addtime from xxdai_stu_baseinfo p,xxdai_stu_identified q where p.id =q.stuid) f on a.ID=f.USERID
where b.ispassed is not NULL or c.ispassed is not NULL or d.ispassed is not NULL or e.ispassed is not NULL or f.status is not NULL;
row_cur_user_appro cur_user_appro%rowtype;

CURSOR cur_realname IS SELECT
  a.id,         a.userid,  a.idcardtype,  a.idCardNo,
  a.realname,   a.pic1,    a.pic2,        a.ispassed,
  a.approTime,  a.approveUser, a.approIp,
  a.approRemark,a.applytime,   a.applyIp
  FROM  xxdai_realname_appro a;
  row_cur_realname cur_realname%rowtype;

CURSOR cur_vip IS SELECT
  a.ID,        a.userid,   a.ispassed,     a.approTime,
  a.approUser, a.approIp,  a.approRemark,  a.serverNum,
  a.isFee,     a.indate,   a.applyTime,    a.applyIp
FROM
  xxdai_vip_appro a;
  row_cur_vip cur_vip%rowtype;



CURSOR cur_email IS SELECT
  a.id,         a.userid,  a.uuid, a.ispassed,
  a.approTime,    a.approIp
  FROM  xxdai_email_appro a;
  row_cur_email cur_email%rowtype;

CURSOR cur_mobile IS SELECT
            a.id,  a.userid,  a.mobileNum,  a.randNo,
            a.ispassed,  a.approTime,  a.approIp
             FROM  xxdai_mobile_appro a;
  row_cur_mobile cur_mobile%rowtype;
m_count INTEGER ;
BEGIN
-- 实名认证
EXECUTE IMMEDIATE 'truncate table xxd_realname_appro';
update xxdai_realname_appro set ispassed=0 where ispassed=-1;
commit;
OPEN cur_realname;
  m_count:= 0;
  loop
  m_count:= m_count+1;
FETCH cur_realname INTO row_cur_realname;
exit when cur_realname%notfound;
INSERT INTO xxd_realname_appro (
  id,   userid,   idcardtype,   idcardno,
  realname,  pic_up,  pic_down,  status,
  approdate,  approuserid,  approusername,  approip,
  approremark,  vaildate,  createdate,  createip,
  modifydate,  lastmodify
)
VALUES
  (
  row_cur_realname.id,         row_cur_realname.userid,  row_cur_realname.idcardtype,  nvl(row_cur_realname.idCardNo,' '),
  row_cur_realname.realname,   replace(row_cur_realname.pic1,'/uploadFile/','/static/image/uploadFile/'), replace(nvl(row_cur_realname.pic2,' '),'/uploadFile/','/static/image/uploadFile/'),        row_cur_realname.ispassed,
  from_unixtime(row_cur_realname.approTime), NULL,      row_cur_realname.approveUser, row_cur_realname.approIp,
  row_cur_realname.approRemark,NULL ,nvl(from_unixtime(row_cur_realname.applytime),sysdate),   row_cur_realname.applyIp,
  nvl(from_unixtime(row_cur_realname.approTime),sysdate),  NULL
);
 if mod(m_count,5000)=0 then
      commit;
  end if;
  end loop;
    commit;
  close cur_realname;
update xxd_realname_appro a
set a.approuserid = (select b.id from (select min(id) id,name from XXDAI_EMPLOYEE GROUP BY name) b where a.approusername=b.name);
update xxd_realname_appro a
set a.lastmodify = (select b.id from (select min(id) id,name from XXDAI_EMPLOYEE GROUP BY name) b where a.approusername=b.name);
commit;
-- vip认证
EXECUTE IMMEDIATE 'truncate table xxd_vip_appro';
  OPEN cur_vip;
  m_count:= 0;
  loop
  m_count:= m_count + 1;
FETCH cur_vip INTO row_cur_vip;
exit when cur_vip%notfound;
INSERT INTO xxd_vip_appro (
  ID,  userid,  status,  approdate,
  approuserid,  approusername,  approip,  approremark,
  servicenum,  isfee,  indate,  createdate,
  createip,  modifydate,  lastmodify
)
VALUES
  (
    row_cur_vip.ID,    row_cur_vip.userid,    row_cur_vip.ispassed,    nvl(FROM_UNIXTIME(row_cur_vip.approTime),SYSDATE),
    1,    row_cur_vip.approUser,    row_cur_vip.approIp,    row_cur_vip.approRemark,
    nvl(row_cur_vip.serverNum,' '),    row_cur_vip.isFee,    nvl(FROM_UNIXTIME(row_cur_vip.indate),SYSDATE),    nvl(FROM_UNIXTIME(row_cur_vip.applyTime),SYSDATE),
    row_cur_vip.applyIp,    nvl(FROM_UNIXTIME(row_cur_vip.approTime),SYSDATE),   1
);
 if mod(m_count,5000)=0 then
      commit;
  end if;
 end loop;
  commit;
  close cur_vip;
update xxd_vip_appro a
set a.approuserid = (select b.id from (select min(id) id,name from XXDAI_EMPLOYEE GROUP BY name) b where a.approusername=b.name);
update xxd_vip_appro a
set a.lastmodify = (select b.id from (select min(id) id,name from XXDAI_EMPLOYEE GROUP BY name) b where a.approusername=b.name);
commit;

-- email认证
EXECUTE IMMEDIATE 'truncate table xxd_email_appro';
commit;
 OPEN cur_email;
  m_count:= 0;
  loop
  m_count:= m_count+1;
FETCH cur_email INTO row_cur_email;
exit when cur_email%notfound;
INSERT INTO xxd_email_appro (
  id,  userid,  email,  uuid,
  status,  approdate,  approip,  approremark,
  createdate,  createip,  modifydate,  lastmodify

)
VALUES
  (
  row_cur_email.id,         row_cur_email.userid,' ',  nvl(row_cur_email.uuid,' '),
  row_cur_email.ispassed,   from_unixtime(row_cur_email.approTime),    row_cur_email.approIp, NULL,
 nvl(from_unixtime(row_cur_email.approTime),sysdate),  nvl(row_cur_email.approIp,'127.0.0.1'), nvl(from_unixtime(row_cur_email.approTime),sysdate),  row_cur_email.userid
);
 if mod(m_count,5000)=0 then
      commit;
  end if;
  end loop;
    commit;
  close cur_email;
update xxd_email_appro a
set a.email = nvl((select b.email from xxdai_user b where a.userid=b.id),' ');
commit;
-- mobile认证
EXECUTE IMMEDIATE 'truncate table xxd_mobile_appro';
update xxdai_mobile_appro set ispassed=0 where ispassed=-1;
commit;
OPEN cur_mobile;
  m_count:= 0;
  loop
  m_count:= m_count+1;
FETCH cur_mobile INTO row_cur_mobile;
exit when cur_mobile%notfound;
INSERT INTO xxd_mobile_appro (
  ID,  userid,  mobileno,  approcode,  status,
  approdate,  approip,  approremark,  createdate,
  createip,  modifydate,  lastmodify
)
VALUES
  (
  row_cur_mobile.id,  row_cur_mobile.userid,  nvl(row_cur_mobile.mobileNum,' '),  nvl(row_cur_mobile.randNo,'0000'),  row_cur_mobile.ispassed,
  from_unixtime(row_cur_mobile.approTime),  row_cur_mobile.approIp,  NULL, nvl(from_unixtime(row_cur_mobile.approTime),sysdate),
 nvl(row_cur_mobile.approIp,'127.0.0.1'),sysdate,0
);
 if mod(m_count,5000)=0 then
      commit;
  end if;
  end loop;
    commit;
  close cur_mobile;
-- 用户认证中心
EXECUTE IMMEDIATE 'truncate table xxd_user_infoappro_center';
  OPEN cur_user_appro;
  m_count:= 0;
  loop
  m_count:= m_count+1;
FETCH cur_user_appro INTO row_cur_user_appro;
exit when cur_user_appro%notfound;
INSERT INTO xxd_user_infoappro_center (
  userid,       vip,             realname,     email,
  mobile,       studentrecords,  otherappro1,  otherappro2,
  otherappro3,  otherappro4,     createdate,   createip,
  modifydate,   note
)
VALUES
  (
   row_cur_user_appro.id,                nvl(row_cur_user_appro.ispassed1,0),  nvl(row_cur_user_appro.ispassed2,0),   nvl(row_cur_user_appro.ispassed3,0),
   nvl(row_cur_user_appro.ispassed4,0),  nvl(row_cur_user_appro.ispassed5,0),  0,                                     0,
   0,                                    0,                                    nvl(from_unixtime(row_cur_user_appro.createdate),sysdate), nvl(row_cur_user_appro.createip,'127.0.0.1'),
  from_unixtime(greatest(nvl(row_cur_user_appro.APPROTIME1,0),nvl(row_cur_user_appro.APPROTIME2,0),nvl(row_cur_user_appro.APPROTIME3,0),nvl(row_cur_user_appro.APPROTIME4,0),nvl(row_cur_user_appro.APPROTIME5,0))),NULL
);
 if mod(m_count,5000)=0 then
      commit;
  end if;
 end loop;
    commit;
  close cur_user_appro;
end DT_PROC_USERAPPRO;



/
