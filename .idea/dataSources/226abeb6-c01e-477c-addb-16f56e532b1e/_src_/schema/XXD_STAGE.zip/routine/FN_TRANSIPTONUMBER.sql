CREATE function fn_transiptonumber(ps_ipaddr in varchar2) return binary_double is
  bd_rtn binary_double;
  bd_ip1 binary_double;
  bd_ip2 binary_double;
  bd_ip3 binary_double;
  bd_ip4 binary_double;
begin
  bd_ip1 := to_number(substr(ps_ipaddr, 1, instr(ps_ipaddr, '.', 1, 1) - 1));
  bd_ip2 := to_number(substr(ps_ipaddr, instr(ps_ipaddr, '.', 1, 1) + 1, instr(ps_ipaddr, '.', 1, 2) - instr(ps_ipaddr, '.', 1, 1) - 1));
  bd_ip3 := to_number(substr(ps_ipaddr, instr(ps_ipaddr, '.', 1, 2) + 1, instr(ps_ipaddr, '.', 1, 3) - instr(ps_ipaddr, '.', 1, 2) - 1));
  bd_ip4 := to_number(substr(ps_ipaddr, instr(ps_ipaddr, '.', -1, 1) + 1));

  bd_rtn := bd_ip1 * 256 * 256 * 256 +
           bd_ip2 * 256 * 256 +
           bd_ip3 * 256 +
           bd_ip4 ;

  return(bd_rtn);
end fn_transiptonumber;
/
