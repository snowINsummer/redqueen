CREATE procedure tabcnt as
cursor ttt is select 'insert into tb_rec select ''V6TRAIN'','''||table_name||''',count(1),trunc(sysdate) from '||table_name||' where '||COLUMN_NAME||'<=trunc(sysdate)+1/3'
                from user_tab_columns
               where table_name not in ('TB_REC','TB_REC_ERROR','XXD_FIFO_DAILY','XXD_IP_EXT','XXD_PRODUCT_DAILY')
                 and table_name not like 'TEMP%'
                 and table_name not like '%TEMP'
                 and table_name not like '%AUDIT'
                 and COLUMN_NAME in ('ADDTIME','CREATEDATE','LOGINTIME')
                 and (DATA_TYPE ='DATE' or DATA_TYPE like 'TIMESTAMP%');
stext varchar2(200);
begin
open ttt;
loop
fetch ttt into stext;
exit when ttt%notfound;
execute immediate stext;
commit;
end loop;
EXCEPTION when others then
 insert into tb_rec_error values (stext);
 commit;
close ttt;
end;
/
