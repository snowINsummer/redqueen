CREATE procedure dt_proc_xxd_xinxincity is

 cursor cur_xxd_market_goods is select
 ID,GOODSNUM,GOODSNAME,PRICE,STANDARD,GOODSTYPE,EXPRESSFEE,XXBEXPRESSFEE,XINXINCOIN,USEMONEY,LIMITCOUNT,COUNT,IMGPATH,REMARK
 from xxdai_market_goods;  --创建xxd_market_goods游标
  row_cur_xxd_market_goods cur_xxd_market_goods%rowtype; --创建xxd_market_goods行类型变量
  --
 cursor cur_xxd_market_order is  select
 t.ID,t.ORDERNUM,t.ORDERTYPE,t.GOODSNUM,t.BUYCOUNT,t.PAYMONEY,t.STATUS,t.USERID,t.PAYTYPE,t.COSTPRICE,t.POSTCODE,t.EXPRESSFEE,t.ADDRESSACCOUNT,t.USERNAME,t.PNUMBER,t.ADDTIME,t.ADDIP,t.AFFIRMTIME,t.AFFIRMNAME,t.EXPRESSORDERNUM,t.shipmentstime,t.shipmentsname,t.AFFIRMID,t.SHIPMENTSID
  from xxdai_market_order t ;--创建xxd_market_orders游标
 row_cur_xxd_market_order cur_xxd_market_order%rowtype;--创建xxd_market_orders行类型变量
  --
  m_count  integer;--提交计数器
begin
--XXD_MARKET_GOODS表处理
  delete from XXD_MARKET_GOODS t;
  commit;
  open cur_xxd_market_goods;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_xxd_market_goods
      into row_cur_xxd_market_goods;
    exit when cur_xxd_market_goods%notfound;
    insert into  xxd_market_goods
    ( ID,          GOODSNUM,          GOODSNAME,          PRICE,       STANDARD,
    GOODSTYPE,   EXPRESSFEE,      XXBEXPRESSFEE,     XINXINCOIN,       USEMONEY,
    LIMITCOUNT,       COUNT,          SELLCOUNT,        IMGPATH,       REMARK)
    values
      (row_cur_xxd_market_goods.id,          row_cur_xxd_market_goods.GOODSNUM,       row_cur_xxd_market_goods.GOODSNAME,         row_cur_xxd_market_goods.PRICE,        row_cur_xxd_market_goods.STANDARD,
      row_cur_xxd_market_goods.GOODSTYPE,    row_cur_xxd_market_goods.EXPRESSFEE,     row_cur_xxd_market_goods.XXBEXPRESSFEE,     row_cur_xxd_market_goods.XINXINCOIN,    row_cur_xxd_market_goods.USEMONEY,
      row_cur_xxd_market_goods.LIMITCOUNT,    row_cur_xxd_market_goods.COUNT,                                  0,              row_cur_xxd_market_goods.IMGPATH,      row_cur_xxd_market_goods.REMARK
      );
     if mod(m_count,2000)=0 then
     commit;
     end if;
  end loop;
  commit;
  close cur_xxd_market_goods;
--xxd_market_order表处理
  delete from xxd_market_order t;
  commit;
  open cur_xxd_market_order;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_xxd_market_order
      into row_cur_xxd_market_order;
    exit when cur_xxd_market_order%notfound;
    insert into  xxd_market_order
    (ID,         ORDERNUM,         ORDERTYPE,             GOODSNUM,          BUYCOUNT,
    PAYMONEY,    STATUS,             USERID,                PAYTYPE,           COSTPRICE,
    POSTCODE,    EXPRESSFEE,     ADDRESSACCOUNT,           USERNAME,            "number",
    ADDTIME,     ADDIP,          AFFIRMTIME,               AFFIRMNAME,          EXPRESSORDERNUM,
    SHIPMENTSTIME,   SHIPMENTSNAME,  AFFIRMID,         shipmentsid)
    values
      (row_cur_xxd_market_order.id,   row_cur_xxd_market_order.ORDERNUM, row_cur_xxd_market_order.ORDERTYPE,   row_cur_xxd_market_order.GOODSNUM, row_cur_xxd_market_order.BUYCOUNT,
      row_cur_xxd_market_order.PAYMONEY,    row_cur_xxd_market_order.STATUS,        row_cur_xxd_market_order.USERID,                    row_cur_xxd_market_order.PAYTYPE,       row_cur_xxd_market_order.COSTPRICE,
      row_cur_xxd_market_order.POSTCODE,    row_cur_xxd_market_order.EXPRESSFEE,        row_cur_xxd_market_order.ADDRESSACCOUNT,           row_cur_xxd_market_order.username,      row_cur_xxd_market_order.pnumber,
      nvl(FROM_UNIXTIME(row_cur_xxd_market_order.addtime),sysdate),     row_cur_xxd_market_order.addip,            nvl(FROM_UNIXTIME(row_cur_xxd_market_order.affirmtime),sysdate),                row_cur_xxd_market_order.affirmname,   row_cur_xxd_market_order.expressordernum,
      nvl(FROM_UNIXTIME(row_cur_xxd_market_order.shipmentstime),sysdate),  row_cur_xxd_market_order.SHIPMENTSNAME,  row_cur_xxd_market_order.AFFIRMID,  row_cur_xxd_market_order.shipmentsid);
     if mod(m_count,2000)=0 then
     commit;
     end if;
  end loop;
  commit;
  close cur_xxd_market_order;
end dt_proc_xxd_xinxincity;



/
