CREATE function fn_md5(instra in varchar2)
return varchar2
is
retval varchar2(32);
begin
retval := lower(utl_raw.cast_to_raw(dbms_obfuscation_toolkit.md5(input_string => instra))) ;
return retval;
end;



/
