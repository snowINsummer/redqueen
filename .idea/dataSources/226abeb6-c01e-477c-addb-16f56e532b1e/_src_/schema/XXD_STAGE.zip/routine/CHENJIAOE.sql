CREATE procedure chenjiaoe  is
cursor tttt is 
select 1 mn from dual;
money tttt%rowtype;
begin
  loop
open tttt;
fetch tttt into money;
exit when tttt%notfound;
DBMS_OUTPUT.PUT_LINE(money.mn);
end loop;
close tttt;
end;
/
