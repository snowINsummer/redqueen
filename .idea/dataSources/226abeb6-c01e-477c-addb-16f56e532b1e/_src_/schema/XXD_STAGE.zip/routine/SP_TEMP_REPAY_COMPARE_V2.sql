CREATE PROCEDURE SP_TEMP_REPAY_COMPARE_V2 IS

  /********************************************************
        功能：线上还款数据修复VERSION2
              本次还款数据修复，是DB由系统导出的逾期未还款的EXCEL给予财务核对[对应数据见邮件]，
              财务会在已结清的标的后添加线下实际还款时间。
              之前月滚动修复数据导入表TEMP_REPAY_USERINFO保存并且不再使用
        日期：20160328
  ********************************************************/

  cursor cursor_ru_v2 is
    select * from TEMP_REPAY_USERINFO_V2 where flag = 0;
  row_cursor_ru_v2 cursor_ru_v2%rowtype;
  P_RESULT         NUMBER;

BEGIN

  --财务提供备注中标记过的标的
  update TEMP_REPAY_USERINFO_V2 tr_v2
     set tr_v2.flag = -7, tr_v2.remark = '财务提供备注中标记过的标的'
   where tr_v2.financeremark is not null
     and flag = 0;

  --财务填写真实姓名与系统不符合
  update TEMP_REPAY_USERINFO_V2 tr_v2
     set tr_v2.flag = -4, tr_v2.remark = '财务提供真实姓名与线上不符'
   where tr_v2.realname != tr_v2.offlinerealname
     and flag = 0;

  --财务提供实际借口金额与线上不符
  update TEMP_REPAY_USERINFO_V2 tr_v2
     set tr_v2.flag = -5, tr_v2.remark = '财务提供实际借款金额与线上不符'
   where tr_v2.account != nvl(tr_v2.offlineaccount, -1)
     and flag = 0;

  --财务提供借款期数与线上不符
  update TEMP_REPAY_USERINFO_V2 tr_v2
     set tr_v2.flag = -6, tr_v2.remark = '财务提供借款期数与线上不符'
   where tr_v2.timelimit != nvl(tr_v2.offlinetimlimit, -1)
     and flag = 0;

  --判断用户是否有过投资行为
  update TEMP_REPAY_USERINFO_V2 ru_v2
     set ru_v2.flag = -1, ru_v2.remark = '该用户有过投资行为'
   where ru_v2.flag = 0
     and NOT EXISTS
   (select 1
            from xxd_realname_appro ra
           where RA.STATUS = 1
             and ru_v2.userid = ra.userid
             AND NOT EXISTS (SELECT USERID
                    FROM XXD_TRADE_PACK TP
                   WHERE RA.USERID = TP.USERID)
             AND NOT EXISTS (SELECT USERID
                    FROM XXD_BORROW_TENDER BT
                   WHERE RA.USERID = BT.USERID)
             AND NOT EXISTS (SELECT USERID
                    FROM XXD_OPTIMIZE_USERSCHEME OU
                   WHERE RA.USERID = OU.USERID));

  --判断是否有重复标的
  update TEMP_REPAY_USERINFO_V2 ru_v2
     set ru_v2.flag = -2, ru_v2.remark = '查询出重复数据'
   where ru_v2.flag = 0
     and exists (select count(1), b.userid
            from TEMP_REPAY_USERINFO_V2 tru2, xxd_borrow b
           where tru2.userid = b.userid
             and tru2.timelimit = b.timelimit
             and b.account = tru2.account
             and tru2.id = ru_v2.id
             and b.status = 4
             AND tru2.successtime = b.successtime
             and tru2.addtime = b.addtime
           group by b.userid,
                    b.account,
                    b.timelimit,
                    b.successtime,
                    b.addtime
          having count(1) > 1);

    --线上数据已经还款完毕（一定要先将垫付BUG修复掉）
  update TEMP_REPAY_USERINFO_V2 tru2
     set borrowid =
         (select b.borrowid
            from xxd_borrow b
           where tru2.userid = b.userid
             and tru2.timelimit = b.timelimit
             and b.account = tru2.account
             AND tru2.successtime = b.successtime
             and tru2.addtime = b.addtime
             and b.status = 5),
         flag     = 10,
         remark   = '线上数据已经还款完毕'
   where tru2.flag = 0 and  exists(select b.borrowid
            from xxd_borrow b
           where tru2.userid = b.userid
             and tru2.timelimit = b.timelimit
             and b.account = tru2.account
             AND tru2.successtime = b.successtime
             and tru2.addtime = b.addtime
             and b.status = 5) ;


  --插入对应表结构
  update TEMP_REPAY_USERINFO_V2 tru2
     set borrowid =
         (select b.borrowid
            from xxd_borrow b
           where tru2.userid = b.userid
             and tru2.timelimit = b.timelimit
             and b.account = tru2.account
             AND tru2.successtime = b.successtime
             and tru2.addtime = b.addtime
             and b.status = 4)
   where tru2.flag = 0 and  exists(select b.borrowid
            from xxd_borrow b
           where tru2.userid = b.userid
             and tru2.timelimit = b.timelimit
             and b.account = tru2.account
             AND tru2.successtime = b.successtime
             and tru2.addtime = b.addtime
             and b.status = 4) ;

  --循环根据标的进行还款操作
  open cursor_ru_v2;
  loop
    fetch cursor_ru_v2
      into row_cursor_ru_v2;
    exit when cursor_ru_v2%NOTFOUND;

    if row_cursor_ru_v2.borrowid is not null   then
    sp_temp_repay_supplement_v2(row_cursor_ru_v2.Borrowid,
                                row_cursor_ru_v2.Userid,
                                row_cursor_ru_v2.offlinerepaypord,
                                P_RESULT);

   end if;


  end loop;
  CLOSE cursor_ru_v2;
END;

/
