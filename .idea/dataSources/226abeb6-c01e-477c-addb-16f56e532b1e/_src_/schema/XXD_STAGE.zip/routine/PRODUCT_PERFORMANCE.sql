CREATE procedure product_performance(in_date date)
is
v_in_date date:=in_date;
cursor ck is
select stepquitid,userid,stepjoinid,quitaccount outaccount,addtime from xxd_step_quit
where addtime>=trunc(v_in_date)-1 and addtime<trunc(v_in_date);

ck_rec ck%rowtype;
servicenum varchar2(20);
empid number;

begin

execute immediate 'truncate table  xxd_product_temp';


insert into xxd_product_temp(indate,tradeid,userid,productcode,productname,tradenum,innum,outnum,CREATEDATE,servicenum,employeeid)
select
trunc(a.addtime)，
a.stepjoinid,a.userid,'96','步步高升',a.account,a.account,0,a.addtime,b.servicenum,b.employeeid
from xxd_step_join a left join tb_order_record b
on a.stepjoinid =b.orderno
where a.addtime>=trunc(v_in_date)-1 and a.addtime<trunc(v_in_date)
union all
select indate,tradeid,userid,productcode,productname,tradenum,innum,outnum,CREATEDATE,servicenum,employeeid
from xxd_product_daily
where indate=trunc(v_in_date)-2
and tradenum>0;

commit;

open ck;
  loop
    fetch ck into  ck_rec;
    exit when ck%notfound;

update xxd_product_temp set outnum=outnum+ck_rec.outaccount,tradenum=tradenum-ck_rec.outaccount where tradeid=ck_rec.stepjoinid;


insert into xxd_product_out(id,outtradeid,userid,productcode,productname,outtradenum,tradeid,tradenum,CREATEDATE,servicenum,employeeid)
select seq_product_out.nextval,ck_rec.stepquitid,ck_rec.userid,'96','步步高升',ck_rec.outaccount,ck_rec.stepjoinid,ck_rec.outaccount,ck_rec.addtime,servicenum,employeeid

from
xxd_product_temp  where tradeid=ck_rec.stepjoinid;


commit;

    end loop;
    close ck;

insert into xxd_product_daily(id,indate,tradeid,userid,productcode,productname,tradenum,innum,outnum,CREATEDATE,servicenum,employeeid)
select seq_product_daily.nextval,trunc(v_in_date)-1,tradeid,userid,productcode,productname,tradenum,innum,outnum,CREATEDATE,servicenum,employeeid from xxd_product_temp;


commit;
end;

/
