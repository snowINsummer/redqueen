CREATE function fn_random
return number
as
begin
  return dbms_random.value;
end;



/
