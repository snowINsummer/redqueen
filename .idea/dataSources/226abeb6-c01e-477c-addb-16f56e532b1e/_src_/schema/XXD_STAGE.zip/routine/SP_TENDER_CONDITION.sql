CREATE procedure SP_TENDER_CONDITION(L_ADDTYPE    in nvarchar2, --week，month
                                                L_createtime in date) is

  P_startdate date;
  P_enddate   date;

begin
  if L_ADDTYPE = 'WEEK' then

    P_startdate := trunc(L_createtime - 7);
    P_enddate   := trunc(L_createtime);

  end if;

  if L_ADDTYPE = 'MONTH' then

    P_startdate := to_date(to_char(add_months(L_createtime, -1), 'YYYYMM'),
                           'YYYYMM'); ---上月初

    P_enddate := to_date(to_char(L_createtime, 'YYYYMM'), 'YYYYMM'); ---本月初

  end if;

  --------------------------统计投资情况---------------------------------
  ---part1 非新元宝部分
  insert into temp_tender_Condition
    select xxd_borrow_tender.userid,
           xxd_borrow_tenderdetail.addtime,
           case
             when xxd_borrow_tenderdetail.terminalver like '%PC%' or
                  xxd_borrow_tenderdetail.terminalver like '%pc%' or
                  xxd_borrow_tenderdetail.terminalver like '%DATATRANS%' then
              '官网'
             when xxd_borrow_tenderdetail.terminalver like
                  '%type":"mobile","user-agent":"XXDIOS%' or
                  xxd_borrow_tenderdetail.terminalver like
                  '%{"type":"mobile","user-agent":"iphone"}%' then
              'IOS（客户端）'
             when xxd_borrow_tenderdetail.terminalver like
                  '%type":"mobile","user-agent":"android%' or
                  xxd_borrow_tenderdetail.terminalver like
                  '%{"type":"mobile","user-agent":"Apache-HttpClient/UNAVAILABLE (java 1.4)"}%' then
              'Android（客户端）'
             when xxd_borrow_tenderdetail.terminalver like '%WEB-APP%' then
              'webapp'
             when xxd_borrow_tenderdetail.terminalver like
                  '%{"type":"mobile"}%' then
              '手机端'
             else
              '其它（主要为无记录）'
           end platform,
           case
             when xxd_borrow.type = 9 then
              '新商贷'
             when xxd_borrow.type = 12 then
              '新网贷'
             when xxd_borrow.type = 11 then
              '菁英贷'
             when xxd_borrow.type = 8 then
              '新生贷'
             when xxd_borrow.type = 13 then
              '票小宝'
             when xxd_borrow.type = 10 then
              '新房贷'
           end as products,
           xxd_borrow.apr || '%' as apr,
           xxd_borrow.timelimit as term,
           xxd_borrow_tender.tenderid as transno,
           xxd_borrow_tenderdetail.effectivemoney as amount,
           case
             when xxd_borrow_tender.status = 1 and
                  xxd_borrow_tender.tenderid not in
                  (select xxd_trade_request.tenderid
                     from xxd_trade_pack, xxd_trade_request
                    where xxd_trade_pack.requestid =
                          xxd_trade_request.requestid
                      and xxd_trade_request.status = 2) then
              '投资中'
             when xxd_borrow_tender.status = 1 and
                  xxd_borrow_tender.tenderid in
                  (select xxd_trade_request.tenderid
                     from xxd_trade_pack, xxd_trade_request
                    where xxd_trade_pack.requestid =
                          xxd_trade_request.requestid
                      and xxd_trade_request.status = 2) then
              '债权转让'
             when xxd_borrow_tender.status = 2 then
              '已结束'
           end as status,
           trunc(L_createtime) as createtime,
           P_startdate as startdate,
           P_enddate - 1 as enddate,
           L_ADDTYPE as addtype
      from xxd_borrow_tender, xxd_borrow_tenderdetail, xxd_borrow
     where xxd_borrow_tender.tenderid = xxd_borrow_tenderdetail.tenderid
       and xxd_borrow_tender.borrowid = xxd_borrow.borrowid
       and xxd_borrow_tender.status in (1, 2)
       and xxd_borrow_tender.isoptimize = 0
       and xxd_borrow.type in (8, 9, 10, 11, 12, 13)
       and xxd_borrow_tender.userid not in
           (select Xxd_Vip_Appro.Userid
              from Xxd_Vip_Appro
             where (upper(Xxd_Vip_Appro.Servicenum) like '%FD%' or
                   upper(Xxd_Vip_Appro.Servicenum) like '%XXD%')
               and Xxd_Vip_Appro.Servicenum not in
                   ('XXD00673',
                    'XXD00676',
                    'XXD0318',
                    'XXD00675',
                    'XXD00698',
                    'XXD00692',
                    'XXD00602')
               and Xxd_Vip_Appro.Status = 1)
       and xxd_borrow_tenderdetail.addtime >= P_startdate
       and xxd_borrow_tenderdetail.addtime < P_enddate
    union
    ----part2 新元宝部分， Windows iPhone iPad XXDIOS  pc   Mac OS auto  Android  UCWEB
    select xxd_optimize_userscheme.userid,
           xxd_optimize_userscheme.addtime,
           case
             when xxd_optimize_userdetail.terminalver like '%Windows%' or
                  xxd_optimize_userdetail.terminalver like '%pc%' then
              'PC端'
             when xxd_optimize_userdetail.terminalver like '%iPhone%' or
                  xxd_optimize_userdetail.terminalver like '%iPad%' or
                  xxd_optimize_userdetail.terminalver like '%XXDIOS%' or
                  xxd_optimize_userdetail.terminalver like '%Mac OS%'

              then
              'IOS端'
             when xxd_optimize_userdetail.terminalver like '%Android%' then
              'Android端'
             else
              xxd_optimize_userdetail.terminalver
           end as platform,
           '新元宝' as products,
           xxd_optimize_scheme.minapr || '%-' || xxd_optimize_scheme.maxapr || '%' as apr,
           xxd_optimize_scheme.CLOSETERM as term,
           xxd_optimize_userscheme.userschemeid as transno,
           xxd_optimize_userdetail.account as amount,
           case
             when xxd_optimize_userscheme.status = 1 then
              '投资中'
             when xxd_optimize_userscheme.status = 6 then
              '强行退出'
             when xxd_optimize_userscheme.status = 7 then
              '到期结束'
           end as status,
           trunc(L_createtime) as createtime,
           P_startdate as startdate,
           P_enddate - 1 as enddate,
           L_ADDTYPE as addtype
      from xxd_optimize_userscheme,
           xxd_optimize_userdetail,
           xxd_optimize_scheme
     where xxd_optimize_scheme.schemeid = xxd_optimize_userscheme.schemeid
       and xxd_optimize_userscheme.userschemeid =
           xxd_optimize_userdetail.userschemeid
       and xxd_optimize_userscheme.userid not in
           (select Xxd_Vip_Appro.Userid
              from Xxd_Vip_Appro
             where (upper(Xxd_Vip_Appro.Servicenum) like '%FD%' or
                   upper(Xxd_Vip_Appro.Servicenum) like '%XXD%')
               and Xxd_Vip_Appro.Servicenum not in
                   ('XXD00673',
                    'XXD00676',
                    'XXD0318',
                    'XXD00675',
                    'XXD00698',
                    'XXD00692',
                    'XXD00602')
               and xxd_vip_appro.status = 1)
       and xxd_optimize_userscheme.status in (1, 6, 7)
       and xxd_optimize_userscheme.addtime >= P_startdate
       and xxd_optimize_userscheme.addtime < P_enddate;

  commit;

  ---------------------债权转让---------------------------------------
  insert into temp_trade_Condition
    select xxd_trade_pack.userid,
           '买入' IO,
           decode(xxd_trade_pack.INMETHOD, 1, '散标买入', 2, '新元宝买入') METHOD,
           xxd_trade_pack.addtime,
           case
             when xxd_borrow.type = 9 then
              '新商贷'
             when xxd_borrow.type = 12 then
              '新网贷'
             when xxd_borrow.type = 11 then
              '菁英贷'
             when xxd_borrow.type = 8 then
              '新生贷'
             when xxd_borrow.type = 13 then
              '票小宝'
             when xxd_borrow.type = 10 then
              '新房贷'
           end as products,
           xxd_borrow.apr || '%' apr,
           xxd_borrow_tender.tenderid,
           xxd_borrow.timelimit,
           xxd_trade_pack.terms,
           xxd_trade_request.amount,
           xxd_trade_request.FUNDS,
           case
             when xxd_borrow_tender.status = 1 and
                  xxd_borrow_tender.CURUSERID = xxd_trade_pack.userid then
              '投资中'
             when xxd_borrow_tender.status = 1 and
                  xxd_borrow_tender.CURUSERID <> xxd_trade_pack.userid then
              '债权转让'
             when xxd_borrow_tender.status = 2 then
              '已结束'
           end as status,
           trunc(L_createtime) as createtime,
           P_startdate as startdate,
           P_enddate - 1 as enddate,
           L_ADDTYPE as addtype
      from xxd_trade_pack, xxd_trade_request, xxd_borrow_tender, xxd_borrow
     where xxd_trade_pack.requestid = xxd_trade_request.requestid
       and xxd_trade_request.tenderid = xxd_borrow_tender.tenderid
       and xxd_borrow_tender.borrowid = xxd_borrow.borrowid
       and xxd_borrow.type in (8, 9, 10, 11, 12, 13)
       and xxd_trade_pack.userid not in
           (select Xxd_Vip_Appro.Userid
              from Xxd_Vip_Appro
             where (upper(Xxd_Vip_Appro.Servicenum) like '%FD%' or
                   upper(Xxd_Vip_Appro.Servicenum) like '%XXD%')
               and Xxd_Vip_Appro.Servicenum not in
                   ('XXD00673',
                    'XXD00676',
                    'XXD0318',
                    'XXD00675',
                    'XXD00698',
                    'XXD00692',
                    'XXD00602')
               and xxd_vip_appro.status = 1)
          --and xxd_trade_request.REQMETHOD=1 --2系统发起卖出，及新元宝自动转让退出
       and xxd_trade_pack.inmethod = 1 --2新元宝买入，及新元宝自动转让买入
          /*and xxd_borrow_tender.schemeid not in
           ( select xxd_optimize_userscheme.schemeid from xxd_optimize_userscheme where xxd_optimize_userscheme.status=7
          )*/
       and xxd_trade_pack.addtime >= P_startdate
       and xxd_trade_pack.addtime < P_enddate
    --and xxd_borrow_tender.isoptimize = 0
    --and xxd_trade_pack.INMETHOD=1
    union
    select xxd_trade_request.userid,
           '卖出' IO,
           decode(xxd_trade_request.REQMETHOD, 1, '用户发起', 2, '系统发起') METHOD,
           xxd_trade_pack.addtime,
           case
             when xxd_borrow.type = 9 then
              '新商贷'
             when xxd_borrow.type = 12 then
              '新网贷'
             when xxd_borrow.type = 11 then
              '菁英贷'
             when xxd_borrow.type = 8 then
              '新生贷'
             when xxd_borrow.type = 13 then
              '票小宝'
             when xxd_borrow.type = 10 then
              '新房贷'
           end as products,
           xxd_borrow.apr || '%',
           xxd_borrow_tender.tenderid,
           xxd_borrow.timelimit,
           xxd_trade_pack.terms,
           xxd_trade_request.amount,
           xxd_trade_request.FUNDS,
           case
             when xxd_borrow_tender.status = 1 then
              '投资中'
             when xxd_borrow_tender.status = 2 then
              '已结束'
           end as status,
           trunc(L_createtime) as createtime,
           P_startdate as startdate,
           P_enddate - 1 as enddate,
           L_ADDTYPE as addtype
      from xxd_trade_pack, xxd_trade_request, xxd_borrow_tender, xxd_borrow
     where xxd_trade_pack.requestid = xxd_trade_request.requestid
       and xxd_trade_request.tenderid = xxd_borrow_tender.tenderid
       and xxd_borrow_tender.borrowid = xxd_borrow.borrowid
       and xxd_borrow.type in (8, 9, 10, 11, 12, 13)
       and xxd_trade_request.userid not in
           (select Xxd_Vip_Appro.Userid
              from Xxd_Vip_Appro
             where (upper(Xxd_Vip_Appro.Servicenum) like '%FD%' or
                   upper(Xxd_Vip_Appro.Servicenum) like '%XXD%')
               and Xxd_Vip_Appro.Servicenum not in
                   ('XXD00673',
                    'XXD00676',
                    'XXD0318',
                    'XXD00675',
                    'XXD00698',
                    'XXD00692',
                    'XXD00602')
               and xxd_vip_appro.status = 1)
       and xxd_trade_request.REQMETHOD = 1 --2系统发起卖出，及新元宝自动转让退出
          --and xxd_trade_pack.inmethod=1     --2新元宝买入，及新元宝自动转让买入
          /* and xxd_borrow_tender.schemeid not in
           ( select xxd_optimize_userscheme.schemeid from xxd_optimize_userscheme where xxd_optimize_userscheme.status=7
          )*/
       and xxd_trade_pack.addtime >= P_startdate
       and xxd_trade_pack.addtime < P_enddate;

  commit;

  --------插入用户信息-----------------
  insert into temp_tender_user
    select xxd_user.userid,
           xxd_user.username,
           xxd_realname_appro_w.realname,
           xxd_user.mobile,
           xxd_user_baseinfo.birthday,
           decode(xxd_user_baseinfo.gender, 1, '男', 0, '女') gender,
           xxd_user.email,
           xxd_user_baseinfo.NATIVEPLACE,
           Xxd_Vip_Appro_w.SERVICENUM,
           xxd_user.expiredate,
           decode(xxd_user.REGSOURCE,
                  1,
                  '网站注册',
                  2,
                  '手机客户端注册',
                  3,
                  '合作商户注册',
                  4,
                  '合作商户导入',
                  5,
                  '微信注册',
                  6,
                  '移动网页注册',
                  7,
                  'WEBAPP') REGSOURCE,
           xxd_user.addip,
           tt.createtime,
           tt.addtype
      from xxd_user,
           (select userid, realname from xxd_realname_appro where status = 1) xxd_realname_appro_w,
           xxd_user_baseinfo,
           (select Userid, SERVICENUM from Xxd_Vip_Appro where status = 1) Xxd_Vip_Appro_w,
           (select distinct Userid, Createtime, addtype
              from temp_tender_Condition
             where temp_tender_Condition.Createtime =
                   to_date(to_char(L_createtime, 'YYYYMMDD'), 'YYYYMMDD')
               and temp_tender_Condition.Addtype = L_ADDTYPE
            union
            select distinct Userid, Createtime, addtype
              from temp_trade_Condition
             where temp_trade_Condition.Createtime =
                   to_date(to_char(L_createtime, 'YYYYMMDD'), 'YYYYMMDD')
               and temp_trade_Condition.Addtype = L_ADDTYPE) tt
     where xxd_user.userid = xxd_realname_appro_w.userid(+)
       and xxd_user.userid = xxd_user_baseinfo.userid(+)
       and xxd_user.userid = Xxd_Vip_Appro_w.Userid(+)
       and xxd_user.userid = tt.userid;

  commit;

end SP_TENDER_CONDITION;

/
