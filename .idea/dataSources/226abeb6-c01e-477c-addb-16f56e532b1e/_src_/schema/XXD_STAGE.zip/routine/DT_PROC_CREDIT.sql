CREATE procedure DT_PROC_CREDIT is
  -- 积分，新新币，信用，
  CURSOR cur_levels IS
    SELECT * from xxdai_levels;
  row_cur_levels cur_levels%rowtype;
  -- 积分，新新币，信用 日志
  CURSOR cur_level_logs IS
    SELECT * from xxdai_level_logs;
  row_cur_level_logs cur_level_logs%rowtype;
  --  用户信用材料（线下材料）
  CURSOR cur_user_creditstuff IS
    SELECT * from xxdai_user_creditstuff;
  row_cur_user_creditstuff cur_user_creditstuff%rowtype;
  --  用户信用材料（线下材料）字典
  CURSOR cur_user_creditstuff_dic IS
    SELECT * from xxdai_user_creditstuff_dic;
  row_cur_user_creditstuff_dic cur_user_creditstuff_dic%rowtype;

  --计数变量
  m_count INTEGER;

begin
  -- levels
  execute immediate 'truncate table xxd_levels';
  OPEN cur_levels;
  m_count := 0;
  loop
    m_count := m_count + 1;
    FETCH cur_levels
      INTO row_cur_levels;
    exit when cur_levels%notfound;
         INSERT INTO xxd_levels
                     (USERID,   COINS,   CREDITlevel,   CREDITINTEGRAL,
                     INVESTlevel,   INVESTINTEGRAL     )
              VALUES
                    (row_cur_levels.USERID,   row_cur_levels.COINS,   nvl(row_cur_levels.CREDITlevel, ' '),   row_cur_levels.CREDITINTEGRAL,
                    nvl(row_cur_levels.INVESTlevel, ' '),   row_cur_levels.INVESTINTEGRAL);
   if mod(m_count,5000)=0 then
      commit;
   end if;
   end loop;
   commit;
   close cur_levels;

  --  积分，新新币，信用
  execute immediate 'truncate table xxd_level_logs';
  OPEN cur_level_logs;
  m_count:= 0;
  loop
    m_count:= m_count+1;
    FETCH cur_level_logs
     INTO row_cur_level_logs;
     exit when cur_level_logs%notfound;
         INSERT INTO xxd_level_logs
                     (ID,BUSIID,USERID,CHANGETIME,
                     CHANGEIP,CHANGENUM,CHANGEHOW,CHANGETYPE,
                     REMARK,OPERATOR)
              VALUES
                   (row_cur_level_logs.ID,  0,row_cur_level_logs.USERID,  from_unixtime(row_cur_level_logs.CHANGETIME),
                   row_cur_level_logs.CHANGEIP,  row_cur_level_logs.CHANGENUM,  row_cur_level_logs.CHANGEHOW,  row_cur_level_logs.CHANGETYPE,
                   row_cur_level_logs.REMARK,  NULL);
  if mod(m_count,5000)=0 then
      commit;
  end if;
  end loop;
  commit;
  update XXD_LEVEL_LOGS a set a.col_a =1 ,a.col_a_note = '投资成功增加新新币' where a.col_a is null and a.changetype = 'xinxincoin' and a.REMARK  like '%投资成功增加新新币%';
    commit;
  update XXD_LEVEL_LOGS a set a.col_a =1 ,a.col_a_note = '管理员调整增加新新币' where a.col_a is null and a.changetype = 'xinxincoin' and a.remark like '%管理员%';
   commit;
  update XXD_LEVEL_LOGS a set a.col_a = 3 ,a.col_a_note = '新新币兑换' where a.col_a is null and a.changetype = 'xinxincoin' and a.remark like '%新新币兑换%' ;
   commit;
  update XXD_LEVEL_LOGS a set a.col_a =3 ,a.col_a_note = '新新贷商城消费新新币' where a.col_a is null and a.changetype = 'xinxincoin' and a.remark like '%新新贷商城消费新新币%' ;
   commit;
  update XXD_LEVEL_LOGS a set a.col_a =3 ,a.col_a_note = '新新商城消费新新币' where a.col_a is null and a.changetype = 'xinxincoin' and a.remark like '%新新商城消费新新币%' ;
   commit;
  update XXD_LEVEL_LOGS a set a.col_a =1 ,a.col_a_note = '新新贷商城订单被驳回' where a.col_a is null and a.changetype = 'xinxincoin' and a.remark like '%新新贷商城订单被驳回%' ;
   commit;
  update XXD_LEVEL_LOGS a set a.col_a =3 ,a.col_a_note = '商城购物新新币支付' where a.col_a is null and a.changetype = 'xinxincoin' and a.remark like '%商城购物新新币支付%' ;
   commit;
  update XXD_LEVEL_LOGS a set a.col_a =1 ,a.col_a_note = '系统退还：商城消费失败退还新新币' where a.col_a is null and a.changetype = 'xinxincoin' and a.remark like '系统退还：商城消费失败退还新新币%' ;
   commit;
  update XXD_LEVEL_LOGS a set a.col_a =1 ,a.col_a_note = '订单xxc_手机充值__14151驳回' where a.col_a is null and a.changetype = 'xinxincoin' and a.remark like '订单xxc_手机充值__14151驳回%' ;
   commit;
  update XXD_LEVEL_LOGS a set a.col_a =1 ,a.col_a_note = '新新商城购物，赠送新新币' where a.col_a is null and a.changetype = 'xinxincoin' and a.remark like '新新商城购物，赠送新新币%' ;
   commit;
  update XXD_LEVEL_LOGS a set a.changehow=a.col_a where a.changetype = 'xinxincoin';

  commit;
  close cur_level_logs;

  --  用户信用材料（线下材料）字典
  execute immediate 'truncate table xxd_user_creditstuff_dic';
  OPEN cur_user_creditstuff_dic;
  m_count:= 0;
  loop
    m_count:= m_count+1;
    FETCH cur_user_creditstuff_dic
     INTO row_cur_user_creditstuff_dic;
     exit when cur_user_creditstuff_dic%notfound;
        INSERT INTO xxd_user_creditstuff_dic
               (ID,KEYID,PNAME,SCORE,
               TYPE,NOTES,STATUS,ADDTIME,
               CREATOR,ADDIP)
        VALUES
             (row_cur_user_creditstuff_dic.ID,row_cur_user_creditstuff_dic.KEYID,row_cur_user_creditstuff_dic.PNAME,row_cur_user_creditstuff_dic.SCORE,
             row_cur_user_creditstuff_dic.TYPE,row_cur_user_creditstuff_dic.NOTES,row_cur_user_creditstuff_dic.STATUS,from_unixtime(row_cur_user_creditstuff_dic.ADDTIME),
             row_cur_user_creditstuff_dic.CREATOR,row_cur_user_creditstuff_dic.ADDIP);

  end loop;
  commit;
  close cur_user_creditstuff_dic;

  -- 用户信用材料（线下材料）
  execute immediate 'truncate table xxd_user_creditstuff';
  OPEN cur_user_creditstuff;
  m_count:= 0;
  loop
    m_count:= m_count+1;
    FETCH cur_user_creditstuff
     INTO row_cur_user_creditstuff;
     exit when cur_user_creditstuff%notfound;
     INSERT INTO xxd_user_creditstuff
                 (ID,    userid,  keyid,  status,
                 score,  addtime,  creator,  modifydate,
                 lastmodify)
          VALUES
               (row_cur_user_creditstuff.ID,row_cur_user_creditstuff.USERID,row_cur_user_creditstuff.KEYID,row_cur_user_creditstuff.STATUS,
               0,from_unixtime(row_cur_user_creditstuff.ADDTIME),row_cur_user_creditstuff.CREATOR,from_unixtime(row_cur_user_creditstuff.MODIFYDATE),
               row_cur_user_creditstuff.LASTMODIFY);
  end loop;
  commit;
  close cur_user_creditstuff;
end DT_PROC_CREDIT;



/
