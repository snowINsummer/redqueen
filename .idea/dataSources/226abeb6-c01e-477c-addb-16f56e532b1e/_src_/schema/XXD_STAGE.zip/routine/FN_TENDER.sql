CREATE function          fn_tender(TERMIN in varchar2) return varchar2 is
--  create by luzhongjie   20150811
  TERMINALVER varchar2(4000);
-- 返回结果集
  btype varchar2(40);
begin
  TERMINALVER:=TERMIN;
   if TERMINALVER like '%WEB-APP%' then if TERMINALVER like '%Android%' then btype :='webappandroid';
                                      else btype :='webappios';
                                       end if;
elsif TERMINALVER like '%mobile%' then if TERMINALVER like '%android%' then btype :='android';
                                    elsif TERMINALVER like '%IOS%' or TERMINALVER like '%iphone%' then btype :='IOS';
                                     else btype :='mobile';
                                      end if;
 else btype :='PC';
  end if;
return btype;
end;
/
