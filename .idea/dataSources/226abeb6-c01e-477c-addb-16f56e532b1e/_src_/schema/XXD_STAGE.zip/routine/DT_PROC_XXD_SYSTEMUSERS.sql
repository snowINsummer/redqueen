CREATE procedure dt_proc_xxd_systemusers is
  --部门信息表
  cursor cur_xxd_department is  select
  t.ID,t.DEPNO,t.DEPNAME,t.PARENTDEPNO,t.PRINCIPAL
  from xxdai_department t ;
 row_cur_xxd_department cur_xxd_department%rowtype;
 --职位信息表
 cursor cur_xxd_position is  select
  t.id,t.positname,t.department,t.positno
  from xxdai_position t ;
 row_cur_xxd_position cur_xxd_position%rowtype;
 --员工信息表
 cursor cur_xxd_employee is
  select t.ID,t.NAME,t.JOBNUM,t.DEPARTMENT,t.POSITION,t.PHONENUM,t.EMAIL,t.ENTRYDATE,t.LOGINPASSWORD,t.SAFEPASSWORD,t.SERVICENUM,c.id c_id,t.ADDTIME,h.id h_id
  from
   xxdai_employee t,
  (select max(id) id,name from  xxdai_employee group by name) c,
  (select max(id) id,name from  xxdai_employee group by name) h
  where t.superior=c.name(+) and t.adder=h.name(+);
 row_cur_xxd_employee cur_xxd_employee%rowtype;



 m_count  integer;--提交计数器
begin
  --处理部门信息表
  delete from xxd_department t;
  commit;
  open cur_xxd_department;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_xxd_department
      into row_cur_xxd_department;
    exit when cur_xxd_department%notfound;
    insert into  xxd_department
    (ID,DEPNO,DEPNAME,PARENTDEPNO,PRINCIPAL
     )
    values
      (row_cur_xxd_department.ID,row_cur_xxd_department.DEPNO,row_cur_xxd_department.DEPNAME,row_cur_xxd_department.PARENTDEPNO,row_cur_xxd_department.PRINCIPAL
      );
     if mod(m_count,2000)=0 then
     commit;
     end if;
  end loop;
  commit;
  close cur_xxd_department;
 --处理职位信息表
  delete from xxd_position t;
  commit;
  open cur_xxd_position;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_xxd_position
      into row_cur_xxd_position;
    exit when cur_xxd_position%notfound;
    insert into  xxd_position
    (id,positName,department,positNo
     )
    values
      (row_cur_xxd_position.ID,row_cur_xxd_position.POSITNAME,row_cur_xxd_position.DEPARTMENT,row_cur_xxd_position.POSITNO
      );
     if mod(m_count,2000)=0 then
     commit;
     end if;
  end loop;
  commit;
  close cur_xxd_position;
  --处理员工信息表
  delete from xxd_employee t;
  commit;
  --处理1
  open cur_xxd_employee;
  m_count:=0;
-- i:=0;
  loop
    m_count:=m_count+1;
--     i:=i+1;
    fetch cur_xxd_employee
      into row_cur_xxd_employee;
    exit when cur_xxd_employee%notfound;
    insert into  xxd_employee
    (EMPLOYEEID,     NAME,      JOBNUM,       DEPARTMENTID,   POSITION,
     PHONENUM,      EMAIL,      ENTRYDATE,      PASSWORD,   SAFEPASSWORD,
     SERVICENUM,  SUPERVISOR,   LASTLOGIN,    CREATEDATE,     CREATOR,
     MODIFIEDDATE,     MODIFER
     )
    values
      (row_cur_xxd_employee.id,            row_cur_xxd_employee.NAME,                                       row_cur_xxd_employee.JOBNUM,                             row_cur_xxd_employee.DEPARTMENT,       row_cur_xxd_employee.POSITION,
      row_cur_xxd_employee.PHONENUM,       row_cur_xxd_employee.EMAIL,       nvl(FROM_UNIXTIME(row_cur_xxd_employee.ENTRYDATE),sysdate),                          row_cur_xxd_employee.LOGINPASSWORD,    row_cur_xxd_employee.SAFEPASSWORD,
      row_cur_xxd_employee.SERVICENUM,     nvl(row_cur_xxd_employee.c_id,null),                                                   sysdate,     nvl(FROM_UNIXTIME(row_cur_xxd_employee.ADDTIME),sysdate),    nvl(row_cur_xxd_employee.h_id,0),
      sysdate,0
      );
     if mod(m_count,2000)=0 then
     commit;
     end if;
  end loop;
  commit;
  close cur_xxd_employee;

update xxd_employee set supervisor=453 where employeeid=494;
update xxd_employee set supervisor=453 where employeeid=769;
update xxd_employee set supervisor=453 where employeeid=520;
update xxd_employee set supervisor=453 where employeeid=454;
update xxd_employee set supervisor=453 where employeeid=770;
update xxd_employee set supervisor=453 where employeeid=771;
update xxd_employee set supervisor=453 where employeeid=432;
update xxd_employee set supervisor=453 where employeeid=727;
update xxd_employee set supervisor=453 where employeeid=728;
update xxd_employee set supervisor=453 where employeeid=745;
update xxd_employee set supervisor=737 where employeeid=792;
update xxd_employee set supervisor=737 where employeeid=797;
update xxd_employee set supervisor=737 where employeeid=506;
update xxd_employee set supervisor=737 where employeeid=507;
update xxd_employee set supervisor=737 where employeeid=508;
update xxd_employee set supervisor=755 where employeeid=726;
update xxd_employee set supervisor=755 where employeeid=510;
update xxd_employee set supervisor=755 where employeeid=512;
update xxd_employee set supervisor=755 where employeeid=518;
update xxd_employee set supervisor=453 where employeeid=435;
update xxd_employee set supervisor=435 where employeeid=438;
update xxd_employee set supervisor=435 where employeeid=737;
update xxd_employee set supervisor=435 where employeeid=755;
update xxd_employee set supervisor=435 where employeeid=633;
update xxd_employee set supervisor=435 where employeeid=750;
update xxd_employee set supervisor=435 where employeeid=752;
update xxd_employee set supervisor=435 where employeeid=816;
update xxd_employee set supervisor=435 where employeeid=597;
update xxd_employee set supervisor=435 where employeeid=598;
update xxd_employee set supervisor=435 where employeeid=599;
update xxd_employee set supervisor=435 where employeeid=600;
update xxd_employee set supervisor=435 where employeeid=614;
update xxd_employee set supervisor=435 where employeeid=617;
update xxd_employee set supervisor=435 where employeeid=619;
update xxd_employee set supervisor=435 where employeeid=622;
update xxd_employee set supervisor=435 where employeeid=629;
update xxd_employee set supervisor=435 where employeeid=920;
update xxd_employee set supervisor=435 where employeeid=922;
update xxd_employee set supervisor=435 where employeeid=944;
update xxd_employee set supervisor=736 where employeeid=740;
update xxd_employee set supervisor=736 where employeeid=746;
update xxd_employee set supervisor=736 where employeeid=747;
update xxd_employee set supervisor=736 where employeeid=754;
update xxd_employee set supervisor=736 where employeeid=621;
update xxd_employee set supervisor=736 where employeeid=736;
update xxd_employee set supervisor=736 where employeeid=738;
update xxd_employee set supervisor=736 where employeeid=744;
update xxd_employee set supervisor=736 where employeeid=749;
update xxd_employee set supervisor=736 where employeeid=596;
update xxd_employee set supervisor=453 where employeeid=439;
update xxd_employee set supervisor=643 where employeeid=634;
update xxd_employee set supervisor=643 where employeeid=635;
update xxd_employee set supervisor=643 where employeeid=636;
update xxd_employee set supervisor=643 where employeeid=637;
update xxd_employee set supervisor=643 where employeeid=638;
update xxd_employee set supervisor=643 where employeeid=642;
update xxd_employee set supervisor=643 where employeeid=644;
update xxd_employee set supervisor=643 where employeeid=646;
update xxd_employee set supervisor=643 where employeeid=938;
update xxd_employee set supervisor=453 where employeeid=643;
update xxd_employee set supervisor=453 where employeeid=444;
update xxd_employee set supervisor=453 where employeeid=449;
update xxd_employee set supervisor=733 where employeeid=683;
update xxd_employee set supervisor=733 where employeeid=685;
update xxd_employee set supervisor=733 where employeeid=691;
update xxd_employee set supervisor=733 where employeeid=693;
update xxd_employee set supervisor=548 where employeeid=766;
update xxd_employee set supervisor=548 where employeeid=845;
update xxd_employee set supervisor=548 where employeeid=859;
update xxd_employee set supervisor=548 where employeeid=860;
update xxd_employee set supervisor=548 where employeeid=861;
update xxd_employee set supervisor=548 where employeeid=862;
update xxd_employee set supervisor=548 where employeeid=552;
update xxd_employee set supervisor=548 where employeeid=557;
update xxd_employee set supervisor=548 where employeeid=559;
update xxd_employee set supervisor=548 where employeeid=561;
update xxd_employee set supervisor=548 where employeeid=563;
update xxd_employee set supervisor=548 where employeeid=564;
update xxd_employee set supervisor=548 where employeeid=910;
update xxd_employee set supervisor=548 where employeeid=928;
update xxd_employee set supervisor=548 where employeeid=929;
update xxd_employee set supervisor=548 where employeeid=948;
update xxd_employee set supervisor=548 where employeeid=949;
update xxd_employee set supervisor=453 where employeeid=548;


update xxd_employee set creator=773 where creator=940;
commit;
 -- delete form xxd_employee t where t.supervisor in (441,440,436,437,125,452,442,123,124,451 )

end dt_proc_xxd_systemusers;



/
