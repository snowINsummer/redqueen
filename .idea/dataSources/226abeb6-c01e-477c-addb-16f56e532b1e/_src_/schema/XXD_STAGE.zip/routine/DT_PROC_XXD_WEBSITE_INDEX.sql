CREATE procedure dt_proc_xxd_website_index is
--
cursor cur_xxd_newsnotices is  select
 t.ID,t.TYPENAME,t.STATUS,t.HITS,t.SOURCE,t.TITLE,t.AUTHOR,t.CONTEXT,t.IMGPATH,t.ADDTIME,t.ADDIP,t.UPDATETIME,t.UPIP
  from xxdai_newsnotices t ;--xxd_newsnotices表游标
 row_cur_xxd_newsnotices cur_xxd_newsnotices%rowtype;--xxd_newsnotices表行类型
--
 cursor cur_xxd_newsppt is  select
   t.ID,t.PPTURL,t.URL,t.ISDISPLAY,t.DISORDER,t.POSITION,t.addperson,e.id e_id,t.ADDTIME,t.CATEGORY,t.KEEPWORD1,t.KEEPWORD2,t.KEEPWORD3
   from xxdai_ppt t,(select max(id) id,name from xxdai_employee  group by name)  e where t.addperson=e.name(+) order by t.addperson;--xxd_newsppt表游标
 row_cur_xxd_newsppt  cur_xxd_newsppt%rowtype;--xxd_newsppt表行类型
--
cursor cur_xxd_linkexchange is  select
 t.ID,t.TYPE,t.URL,t.SHOWHINT,t.ANCHOR,t.SEOTEXT,t.PICADDR,t.STATUS,t.PORDER,t.ADDTIME
  from xxdai_lingexchange t ;--xxd_linkexchange表游标
 row_cur_xxd_linkexchange cur_xxd_linkexchange%rowtype;--xxd_linkexchange表行类型
--
 cursor cur_xxd_newsnoticestype is  select
  t.ID,t.NAME,t.VALUE,t.ADDTIME,t.ADDIP
  from xxdai_newsnoticestype t ;--xxd_newsnoticestype表游标
 row_cur_xxd_newsnoticestype cur_xxd_newsnoticestype%rowtype;--xxd_newsnoticestype表行类型
--
 cursor cur_xxd_homepage_Property is  select
 t.ID,   t.TYPE,   t.VALUE,   t.MODIFYTIME,    t.LASTMODIFY
  from xxdai_homepage_Property t ;--xxd_homepage_Property表游标
 row_cur_xxd_homepage_Property cur_xxd_homepage_Property%rowtype;--xxd_homepage_Property表行类型
 --
 cursor cur_xxd_hp_Property_audit is  select
 t.AUDITID,t.AUDITTIME,t.ID,t.TYPE,t.VALUE,t.MODIFYTIME,t.LASTMODIFY
  from xxdai_homepage_Property_audit t ;--xxd_hp_Property_audit表游标
 row_cur_xxd_hp_Property_audit cur_xxd_hp_Property_audit%rowtype;--xxd_hp_Property_audit表行类型
 --
 m_count  integer;--提交计数器
begin
  --处理xxd_newsnotices表
  delete from xxd_newsnotices t;
  commit;
  open cur_xxd_newsnotices;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_xxd_newsnotices
      into row_cur_xxd_newsnotices;
    exit when cur_xxd_newsnotices%notfound;
    insert into  xxd_newsnotices
    (ID,    TYPENAME,    STATUS,     HITS,      SOURCE,
    TITLE,    AUTHOR,   CONTEXT,  IMGPATH,     CREATOR,
    ADDTIME,   ADDIP,  LASTMODIFY,  UPDATETIME,  UPIP)
    values
      (row_cur_xxd_newsnotices.ID,   row_cur_xxd_newsnotices.TYPENAME,      row_cur_xxd_newsnotices.STATUS,       row_cur_xxd_newsnotices.HITS,     row_cur_xxd_newsnotices.SOURCE,
      row_cur_xxd_newsnotices.TITLE,  row_cur_xxd_newsnotices.AUTHOR,       row_cur_xxd_newsnotices.CONTEXT,    row_cur_xxd_newsnotices.IMGPATH,    0,
      nvl(FROM_UNIXTIME(row_cur_xxd_newsnotices.ADDTIME),sysdate),    nvl(row_cur_xxd_newsnotices.ADDIP,'127.0.0.1'),    0,   nvl(FROM_UNIXTIME(row_cur_xxd_newsnotices.UPDATETIME),sysdate),   row_cur_xxd_newsnotices.UPIP);
     if mod(m_count,2000)=0 then
     commit;
     end if;
  end loop;
  update XXD_NEWSNOTICES set context=replace(context,'<img src="http://www.xinxindai.com:80/xxdai_sys_admin/image/data/xheditor_Upload','<img src="http://www.xinxindai.com/static/admin/image/data/xheditor_Upload');
  --处理完后修改了一条数据
  commit;
  close cur_xxd_newsnotices;
--处理xxd_newsppt表
  delete from xxd_newsppt t;
  commit;
  open cur_xxd_newsppt;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_xxd_newsppt
      into row_cur_xxd_newsppt;
    exit when cur_xxd_newsppt%notfound;
    insert into  xxd_newsppt
    (ID,            PPTURL,      URL,      ISDISPLAY,    DISORDER,
    POSITION,    ADDPERSON,    ADDTIME,     CATEGORY,    KEEPWORD1,
    KEEPWORD2,    KEEPWORD3,   CREATOR,   MODIFYTIME,    LASTMODIFY)
    values
      (row_cur_xxd_newsppt.ID,                row_cur_xxd_newsppt.PPTURL,     row_cur_xxd_newsppt.URL,      row_cur_xxd_newsppt.ISDISPLAY,     row_cur_xxd_newsppt.DISORDER,
      row_cur_xxd_newsppt.POSITION,        row_cur_xxd_newsppt.e_id,      nvl(FROM_UNIXTIME(row_cur_xxd_newsppt.ADDTIME),sysdate),    row_cur_xxd_newsppt.CATEGORY,    row_cur_xxd_newsppt.KEEPWORD1,
      row_cur_xxd_newsppt.KEEPWORD2,      row_cur_xxd_newsppt.KEEPWORD3,    0,      sysdate,     0);
     if mod(m_count,1)=0 then
     commit;
     end if;
  end loop;
  commit;
  close cur_xxd_newsppt;
 --处理xxd_linkexchange表
  delete from xxd_linkexchange t;
  commit;
  open cur_xxd_linkexchange;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_xxd_linkexchange
      into row_cur_xxd_linkexchange;
    exit when cur_xxd_linkexchange%notfound;
    insert into  xxd_linkexchange
    (ID,      TYPE,     URL,     SHOWHINT,    ANCHOR,
    SEOTEXT,  PICADDR,   STATUS,   PORDER,   CREATOR,
    ADDTIME,  MODIFYTIME,  LASTMODIFY)
    values
      (row_cur_xxd_linkexchange.ID,         row_cur_xxd_linkexchange.TYPE,     row_cur_xxd_linkexchange.URL,    nvl(row_cur_xxd_linkexchange.SHOWHINT,' '),  row_cur_xxd_linkexchange.ANCHOR,
      row_cur_xxd_linkexchange.SEOTEXT,  row_cur_xxd_linkexchange.PICADDR,  row_cur_xxd_linkexchange.STATUS,     row_cur_xxd_linkexchange.PORDER,     0,
      nvl(FROM_UNIXTIME(row_cur_xxd_linkexchange.ADDTIME),sysdate),     sysdate,    0
      );
     if mod(m_count,2000)=0 then
     commit;
     end if;
  end loop;
  commit;
  close cur_xxd_linkexchange;
----处理xxd_newsnoticestype表
  delete from xxd_newsnoticestype t;
  commit;
  open cur_xxd_newsnoticestype;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_xxd_newsnoticestype
      into row_cur_xxd_newsnoticestype;
    exit when cur_xxd_newsnoticestype%notfound;
    insert into  xxd_newsnoticestype
    (ID,  NAME,  VALUE,  ADDTIME,    ADDIP)
    values
      (row_cur_xxd_newsnoticestype.ID,   row_cur_xxd_newsnoticestype.NAME,    row_cur_xxd_newsnoticestype.VALUE,    nvl(from_unixtime(row_cur_xxd_newsnoticestype.ADDTIME),sysdate),    row_cur_xxd_newsnoticestype.ADDIP);
     if mod(m_count,2000)=0 then
     commit;
     end if;
  end loop;
  commit;
  close cur_xxd_newsnoticestype;
----处理xxd_homepage_Property表
  delete from xxd_homepage_Property t;
  commit;
  open cur_xxd_homepage_Property;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_xxd_homepage_Property
      into row_cur_xxd_homepage_Property;
    exit when cur_xxd_homepage_Property%notfound;
    insert into  xxd_homepage_Property
    (ID, TYPE, VALUE, MODIFYTIME, LASTMODIFY)
    values
      (row_cur_xxd_homepage_Property.ID,    row_cur_xxd_homepage_Property.TYPE,   row_cur_xxd_homepage_Property.VALUE,    nvl(FROM_UNIXTIME(row_cur_xxd_homepage_Property.MODIFYTIME),sysdate),   row_cur_xxd_homepage_Property.LASTMODIFY
      );
     if mod(m_count,2000)=0 then
     commit;
     end if;
  end loop;
  commit;
  close cur_xxd_homepage_Property;
----处理xxd_hp_Property_audit表
  delete from xxd_homepage_Property_audit t;
  commit;
  open cur_xxd_hp_Property_audit;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_xxd_hp_Property_audit
      into row_cur_xxd_hp_Property_audit;
    exit when cur_xxd_hp_Property_audit%notfound;
    insert into  xxd_homepage_Property_audit
    (AUDITID,   AUDITTIME,   ID,   TYPE,   VALUE,    MODIFYTIME,     LASTMODIFY)
    values
      (row_cur_xxd_hp_Property_audit.AUDITID,  nvl(FROM_UNIXTIME(row_cur_xxd_hp_Property_audit.AUDITTIME),sysdate),  row_cur_xxd_hp_Property_audit.ID,   row_cur_xxd_hp_Property_audit.TYPE,   row_cur_xxd_hp_Property_audit.VALUE,
      nvl(FROM_UNIXTIME(row_cur_xxd_hp_Property_audit.MODIFYTIME),sysdate),  row_cur_xxd_hp_Property_audit.LASTMODIFY);
     if mod(m_count,2000)=0 then
     commit;
     end if;
  end loop;
  commit;
  close cur_xxd_hp_Property_audit;
end dt_proc_xxd_website_index;



/
