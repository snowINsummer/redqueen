CREATE function isNumber(p in varchar2) return number is
  result number;
begin
  result := to_number(p);
  if p is null then
    return null;
  else
    return 1;
  end if;
exception
  when VALUE_ERROR then
    return 0;
end;

/
