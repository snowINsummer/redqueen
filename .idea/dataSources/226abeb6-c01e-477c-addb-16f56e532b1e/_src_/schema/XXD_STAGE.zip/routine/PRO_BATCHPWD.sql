CREATE procedure pro_batchpwd is
cursor cur_temp is select t.userid,t.logpwd,t.paypdw from TEMP_USER_PASSWORD_LAST t ;
str_logpwd varchar2(30);
str_paypwd varchar2(30);
num_userid integer;
begin
  open cur_temp;
   loop 
     fetch cur_temp into num_userid,str_logpwd,str_paypwd ;
     exit when cur_temp%notfound;
     update xxd_company t
     set t.property1 =fn_passup(fn_md5(str_logpwd)),
         t.property2 = fn_passup(fn_md5(str_paypwd))
     where t.id = fn_md5(num_userid);
   end loop;
  close cur_temp;
  commit;
end pro_batchpwd;
/
