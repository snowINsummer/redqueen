CREATE procedure SP_TEMP_REPAY_CLEAR is
begin

  /********************************************************
        功能：补录还款之已还数据清零
              1.充值记录，2.还款记录，3.账户日志
        日期：20151019
  ********************************************************/

  ---备份清零前数据
  INSERT INTO XXD_ACCOUNT_CLEAR_BAK
    select *
      from xxd_account
     where userid in (select userid
                        from TEMP_REPAY_USERINFO_RESULT
                       where flag in (1,2,3))
       and pcode = '1001'
       and userid not in (select distinct userid
                            from xxd_borrow_repayment
                           where status = 0)
       AND (usable <> 0 OR frozen <> 0 OR collection <> 0 OR repayment <> 0 OR
           accounttotal <> 0);

  --清零
  update xxd_account
     set usable       = 0,
         frozen       = 0,
         collection   = 0,
         repayment    = 0,
         accounttotal = 0
   where pcode = '1001'
     and exists
   (select userid
            from XXD_ACCOUNT_CLEAR_BAK
           where XXD_ACCOUNT_CLEAR_BAK.userid = xxd_account.userid);

  --日志记录
  INSERT INTO XXD_ACCOUNT_LOG
    (ID,
     USERID,
     PCODE,
     USABLE,
     FROZEN,
     COLLECTION,
     REPAYMENT,
     ADDTIME,
     BUSITIME,
     OPERATORTYPE,
     MONEYTYPE,
     WORKMONEY,
     BUSIID,
     ADDIP,
     ACCOUNTTOTAL,
     SCHEMEID,
     REMARK,
     STATUS,
     ISSHOW)
    select seq_account_log.nextval,
           XXD_ACCOUNT.USERID,
           XXD_ACCOUNT.PCODE,
           XXD_ACCOUNT.USABLE,
           XXD_ACCOUNT.FROZEN,
           XXD_ACCOUNT.COLLECTION,
           XXD_ACCOUNT.REPAYMENT,
           systimestamp,
           sysdate,
           'handle',
           3,
           0,
           xxd_borrow_repayment_w.repaymentid, --充值记录
           '127.0.0.1',
           XXD_ACCOUNT.ACCOUNTTOTAL,
           '0',
           '系统账户调整，结清借款账户',
           0,
           -1
      from XXD_ACCOUNT,
           (select userid, max(repaymentid) repaymentid
              from xxd_borrow_repayment
             group by userid) xxd_borrow_repayment_w,
           XXD_ACCOUNT_CLEAR_BAK
     where XXD_ACCOUNT.userid = xxd_borrow_repayment_w.userid
       and XXD_ACCOUNT.USERID = XXD_ACCOUNT_CLEAR_BAK.userid
       and XXD_ACCOUNT.PCODE = '1001';

end SP_TEMP_REPAY_CLEAR;


/
