CREATE procedure dt_proc_borrow(p_rowcommit  number) is
-- 借款标
cursor cur_borrow is
    select
     *
      from xxdai_borrow t ;
row_cur_borrow cur_borrow%rowtype;
--  标的审核记录
cursor cur_boapproved is
select
   *
 from xxdai_borrow_approved t
 order by t.id;
row_cur_boapproved cur_boapproved%rowtype;

--  待还记录
cursor cur_repayment is
select
   br.*,bo.userid
  from xxdai_borrow_repayment br,
       xxdai_borrow bo
 where br.borrowid = bo.id ;
row_cur_repayment cur_repayment%rowtype;
--  投标记录
cursor  cur_tender is
select
    *
 from xxdai_borrow_tender t
 order by t.id;
row_cur_tender cur_tender%rowtype;
--  待收记录
cursor cur_collection is
select
  t.*,tt.borrowid,
  tt.userid
 from xxdai_borrow_collection t,
      xxdai_borrow_tender tt
where t.tenderid = tt.id order by t.id;
row_cur_collection cur_collection%rowtype;

m_count  integer;--提交计数器
begin
  -- 借款标
  m_count:=0;
  delete from xxd_borrow t;
  commit;
 open  cur_borrow;
 loop
    m_count:=m_count+1;
    fetch cur_borrow into row_cur_borrow;
    exit when cur_borrow%notfound;
     -- dbms_output.put_line(m_count);
     --  dbms_output.put_line(row_cur_borrow.pname);
     insert into xxd_borrow
      (BORROWID,     USERID,        TYPE,            NAME,          CONTENT,
       USE,          ACCOUNT,       APR,             TIMELIMIT,     PAYMENTMETHOD,
       STATUS,       AWARD,         FUNDS,           PORDER,        LOWESTTENDER,
       MOSTTENDER,   BLEVEL,        SHOWLABELID,     PROVINCE,      ADDTIME,
       ADDIP,        ENDTIME,       TENDERTIMES,     ACCOUNTYES,    SUCCESSTIME,
       CASHDEPOSIT,  PAYSNAP)
  SELECT
       row_cur_borrow.id,          row_cur_borrow.userid,   row_cur_borrow.type,        row_cur_borrow.pname,    nvl(row_cur_borrow.content,' '),
       row_cur_borrow.puse,        row_cur_borrow.account,  row_cur_borrow.apr,         row_cur_borrow.timelimit,row_cur_borrow.style,
       row_cur_borrow.status,      row_cur_borrow.award,    row_cur_borrow.funds,       row_cur_borrow.porder,   row_cur_borrow.lowesttender,
       row_cur_borrow.mosttender,  5,                       null,                       null,                    from_unixtime(row_cur_borrow.addtime),
       '127.0.0.1历史',            from_unixtime(row_cur_borrow.addtime+row_cur_borrow.endtime),  row_cur_borrow.tendertimes, row_cur_borrow.accountyes,from_unixtime(row_cur_borrow.successtime),
       row_cur_borrow.depositmoney,row_cur_borrow.is_paysnapsent
  FROM dual;
   if mod(m_count,p_rowcommit)=0 then
        commit;
   end if;
  end loop;
   update xxd_borrow t
    set t.showlabelid = (select decode(bs.showlabelid,'1','7','2','6','3','1','4','2','5','3','6','8',null) from xxdai_borrow_showlabel bs
                                where bs.borrowid =t.borrowid)
   where exists (select '1' from  xxdai_borrow_showlabel bs
   where bs.borrowid =t.borrowid );
  commit;
  close cur_borrow;
  --  借款标审核记录
  delete from xxd_borrow_approved ;
  commit;
  m_count:=0;
  open cur_boapproved;
  loop
     fetch cur_boapproved into row_cur_boapproved;
     exit when cur_boapproved%notfound;
     m_count:= m_count+1;
     insert into xxd_borrow_approved
     (  approveid          ,  borrowid           ,  status             ,
        approveuser1       ,  approvetime1       ,  approveremark1     ,  approveip1         ,
        approveuser2       ,  approvetime2       ,  approveremark2     ,  approveip2         ,
        approveuser3       ,  approvetime3       ,  approveremark3     ,  approveip3         ,
        approveuser4       ,  approvetime4       ,  approveremark4     ,  approveip4         ,
        canceluser         ,  canceltime         ,  cancelremark       ,  cancelip  )
     select
        row_cur_boapproved.id,           row_cur_boapproved.BORROWID,     row_cur_boapproved.STATUS,
        row_cur_boapproved.APPROVEUSER1, from_unixtime(row_cur_boapproved.APPROVETIME1), row_cur_boapproved.APPROVEREMARK1, row_cur_boapproved.APPROVEIP1,
        row_cur_boapproved.APPROVEUSER2, from_unixtime(row_cur_boapproved.APPROVETIME2), row_cur_boapproved.APPROVEREMARK2, row_cur_boapproved.APPROVEIP2,
        row_cur_boapproved.APPROVEUSER3, from_unixtime(row_cur_boapproved.APPROVETIME3), row_cur_boapproved.APPROVEREMARK3, row_cur_boapproved.APPROVEIP3,
        row_cur_boapproved.APPROVEUSER4, from_unixtime(row_cur_boapproved.APPROVETIME4), row_cur_boapproved.APPROVEREMARK4, row_cur_boapproved.APPROVEIP4,
        row_cur_boapproved.CANCELUSER,   from_unixtime(row_cur_boapproved.CANCELTIME),   row_cur_boapproved.CANCELREMARK,   row_cur_boapproved.CANCELIP
     from dual;
     if mod(m_count,p_rowcommit)=0 then
       commit;
     end if;
     commit;
  end loop;
  close cur_boapproved;
  --  借款人待还记录
   delete from xxd_borrow_repayment;
  commit;
  m_count:=0;
  open cur_repayment ;
  loop
  m_count:=m_count+1;
    fetch cur_repayment into row_cur_repayment;
    exit when cur_repayment%notfound;
     insert into xxd_borrow_repayment
     (REPAYMENTID,           BORROWID,             USERID,               PORDER,                REPAYMENTACCOUNT,
      REPAYMENTINTEREST,     REPAYMENTCAPITAL,     REPAYMENTTIME,        STATUS,                REPAYMENTYESTIME,
      REPAYMENTYESACCOUNT,   REPAYMENTYESINTEREST, REPAYMENTYESCAPITAL,  WEBSTATUS,             WEBTIME,
      LATERDAYS,             LATERINTEREST,        PENALSUM,             ISPAYMENT,             ADDTIME,
      ADDIP)
     SELECT
      row_cur_repayment.id,                 row_cur_repayment.borrowid,            row_cur_repayment.userid,                      row_cur_repayment.porder,   row_cur_repayment.repaymentaccount,
      row_cur_repayment.repaymentinterest,  row_cur_repayment.repaymentcapital,    from_unixtime(row_cur_repayment.repaymenttime),row_cur_repayment.status,   from_unixtime(row_cur_repayment.repaymentyestime),
      row_cur_repayment.repaymentyesaccount,row_cur_repayment.repaymentyesinterest,row_cur_repayment.REPAYMENTYESCAPITAL,         row_cur_repayment.webstatus,from_unixtime(row_cur_repayment.webtime),
      row_cur_repayment.laterdays,          row_cur_repayment.laterinterest,       row_cur_repayment.penalsum,                    row_cur_repayment.ispayment,from_unixtime(row_cur_repayment.addtime),
      row_cur_repayment.addip
     FROM dual;
      if mod(m_count,p_rowcommit)=0 then
        commit;
       end if;
  end loop;
  commit;
  close cur_repayment;
  --  投标记录表 投标明细
  delete from xxd_borrow_tender;
  delete from xxd_borrow_tenderdetail;
  commit;
  m_count:=0;
  open cur_tender;
  loop
  m_count:=m_count+1;
     fetch cur_tender into row_cur_tender;
     exit when cur_tender%notfound;
    insert into xxd_borrow_tender
       (  tenderid         ,  borrowid         ,  userid           ,  isoptimize       ,  schemeid         ,
          effectivemoney   ,  addtime          ,  endtime          ,  status           ,  curuserid        ,
          collectamount    ,  collectinterest  ,  collectedamount  ,  collectedinterest,  collectedfine )
    select
         row_cur_tender.id,            row_cur_tender.borrowid,              row_cur_tender.userid,                '0',                  0,
         row_cur_tender.effectivemoney,from_unixtime(row_cur_tender.addtime),from_unixtime(row_cur_tender.endtime),row_cur_tender.status,row_cur_tender.userid,
         row_cur_tender.repaymentaccount,row_cur_tender.repaymentinterest,row_cur_tender.repaymentyesaccount,row_cur_tender.repaymentyesinterest,0
      from dual;
    insert into xxd_borrow_tenderdetail
        (  TENDDETAILID      ,TENDERID          ,MONEY             ,EFFECTIVEMONEY    ,
           TERMINALVER       ,ADDTIME           ,ADDIP             , isautotender)
     select
        'TD'||to_char(from_unixtime(row_cur_tender.addtime),'yyyymmdd')||lpad(SEQ_BORROW_TENDERDETAIL.NEXTVAL,6,'A'),row_cur_tender.id,row_cur_tender.money,row_cur_tender.effectivemoney,
        'DATATRANS'         ,from_unixtime(row_cur_tender.addtime),row_cur_tender.addip,decode(row_cur_tender.addip,'系统自动投标',1,0)
     from dual;
     if mod(m_count,p_rowcommit)=0 then
       commit;
     end if;
  end loop;
    commit;
  close cur_tender;
  --  待收处理
  delete from xxd_borrow_collection;
  commit;
  m_count :=0;
  open cur_collection;
  loop
     m_count:=m_count+1;
     fetch cur_collection into row_cur_collection;
      exit when cur_collection%notfound;
     insert into xxd_borrow_collection
     (  collectionid        ,  tenderid            ,  borrowid            ,  porder              ,  repayaccount        ,
        repayinterest       ,  repaycapital        ,  repaytime           ,  repayyesaccount     ,  repayyesinterest    ,
        repayyescapital     ,  repayyestime        ,  userid              ,  laterdays           ,  laterinterest       ,
        penalsum            ,  ispayment           ,  status              ,  addtime             ,  addip               )
      select
        row_cur_collection.id,                 row_cur_collection.tenderid,                      row_cur_collection.borrowid,                row_cur_collection.porder,               row_cur_collection.REPAYACCOUNT,
        row_cur_collection.repayinterest,      row_cur_collection.repaycapital,                  from_unixtime(row_cur_collection.repaytime),row_cur_collection.repayyesaccount,      row_cur_collection.repayyesinterest,
        row_cur_collection.repayyescapital,    from_unixtime(row_cur_collection.repayyestime),   row_cur_collection.userid,                  row_cur_collection.laterdays,            row_cur_collection.laterinterest,
        row_cur_collection.penalsum,           row_cur_collection.ispayment,                     row_cur_collection.status,                  from_unixtime(row_cur_collection.addtime),row_cur_collection.addip
       from dual;
       if mod(m_count,p_rowcommit)=0 then
          commit;
       end if;
   end loop;
   commit;
  close cur_collection;
end dt_proc_borrow;



/
