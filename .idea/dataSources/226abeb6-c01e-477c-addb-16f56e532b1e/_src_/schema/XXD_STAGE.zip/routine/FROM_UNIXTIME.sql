CREATE function from_unixtime(p_unixtime number) return date is
result date;
begin
result:=to_date('1970-01-01 08:00:00','yyyy-mm-dd hh24:mi:ss')+p_unixtime/86400;
return(result);
end from_unixtime;



/
