CREATE procedure dt_proc_user_GROUP_lipanfeng is
-- baseinfo
CURSOR cur_baseinfo IS SELECT
userId,IdCardNum,degree,marryStatus,nativePlace,houseAddress,houseTel,companyAddress,companyIndustry,position,companyTel,
income,shebaoNum,interest,ability,otherRemark,upTime,upIp,sex,BIRTHDAY,mobilePhone,province,city,idcardtype,occupation
  FROM  xxdai_base_info;
  row_cur_baseinfo cur_baseinfo%rowtype;
  -- bank
CURSOR cur_user_bank IS SELECT b.id,b.userId,b.bankName,b.bankAddress,b.bankCode,b.banded,b.setTime,b.setIp
  FROM xxdai_bank_info b , xxdai_user u
  where  b.userid  = u.id;
  row_cur_user_bank cur_user_bank%rowtype;
  -- extdetail
CURSOR cur_user_extdetail IS SELECT id,userId,infoDetailId,infoValue,addScore,setTime,setIp
  FROM xxdai_infos;
  row_cur_user_extdetail cur_user_extdetail%rowtype;
  m_count INTEGER ;
 -- m_str_sql varchar2(200);
  m_str_bankcode varchar2(200);
  -- stu_baseinfo
cursor cur_stu_baseinfo is select b.ID,b.USERID,b.JOBSTATUS,b.UNIVERSITY,b.ENROLLMENTDATE,b.GRADUATIONDATE,b.COLLEGUE,b.MAJOR,
       b.DORMNO,b.HOBBY,b.REMARK,b.CREATEDATE,b.CREATEIP,b.LASTMODIFY,b.MODIFYER,b.BACK1,b.BACK2,b.BACK3,b.BACK4,b.BACK5,
       r.RELATION,r.CNAME,r.PHONE,r.JOB,r.COMPANY,r.ADDTIME AS ADDTIME2,r.ADDIP AS ADDIP2,r.LASTMODIFY AS LASTMODIFY2,t.MATENAME1 ,
       t.MATEPHONE1,t.MATENAME2,t.MATEPHONE2,t.ADDTIME AS ADDTIME3,t.ADDIP AS ADDIP3,t.LASTMODIFY AS LASTMODIFY3
       from xxdai_stu_baseinfo b
       LEFT JOIN XXDAI_STU_RELATION r ON r.stuid=b.id
       left join xxdai_stu_mate t on t.stuid=b.id;
  row_stu_baseinfo cur_stu_baseinfo%rowtype;
  -- stu_doc
cursor cur_stu_doc is select b.userid,d.DOCURL,d.ADDTIME AS ADDTIME4,
       d.ADDIP AS ADDIP4,d.LASTMODIFY AS LASTMODIFY4 from xxdai_stu_baseinfo b,xxdai_stu_doc d where b.id=d.stuid;
  row_stu_doc cur_stu_doc%rowtype;
  -- stu_baseinfo--
  m_userid INTEGER;
  m_CREATEDATE number;
  m_CREATEIP varchar2(50);
  m_LASTMODIFY number;
  -- stu_relation
  r_ADDTIME2 number;
  r_ADDIP2 varchar2(50);
  r_LASTMODIFY2 number;
  -- stu_mate
  t_ADDTIME3 number;
  t_ADDIP3 varchar2(50);
  t_LASTMODIFY3 number;
  -- stu_doc
  d_ADDTIME4 number;
  d_ADDIP4 varchar2(50);
  d_LASTMODIFY4 number;
  m_str_nativeplace varchar2(2000);
  m_str_interest    varchar2(2000);
  m_str_housetel    varchar2(2000);
  m_str_ability     varchar2(2000);
  m_str_otherRemark     varchar2(2000);
  m_str_shebaoNum     varchar2(2000);
  m_str_companyTel     varchar2(2000);

BEGIN
  delete from  xxd_user_baseinfo;
  delete from xxd_user_bank;
  delete from   xxd_user_extdetail;
  commit;
  --user_baseinfo
  m_count:= 0;
  OPEN cur_baseinfo;
  loop
     m_count:= m_count+1;
     FETCH cur_baseinfo INTO row_cur_baseinfo;
     exit when cur_baseinfo%notfound;
         --  超长数据处理
         m_str_nativeplace := row_cur_baseinfo.nativePlace;
         if lengthb(m_str_nativeplace)>30 then
           m_str_nativeplace :=substr(m_str_nativeplace,1,10);
           end if ;
         m_str_interest :=row_cur_baseinfo.interest;
         if lengthb(m_str_interest)>30 then
           m_str_interest :=substr(m_str_interest,1,10);
           end if ;

           m_str_housetel :=row_cur_baseinfo.housetel;
         if lengthb(m_str_housetel)>20 then
           m_str_housetel :=substr(m_str_housetel,1,6);
           end if ;

           m_str_ability :=row_cur_baseinfo.ability;
         if lengthb(m_str_ability)>300 then
           m_str_ability :=substr(m_str_ability,1,100);
           end if ;
           m_str_otherRemark :=row_cur_baseinfo.otherremark;
         if lengthb(m_str_otherRemark)>300 then
           m_str_otherRemark :=substr(m_str_otherRemark,1,100);
           end if ;

           m_str_shebaoNum :=row_cur_baseinfo.shebaonum;
         if lengthb(m_str_shebaoNum)>20 then
           m_str_shebaoNum :=substr(m_str_shebaoNum,1,6);
           end if ;
           m_str_companyTel :=row_cur_baseinfo.companytel;
         if lengthb(m_str_companyTel)>20 then
           m_str_companyTel :=substr(m_str_companyTel,1,6);
           end if ;


         INSERT INTO xxd_user_baseinfo (
         USERID,           IDCARDTYPE,      IDCARDNO,
         REALNAME,         GENDER,          DEGREE,
         BIRTHDAY,         PROVINCE,        CITY,
         STREET,           MARITALSTATUS,   NATIVEPLACE,
         ISVIP,            ABILITY,         HOMEADDR,
         HOMETEL,          COMPANYADDR,     COMPANYTEL,
         COMPANYINDUSTRY,  POSITION,        INCOME,
         SOCIALINSURCODE,  INTEREST,        NOTE,
         CREATEDATE,       CREATEIP,        MODIFYDATE,
         OCCUPATION
         )
         VALUES(
         row_cur_baseinfo.userId,    row_cur_baseinfo.idcardtype,      row_cur_baseinfo.IdCardNum,
         null,                       row_cur_baseinfo.sex,             row_cur_baseinfo.degree,
         trunc(FROM_UNIXTIME(row_cur_baseinfo.BIRTHDAY)),              row_cur_baseinfo.province,       row_cur_baseinfo.city,
         null,                       row_cur_baseinfo.marryStatus,     m_str_nativeplace,
         null,                       m_str_ability,         row_cur_baseinfo.houseAddress,
         m_str_housetel,  row_cur_baseinfo.companyAddress,  m_str_companyTel,
         row_cur_baseinfo.companyIndustry,                             row_cur_baseinfo.position,       row_cur_baseinfo.income,
         m_str_shebaoNum, m_str_interest,        m_str_otherRemark,
         nvl(FROM_UNIXTIME(row_cur_baseinfo.upTime),sysdate),          nvl(row_cur_baseinfo.upIp,'127.0.0.1datatrans'),           sysdate,
         row_cur_baseinfo.occupation
         );
    if mod(m_count,2000)=0 then
       commit;
    end if;
  end loop;
    commit;
  close cur_baseinfo;
        update xxd_user_baseinfo b
           set b.realname =
               (select realname
                 from xxdai_realname_appro a
                where a.userid = b.userid)
         where b.userid in (select userid from xxdai_realname_appro);
        commit;
       update xxd_user_baseinfo b
          set b.ISVIP =
              (select ispassed from xxdai_vip_appro a where a.userid = b.userid)
        where b.userid in (select userid from xxdai_vip_appro);
        commit;
  -- bank
  m_count:= 0;
  OPEN cur_user_bank;
  loop
     m_count:= m_count+1;
     FETCH cur_user_bank INTO row_cur_user_bank;
     exit when cur_user_bank%notfound;
         m_str_bankcode := replace(row_cur_user_bank.bankCode,' ','');
         m_str_bankcode := replace(row_cur_user_bank.bankCode,'银行卡号','');
         if lengthb(m_str_bankcode)>20 then
           m_str_bankcode:=substr(m_str_bankcode,1,20);
         end if ;
         INSERT INTO xxd_user_bank(
              ID,              USERID,          BANKCODE,
              BRANCH,          BANKACCOUNT,     BANDED,
              ADDTIME,         ADDIP,           LASTMODIFY,
              MODIFYDATE
         )
         VALUES(
              row_cur_user_bank.id,                      row_cur_user_bank.userId,    row_cur_user_bank.bankName,
              row_cur_user_bank.bankAddress,             nvl(m_str_bankcode,' '),  row_cur_user_bank.banded,
              from_unixtime(row_cur_user_bank.setTime),  row_cur_user_bank.setIp,     0,
              sysdate
         );
    if mod(m_count,2000)=0 then
       commit;
    end if;
   end loop;

   -- 处理银行编码
   update xxd_user_bank t set t.bankcode  = 'citic'  where t.bankcode  = '中信实业银行';
   update xxd_user_bank t set t.bankcode  = 'boc'  where t.bankcode  = '中国银行';
   update xxd_user_bank t set t.bankcode  = 'psbc'  where t.bankcode  = '中国邮政储蓄银行';
   update xxd_user_bank t set t.bankcode  = 'adbc'  where t.bankcode  = '中国农业发展银行';
   update xxd_user_bank t set t.bankcode  = 'rcc'  where t.bankcode  = '农村信用社';
   update xxd_user_bank t set t.bankcode  = 'cbhb'  where t.bankcode  = '渤海银行';
   update xxd_user_bank t set t.bankcode  = 'icbc'  where t.bankcode  = '中国工商银行';
   update xxd_user_bank t set t.bankcode  = 'bosh'  where t.bankcode  = '上海银行';
   update xxd_user_bank t set t.bankcode  = 'egbank'  where t.bankcode  = '恒丰银行';
   update xxd_user_bank t set t.bankcode  = 'cmbc'  where t.bankcode  = '中国民生银行';
   update xxd_user_bank t set t.bankcode  = 'bcm'  where t.bankcode  = '交通银行';
   update xxd_user_bank t set t.bankcode  = 'ncb'  where t.bankcode  = '南洋商业银行';
   update xxd_user_bank t set t.bankcode  = 'rbs'  where t.bankcode  = '苏格兰皇家银行';
   update xxd_user_bank t set t.bankcode  = 'abc'  where t.bankcode  = '中国农业银行';
   update xxd_user_bank t set t.bankcode  = 'citi'  where t.bankcode  = '花旗银行';
   update xxd_user_bank t set t.bankcode  = 'ccb'  where t.bankcode  = '中国建设银行';
   update xxd_user_bank t set t.bankcode  = 'ceb'  where t.bankcode  = '中国光大银行';
   update xxd_user_bank t set t.bankcode  = 'pingan'  where t.bankcode  = '平安银行';
   update xxd_user_bank t set t.bankcode  = 'hsbank'  where t.bankcode  = '徽商银行';
   update xxd_user_bank t set t.bankcode  = 'cmb'  where t.bankcode  = '招商银行';
   update xxd_user_bank t set t.bankcode  = 'cgb'  where t.bankcode  = '广发银行';
   update xxd_user_bank t set t.bankcode  = 'hxb'  where t.bankcode  = '华夏银行';
   update xxd_user_bank t set t.bankcode  = 'lchz'  where t.bankcode  = '农村合作银行';
   update xxd_user_bank t set t.bankcode  = 'rcb'  where t.bankcode  = '农村商业银行';
   update xxd_user_bank t set t.bankcode  = 'spdb'  where t.bankcode  = '上海浦东发展银行';
   update xxd_user_bank t set t.bankcode  = 'cib'  where t.bankcode  = '兴业银行';
   update xxd_user_bank t set t.bankcode  = 'srcb'  where t.bankcode  = '上海农商银行';

    commit;
  close cur_user_bank;
  -- extdetail
  m_count:= 0;
  OPEN cur_user_extdetail;
  loop
     m_count:= m_count+1;
     FETCH cur_user_extdetail INTO row_cur_user_extdetail;
     exit when cur_user_extdetail%notfound;
         INSERT INTO xxd_user_extdetail(
           EXTDETAILID,         USERID,            EXTKEYID,
           EXTVALUE,            CREATEDATE,        CREATEIP,
           MODIFYDATE
         )
         VALUES(
           seq_user_extdetail.nextval,       row_cur_user_extdetail.userId,                         row_cur_user_extdetail.infoDetailId,
           row_cur_user_extdetail.infoValue, from_unixtime(row_cur_user_extdetail.setTime),         row_cur_user_extdetail.setIp,
           sysdate
         );
    if mod(m_count,2000)=0 then
       commit;
    end if;
  end loop;
    commit;
  close cur_user_extdetail;
  -- 学生扩展信息部分
  m_count:=0;
  open cur_stu_baseinfo;
  loop
    m_count:=m_count+1;
    fetch cur_stu_baseinfo
      into row_stu_baseinfo;
    exit when cur_stu_baseinfo%notfound;
     --stu_baseinfo--
    m_userid:=row_stu_baseinfo.userid;
    m_CREATEDATE:=row_stu_baseinfo.createdate;
    m_CREATEIP:=row_stu_baseinfo.CREATEIP ;
    m_LASTMODIFY:=row_stu_baseinfo.LASTMODIFY;
    --stu_relation ------------
    r_ADDTIME2:=row_stu_baseinfo.ADDTIME3;
    r_ADDIP2:=row_stu_baseinfo.ADDIP2;
    r_LASTMODIFY2:=row_stu_baseinfo.LASTMODIFY2;
    --stu_mate ---------------
    t_ADDTIME3:=row_stu_baseinfo.ADDTIME3;
    t_ADDIP3:=row_stu_baseinfo.ADDIP3;
    t_LASTMODIFY3:=row_stu_baseinfo.LASTMODIFY3;

  -- 源表stu_baseinfo
    insert into xxd_user_extdetail
       (extdetailid , USERID,   EXTKEYID,     EXTVALUE,     CREATEDATE,    CREATEIP,      MODIFYDATE)
    values
       (seq_user_extdetail.nextval,  m_userid,     50,      row_stu_baseinfo.jobstatus,   nvl(FROM_UNIXTIME(m_CREATEDATE),sysdate),     nvl(m_CREATEIP,'127.0.0.1'),    nvl(FROM_UNIXTIME(m_LASTMODIFY),sysdate));
    insert into xxd_user_extdetail
       (extdetailid , USERID,        EXTKEYID,      EXTVALUE,       CREATEDATE,    CREATEIP,      MODIFYDATE)
    values
       (seq_user_extdetail.nextval,  m_userid,     51,   row_stu_baseinfo.UNIVERSITY,   nvl(FROM_UNIXTIME(m_CREATEDATE),sysdate),     nvl(m_CREATEIP,'127.0.0.1'),    nvl(FROM_UNIXTIME(m_LASTMODIFY),sysdate));
    insert into xxd_user_extdetail
       (extdetailid , USERID,        EXTKEYID,      EXTVALUE,       CREATEDATE,    CREATEIP,      MODIFYDATE)
    values
       (seq_user_extdetail.nextval,  m_userid,     52,   to_char(FROM_UNIXTIME(row_stu_baseinfo.ENROLLMENTDATE/1000),'yyyy-mm-dd'),   nvl(FROM_UNIXTIME(m_CREATEDATE),sysdate),     nvl(m_CREATEIP,'127.0.0.1'),    nvl(FROM_UNIXTIME(m_LASTMODIFY),sysdate));
    insert into xxd_user_extdetail
       (extdetailid , USERID,        EXTKEYID,      EXTVALUE,       CREATEDATE,    CREATEIP,      MODIFYDATE)
    values
       (seq_user_extdetail.nextval,  m_userid,     53,    to_char(FROM_UNIXTIME(row_stu_baseinfo.GRADUATIONDATE/1000),'yyyy-mm-dd'),   nvl(FROM_UNIXTIME(m_CREATEDATE),sysdate),     nvl(m_CREATEIP,'127.0.0.1'),    nvl(FROM_UNIXTIME(m_LASTMODIFY),sysdate));
    insert into xxd_user_extdetail
       (extdetailid , USERID,        EXTKEYID,      EXTVALUE,       CREATEDATE,    CREATEIP,      MODIFYDATE)
    values
       (seq_user_extdetail.nextval,  m_userid,     54,  row_stu_baseinfo.COLLEGUE,   nvl(FROM_UNIXTIME(m_CREATEDATE),sysdate),     nvl(m_CREATEIP,'127.0.0.1'),    nvl(FROM_UNIXTIME(m_LASTMODIFY),sysdate));
    insert into xxd_user_extdetail
       (extdetailid , USERID,        EXTKEYID,      EXTVALUE,       CREATEDATE,    CREATEIP,      MODIFYDATE)
    values
       (seq_user_extdetail.nextval,  m_userid,     55,  row_stu_baseinfo.MAJOR,   nvl(FROM_UNIXTIME(m_CREATEDATE),sysdate),     nvl(m_CREATEIP,'127.0.0.1'),    nvl(FROM_UNIXTIME(m_LASTMODIFY),sysdate));
    insert into xxd_user_extdetail
       (extdetailid , USERID,        EXTKEYID,      EXTVALUE,       CREATEDATE,    CREATEIP,      MODIFYDATE)
    values
       (seq_user_extdetail.nextval,  m_userid,     56,  row_stu_baseinfo.DORMNO,   nvl(FROM_UNIXTIME(m_CREATEDATE),sysdate),     nvl(m_CREATEIP,'127.0.0.1'),    nvl(FROM_UNIXTIME(m_LASTMODIFY),sysdate));
    insert into xxd_user_extdetail
       (extdetailid , USERID,        EXTKEYID,      EXTVALUE,       CREATEDATE,    CREATEIP,      MODIFYDATE)
    values
       (seq_user_extdetail.nextval,  m_userid,     57,  row_stu_baseinfo.HOBBY,   nvl(FROM_UNIXTIME(m_CREATEDATE),sysdate),     nvl(m_CREATEIP,'127.0.0.1'),    nvl(FROM_UNIXTIME(m_LASTMODIFY),sysdate));
     insert into xxd_user_extdetail
       (extdetailid , USERID,        EXTKEYID,      EXTVALUE,       CREATEDATE,    CREATEIP,      MODIFYDATE)
    values
       (seq_user_extdetail.nextval,  m_userid,     44,  row_stu_baseinfo.BACK1,   nvl(FROM_UNIXTIME(m_CREATEDATE),sysdate),     nvl(m_CREATEIP,'127.0.0.1'),    nvl(FROM_UNIXTIME(m_LASTMODIFY),sysdate));
     insert into xxd_user_extdetail
       (extdetailid , USERID,        EXTKEYID,      EXTVALUE,       CREATEDATE,    CREATEIP,      MODIFYDATE)
    values
       (seq_user_extdetail.nextval,  m_userid,     45,  row_stu_baseinfo.BACK2,   nvl(FROM_UNIXTIME(m_CREATEDATE),sysdate),     nvl(m_CREATEIP,'127.0.0.1'),    nvl(FROM_UNIXTIME(m_LASTMODIFY),sysdate));
    insert into xxd_user_extdetail
       (extdetailid , USERID,        EXTKEYID,      EXTVALUE,       CREATEDATE,    CREATEIP,      MODIFYDATE)
    values
       (seq_user_extdetail.nextval,  m_userid,     46,  row_stu_baseinfo.BACK3,   nvl(FROM_UNIXTIME(m_CREATEDATE),sysdate),     nvl(m_CREATEIP,'127.0.0.1'),    nvl(FROM_UNIXTIME(m_LASTMODIFY),sysdate));
     insert into xxd_user_extdetail
       (extdetailid , USERID,        EXTKEYID,      EXTVALUE,       CREATEDATE,    CREATEIP,      MODIFYDATE)
    values
       (seq_user_extdetail.nextval, m_userid,     47,  row_stu_baseinfo.BACK4,   nvl(FROM_UNIXTIME(m_CREATEDATE),sysdate),     nvl(m_CREATEIP,'127.0.0.1'),    nvl(FROM_UNIXTIME(m_LASTMODIFY),sysdate));
 -- 源表stu_relation
    insert into xxd_user_extdetail
       (extdetailid , USERID,        EXTKEYID,      EXTVALUE,       CREATEDATE,    CREATEIP,      MODIFYDATE)
    values
       (seq_user_extdetail.nextval, m_userid,     58,  decode(row_stu_baseinfo.RELATION,'父亲','01','母亲','02','兄弟姐妹','03','03'),   nvl(FROM_UNIXTIME(r_ADDTIME2),sysdate),     nvl(r_ADDIP2,'127.0.0.1'),    nvl(FROM_UNIXTIME(r_LASTMODIFY2),sysdate));
    insert into xxd_user_extdetail
       (extdetailid , USERID,        EXTKEYID,      EXTVALUE,       CREATEDATE,    CREATEIP,      MODIFYDATE)
    values
       (seq_user_extdetail.nextval, m_userid,     59,  row_stu_baseinfo.CNAME,   nvl(FROM_UNIXTIME(r_ADDTIME2),sysdate),     nvl(r_ADDIP2,'127.0.0.1'),    nvl(FROM_UNIXTIME(r_LASTMODIFY2),sysdate));
    insert into xxd_user_extdetail
       (extdetailid , USERID,        EXTKEYID,      EXTVALUE,       CREATEDATE,    CREATEIP,      MODIFYDATE)
    values
       (seq_user_extdetail.nextval, m_userid,     60,  row_stu_baseinfo.PHONE,   nvl(FROM_UNIXTIME(r_ADDTIME2),sysdate),     nvl(r_ADDIP2,'127.0.0.1'),    nvl(FROM_UNIXTIME(r_LASTMODIFY2),sysdate));
    insert into xxd_user_extdetail
       (extdetailid , USERID,        EXTKEYID,      EXTVALUE,       CREATEDATE,    CREATEIP,      MODIFYDATE)
    values
       (seq_user_extdetail.nextval, m_userid,     61,  row_stu_baseinfo.JOB,   nvl(FROM_UNIXTIME(r_ADDTIME2),sysdate),     nvl(r_ADDIP2,'127.0.0.1'),    nvl(FROM_UNIXTIME(r_LASTMODIFY2),sysdate));
    insert into xxd_user_extdetail
       (extdetailid , USERID,        EXTKEYID,      EXTVALUE,       CREATEDATE,    CREATEIP,      MODIFYDATE)
    values
       (seq_user_extdetail.nextval, m_userid,     62,  row_stu_baseinfo.COMPANY,   nvl(FROM_UNIXTIME(r_ADDTIME2),sysdate),     nvl(r_ADDIP2,'127.0.0.1'),    nvl(FROM_UNIXTIME(r_LASTMODIFY2),sysdate));
    -- 源表stu_mate
    insert into xxd_user_extdetail
       (extdetailid , USERID,        EXTKEYID,      EXTVALUE,       CREATEDATE,    CREATEIP,      MODIFYDATE)
    values
       (seq_user_extdetail.nextval, m_userid,     63,  row_stu_baseinfo.MATENAME1,   nvl(FROM_UNIXTIME(t_ADDTIME3),sysdate),     nvl(t_ADDIP3,'127.0.0.1'),    nvl(FROM_UNIXTIME(t_LASTMODIFY3),sysdate));
    insert into xxd_user_extdetail
       (extdetailid , USERID,        EXTKEYID,      EXTVALUE,       CREATEDATE,    CREATEIP,      MODIFYDATE)
    values
       (seq_user_extdetail.nextval, m_userid,     64,  row_stu_baseinfo.MATEPHONE1,   nvl(FROM_UNIXTIME(t_ADDTIME3),sysdate),     nvl(t_ADDIP3,'127.0.0.1'),    nvl(FROM_UNIXTIME(t_LASTMODIFY3),sysdate));
    insert into xxd_user_extdetail
       (extdetailid , USERID,        EXTKEYID,      EXTVALUE,       CREATEDATE,    CREATEIP,      MODIFYDATE)
    values
       (seq_user_extdetail.nextval, m_userid,     65,  row_stu_baseinfo.MATENAME2,   nvl(FROM_UNIXTIME(t_ADDTIME3),sysdate),     nvl(t_ADDIP3,'127.0.0.1'),    nvl(FROM_UNIXTIME(t_LASTMODIFY3),sysdate));
    insert into xxd_user_extdetail
       (extdetailid , USERID,        EXTKEYID,      EXTVALUE,       CREATEDATE,    CREATEIP,      MODIFYDATE)
    values
       (seq_user_extdetail.nextval, m_userid,     66,  row_stu_baseinfo.MATEPHONE2,   nvl(FROM_UNIXTIME(t_ADDTIME3),sysdate),     nvl(t_ADDIP3,'127.0.0.1'),    nvl(FROM_UNIXTIME(t_LASTMODIFY3),sysdate));

  end loop;
  commit;
  close cur_stu_baseinfo;
  -- 源表stu_doc
   m_count:= 0;
  OPEN cur_stu_doc;
  loop
     m_count:= m_count+1;
     FETCH cur_stu_doc INTO row_stu_doc;
     exit when cur_stu_doc%notfound;
--stu_doc ------
    m_userid:=row_stu_doc.userid;
    d_ADDTIME4:=row_stu_doc.ADDTIME4 ;
    d_ADDIP4:=row_stu_doc.ADDIP4;
    d_LASTMODIFY4:=row_stu_doc.LASTMODIFY4;
    insert into xxd_user_extdetail
       (extdetailid , USERID,        EXTKEYID,      EXTVALUE,       CREATEDATE,    CREATEIP,      MODIFYDATE)
    values
       (seq_user_extdetail.nextval, m_userid,     49,  replace(row_stu_doc.Docurl,'/images/','/static/image/student_card/'),    nvl(FROM_UNIXTIME(d_ADDTIME4),sysdate),     nvl(d_ADDIP4,'127.0.0.1'),    nvl(FROM_UNIXTIME(d_LASTMODIFY4),sysdate));
     end loop;
  commit;
  close cur_stu_doc;
end dt_proc_user_GROUP_lipanfeng;



/
