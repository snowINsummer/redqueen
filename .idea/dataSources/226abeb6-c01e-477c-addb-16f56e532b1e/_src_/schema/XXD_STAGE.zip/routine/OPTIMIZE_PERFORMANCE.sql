CREATE procedure optimize_performance(in_date date)
is
v_in_date date:=in_date;

begin

--计算新元宝业绩

--生成退出信息，包含正常退出和提前退出

insert into xxd_product_out(id,outtradeid,userid,productcode,productname,outtradenum,tradeid,tradenum,CREATEDATE,servicenum,employeeid,
initiator,outtype,KEEPDAYS,terms,departmentid,interest)
select seq_product_out.nextval,a.userdetailid,b.userid,'98','新元宝',a.account,a.userdetailid,a.account,b.enddate,
c.servicenum,employeeid,1,
case when b.status=3 then 1
     when b.status=2 then 2 end outtype,
case when b.status=3 then trunc(b.enddate-a.addtime) end keeydays,c.terms,c.dept4id,
case when b.status=3 then (floatprofit+balancemoney)*a.account/b.account
     when b.status=2 then c.plannedinterest end  interest
from xxd_optimize_userdetail a inner join xxd_optimize_userscheme b
on a.userschemeid=b.userschemeid
inner join xxd_order_record c
on a.userdetailid=c.orderno
where enddate>=trunc(v_in_date)-1 and enddate<trunc(v_in_date)
and b.status in (2,3);


commit;



--计算每日年化

insert into xxd_performance_daily(id,adddate,userid,servicenum,employeeid,ptype,departmentid,addamount,scaleamount,annualamount,outtype)
select seq_performance_daily.nextval,addtime,userid,servicenum,employeeid,ptype,departmentid,addaccount,addaccount scaleamount,annual_amount,outtype from
(select addtime,userid,servicenum,employeeid,ptype,departmentid,sum(addaccount) addaccount,sum(scaleamount) scaleamount,sum(annual_amount) annual_amount,outtype from
(select trunc(addtime) addtime,userid,nvl(servicenum,0) servicenum,nvl(employeeid,0) employeeid,ptype,nvl(dept4id,0) departmentid,addaccount,addaccount scaleamount,
case when terms<=12 then addaccount*terms/12
     when terms=18 then (addaccount*terms/12)/1.5*1.2
     when terms=24 then (addaccount*terms/12)/2*1.5
     when terms=36 then (addaccount*terms/12)/3*2
       end annual_amount,null outtype
from xxd_order_record a
where ptype=98
and addtime>=trunc(v_in_date)-1 and  addtime<trunc(v_in_date)
and userid not in (select userid from xxd_account_cashprohibit)
union all
select outcreatedate,userid,servicenum,employeeid,productcode,departmentid,addaccount,tradenum,
case when increatedate<to_date('20170701','yyyymmdd') then annual_amount
     when increatedate>=to_date('20170701','yyyymmdd') and terms<=12 then annual_amount
     when increatedate>=to_date('20170701','yyyymmdd') and terms=18 then annual_amount/1.5*1.2
     when increatedate>=to_date('20170701','yyyymmdd') and terms=24 then annual_amount/2*1.5
     when increatedate>=to_date('20170701','yyyymmdd') and terms=36 then annual_amount/3*2
  end annual_amount,outtype from
(select b.addtime increatedate,a.terms,trunc(a.createdate) outcreatedate,a.userid,nvl(a.servicenum,0) servicenum,nvl(a.employeeid,0) employeeid,a.productcode,nvl(a.departmentid,0) departmentid,
0 addaccount,(-1*a.tradenum) tradenum,
case when round(-1*(a.tradenum*a.terms/12-a.tradenum*a.keepdays/360),6)>0 then 0
     else round(-1*(a.tradenum*a.terms/12-a.tradenum*a.keepdays/360),6) end annual_amount,1 outtype
from xxd_product_out a inner join xxd_order_record b
on a.tradeid=b.orderno
where a.productcode=98
and a.OUTTYPE=1
and a.createdate>=trunc(v_in_date)-1 and  a.createdate<trunc(v_in_date)
and a.userid not in (select userid from xxd_account_cashprohibit)))
group by addtime,userid,servicenum,employeeid,ptype,departmentid,outtype);


commit;


--计算每月年化

delete from xxd_performance_month where PTYPE=98 and ADDDATE=trunc(trunc(v_in_date)-1,'month');

insert into xxd_performance_month(id,adddate,employeeid,ptype,addamount,scaleamount,annualamount,departmentid)
select seq_performance_month.nextval,adddate,employeeid,ptype,addamount,scaleamount,annualamount,departmentid from
(select trunc(adddate,'month') adddate,employeeid,ptype,sum(addamount) addamount,
sum(scaleamount) scaleamount,
sum(annualamount) annualamount,departmentid
from xxd_performance_daily
where adddate>=trunc(trunc(v_in_date)-1,'month')
and adddate<add_months(trunc(trunc(v_in_date)-1,'month'),1)
and ptype=98
group by trunc(adddate,'month'),employeeid,ptype,departmentid);

commit;

end;


/
