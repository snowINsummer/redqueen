CREATE procedure DT_proc_stu_lipanfeng is
  -- stu_identified
cursor cur_stu_identified is select b.userid,b.graduationdate,e.name,s.ID,s.STUID,s.STUDENTPICUP,s.STUDENTPICDOWN,s.STATUS  ,s.APPROVEDDATE ,
       s.APPROVEIDP ,s.APPROVEDBY,s.ADDTIME ,s.ADDIP  ,s.LASTMODIFY,s.MODIFYER,s.REMARK ,s.BACK1,s.BACK2,s.BACK3,s.BACK4,s.BACK5
       from xxdai_stu_identified s
       left join xxdai_employee e on e.id=s.approvedby
       left join xxdai_stu_baseinfo b on s.stuid=b.id ;
  row_stu_identified cur_stu_identified%rowtype;
  -- xxdai_contract_signinfo
cursor cur_contract_signinfo is select ID,BORROWERID,LENDERSUSERID,BORROWERUSERID,SERVICESIDEID,LENDERSSIGNSTATUS,LENDERSSIGNDATE,
       BORROWERSIGNSTATUS,BORROWERSIGNDATE,SERVICESIGNSTATUS,SERVICESIGNDATE,CONTRACTVERSION,CONTRACTADDR,CONTRACTMAKEDATE,CREATEDATE,
       CREATEIP,MODIFIEDDATE,BACK2,BACK1,BACK3,BACK4,BACK5 from xxdai_contract_signinfo;
  row_contract_signinfo cur_contract_signinfo%rowtype;
  m_count INTEGER ;
  m_str_sql varchar2(200);
begin
  --源表stu_identified
  m_count:= 0;
  m_str_sql:='truncate table xxd_sturecords_appro';
  execute immediate m_str_sql;
  commit;
  OPEN cur_stu_identified;
  loop
     m_count:= m_count+1;
     FETCH cur_stu_identified INTO row_stu_identified;
     exit when cur_stu_identified%notfound;
         INSERT INTO xxd_sturecords_appro(
                 ID,    USERID,        STUPIC_UP,         STUPIC_DOWN,            STATUS,              APPRODATE,
               APPROUSERID,   APPROUSERNAME,     APPROIP,                APPROREMARK,    VAILDATE,
               CREATEDATE,   CREATEIP,          MODIFYDATE,             LASTMODIFY
         )
         VALUES( seq_sturecords_appro.nextval,   row_stu_identified.USERID,   replace(row_stu_identified.STUDENTPICUP,'/images/','/static/image/student_card/'),    replace(row_stu_identified.STUDENTPICDOWN,'/images/','/static/image/student_card/'),   row_stu_identified.STATUS,   from_unixtime(row_stu_identified.APPROVEDDATE),
                row_stu_identified.APPROVEDBY,   row_stu_identified.name,    row_stu_identified.APPROVEIDP,   row_stu_identified.REMARK,   trunc(from_unixtime(row_stu_identified.graduationdate/1000)),
                from_unixtime(row_stu_identified.ADDTIME),   row_stu_identified.ADDIP,    nvl(from_unixtime(row_stu_identified.LASTMODIFY),sysdate),   row_stu_identified.MODIFYER
         );
  end loop;
    commit;
  close cur_stu_identified;
  -- 源表xxdai_contract_signinfo
  m_count:= 0;
  m_str_sql:='truncate table xxd_contract_signinfo';
  execute immediate m_str_sql;
  commit;
  OPEN cur_contract_signinfo;
  loop
     m_count:= m_count+1;
     FETCH cur_contract_signinfo INTO row_contract_signinfo;
     exit when cur_contract_signinfo%notfound;
         INSERT INTO xxd_contract_signinfo(
         ID,      BORROWERID        ,  LENDERSUSERID     ,  BORROWUSERID      ,  SERVICESIDEID     ,  LENDERSSIGNSTATUS ,  LENDERSSIGNDATE   ,
         BORROWERSIGNSTATUS,  BORROWERSIGNDATE  ,  SERVICESIGNSTATUS ,  SERVICESIGNDATE   ,  CONTRACTVERSION   ,  CONTRACTADDR      ,
         CONTRACTMAKEDATE  ,  CREATEDATE        ,  CREATEIP          ,  MODIFIEDDATE
                     )
         VALUES(
         seq_contract_signinfo.nextval,   row_contract_signinfo.BORROWERID,           row_contract_signinfo.LENDERSUSERID,                     row_contract_signinfo.BORROWERUSERID,      row_contract_signinfo.SERVICESIDEID,                    row_contract_signinfo.LENDERSSIGNSTATUS,  from_unixtime(row_contract_signinfo.LENDERSSIGNDATE),
         row_contract_signinfo.BORROWERSIGNSTATUS,   from_unixtime(row_contract_signinfo.BORROWERSIGNDATE),   row_contract_signinfo.SERVICESIGNSTATUS,   from_unixtime(row_contract_signinfo.SERVICESIGNDATE),   row_contract_signinfo.CONTRACTVERSION,  row_contract_signinfo.CONTRACTADDR,
         from_unixtime(row_contract_signinfo.CONTRACTMAKEDATE),  from_unixtime(row_contract_signinfo.CREATEDATE),  row_contract_signinfo.CREATEIP,       from_unixtime(row_contract_signinfo.MODIFIEDDATE)
               );
  end loop;
    commit;
  close cur_contract_signinfo;
end DT_proc_stu_lipanfeng;



/
