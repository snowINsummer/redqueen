CREATE procedure fund_performance(in_date date)
is
v_in_date date:=in_date;
cursor ck is
select tradeid,userid,tradenum,createdate  from xxd_fund_usertrade
where type=2
and createdate>=trunc(v_in_date)-1 and createdate<trunc(v_in_date);


cursor kc(v_userid varchar2) is
select row_number() over (partition by userid order by createdate,tradeid) rn,tradeid,userid,productcode,productname,initiator,tradenum,CREATEDATE ,servicenum,employeeid
from xxd_fifo_temp
where userid=v_userid
and tradenum>0
order by createdate,tradeid;

ck_rec ck%rowtype;
kc_rec kc%rowtype;
out_outcnt number;
tmp_outcnt number;
cnt number;

begin

execute immediate 'truncate table  xxd_fifo_temp';

insert into xxd_fifo_temp(indate,tradeid,userid,productcode,productname,initiator,tradenum,innum,outnum,CREATEDATE,servicenum,employeeid)
select
trunc(a.createdate)，
a.tradeid,a.userid,99,'日日盈',a.initiator,a.tradenum,a.tradenum,0,a.createdate,b.servicenum,b.employeeid
from xxd_fund_usertrade a left join xxd_order_record b
on a.tradeid=b.orderno
where tradenum>0
and type=1
and createdate>=trunc(v_in_date)-1 and createdate<trunc(v_in_date)
union all
select indate,tradeid,userid,productcode,productname,initiator,tradenum,innum,outnum,CREATEDATE,servicenum,employeeid
from xxd_fifo_daily
where indate=trunc(v_in_date)-2
and tradenum>0
;

commit;

open ck;
  loop
    fetch ck into  ck_rec;
    exit when ck%notfound;
    open kc(ck_rec.userid);

    loop
      fetch kc into kc_rec;
      exit when kc%notfound;

if kc_rec.rn=1 then
tmp_outcnt:=ck_rec.tradenum;
end if;

if tmp_outcnt>0 then
cnt:=tmp_outcnt-kc_rec.tradenum;

if cnt>=0 then
out_outcnt:=kc_rec.tradenum;
else
out_outcnt:=tmp_outcnt;
end if;

update xxd_fifo_temp set tradenum=tradenum-out_outcnt,outnum=outnum+out_outcnt where userid=kc_rec.userid and tradeid=kc_rec.tradeid;

insert into xxd_product_out (id,outtradeid,userid,productcode,productname,outtradenum,tradeid,tradenum,CREATEDATE,servicenum,employeeid,initiator)
values(seq_product_out.nextval,ck_rec.tradeid,ck_rec.userid,kc_rec.productcode,kc_rec.productname,ck_rec.tradenum,kc_rec.tradeid,out_outcnt,ck_rec.CREATEDATE,
kc_rec.servicenum,kc_rec.employeeid,kc_rec.initiator);

tmp_outcnt:=cnt;

end if;

commit;



    end loop;
    close kc;
  end loop;
  close ck;

insert into xxd_fifo_daily(id,indate,tradeid,userid,productcode,productname,initiator,tradenum,innum,outnum,CREATEDATE,servicenum,employeeid)
select seq_fifo_daily.nextval,trunc(v_in_date)-1,tradeid,userid,productcode,productname,initiator,tradenum,innum,outnum,CREATEDATE,servicenum,employeeid
from xxd_fifo_temp;


commit;



insert into xxd_performance_daily(id,adddate,userid,servicenum,employeeid,departmentid,ptype,addamount,scaleamount,annualamount)
select seq_performance_daily.nextval,indate,userid,servicenum,employeeid,departmentid,productcode,addamount,scaleamount,annualamount from(
select  indate,userid,nvl(servicenum,0) servicenum,nvl(employeeid,0) employeeid,nvl(departmentid,0) departmentid,productcode,
sum(case when createdate>=trunc(v_in_date)-1 and createdate<trunc(v_in_date) then innum else 0 end) addamount,
sum(case when createdate>=trunc(v_in_date)-1 and createdate<trunc(v_in_date) then innum else 0 end) scaleamount,
round(sum(tradenum)/360,6) annualamount
from xxd_fifo_daily
where indate=trunc(v_in_date)-1
and productcode=99
and userid not in (select userid from xxd_account_cashprohibit)
group by indate,userid,nvl(servicenum,0),nvl(employeeid,0),nvl(departmentid,0),productcode);

commit;


delete from xxd_performance_month where PTYPE=99 and ADDDATE=trunc(trunc(v_in_date)-1,'month');

insert into xxd_performance_month(id,adddate,employeeid,ptype,addamount,scaleamount,annualamount,departmentid)
select seq_performance_month.nextval,adddate,employeeid,ptype,addamount,scaleamount,annualamount,departmentid from
(select trunc(adddate,'month') adddate,employeeid,ptype,sum(addamount) addamount,sum(scaleamount) scaleamount,sum(annualamount) annualamount,departmentid
from xxd_performance_daily
where adddate>=trunc(trunc(v_in_date)-1,'month')
and adddate<add_months(trunc(trunc(v_in_date)-1,'month'),1)
and ptype=99
group by trunc(adddate,'month'),employeeid,ptype,departmentid);

/*
merge into (select * from xxd_performance_month where  ptype=99 and adddate=trunc(trunc(v_in_date)-1,'month')) a
using (select trunc(adddate,'month') adddate,employeeid,ptype,sum(addamount) addamount,sum(scaleamount) scaleamount,sum(annualamount) annualamount,departmentid
from xxd_performance_daily
where adddate=trunc(v_in_date)-1
and ptype=99
group by trunc(adddate,'month'),employeeid,ptype,departmentid) b
on (a.adddate=b.adddate and a.employeeid=b.employeeid and a.ptype=b.ptype and a.departmentid=b.departmentid)
when matched  then
  update set a.addamount=a.addamount+b.addamount,
         a.scaleamount=a.scaleamount+b.scaleamount,
         a.annualamount=a.annualamount+b.annualamount
when not matched then
  insert values ( seq_performance_month.nextval,b.adddate,b.employeeid,b.ptype,b.addamount,b.scaleamount,b.annualamount,b.departmentid);
*/

commit;

end;

/
