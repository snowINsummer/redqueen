CREATE procedure abc(in_date date)
is
v_in_date date:=in_date;
cursor ck is
select tradeid,userid,tradenum,createdate  from xxd_fund_usertrade
where type=2
and createdate>=trunc(v_in_date)-1 and createdate<trunc(v_in_date);


cursor kc(v_userid varchar2) is
select row_number() over (partition by userid order by createdate,tradeid) rn,tradeid,userid,productcode,productname,initiator,tradenum,CREATEDATE ,servicenum,employeeid,departmentid
from xxd_fifo_temp
where userid=v_userid
and tradenum>0
order by createdate,tradeid;

ck_rec ck%rowtype;
kc_rec kc%rowtype;
out_outcnt number;
tmp_outcnt number;
cnt number;
tmp_interest number;

begin

execute immediate 'truncate table  xxd_fifo_temp';

insert into xxd_fifo_temp(indate,tradeid,userid,productcode,productname,initiator,tradenum,innum,outnum,CREATEDATE,servicenum,employeeid,departmentid)
select
trunc(a.createdate)，
a.tradeid,a.userid,99,'日日盈',a.initiator,a.tradenum,a.tradenum,0,a.createdate,b.servicenum,b.employeeid,b.dept4id
from xxd_fund_usertrade a left join xxd_order_record b
on a.tradeid=b.orderno
where tradenum>0
and type=1
and createdate>=trunc(v_in_date)-1 and createdate<trunc(v_in_date)
and b.initiator in (1,3)
union all
select
trunc(a.createdate)，
a.tradeid,a.userid,99,'日日盈',a.initiator,a.tradenum,a.tradenum,0,a.createdate,b.servicenum,b.employeeid,b.dept4id
from xxd_fund_usertrade a left join xxd_order_interest b
on a.tradeid=b.orderno
where tradenum>0
and type=1
and createdate>=trunc(v_in_date)-1 and createdate<trunc(v_in_date)
and b.initiator=2
union all
select indate,tradeid,userid,productcode,productname,initiator,tradenum,innum,outnum,CREATEDATE,servicenum,employeeid,departmentid
from temp_fifo_daily
where indate=trunc(v_in_date)-2
and tradenum>0
;

commit;

open ck;
  loop
    fetch ck into  ck_rec;
    exit when ck%notfound;
    open kc(ck_rec.userid);

    loop
      fetch kc into kc_rec;
      exit when kc%notfound;

if kc_rec.rn=1 then
tmp_outcnt:=ck_rec.tradenum;
end if;

if tmp_outcnt>0 then
cnt:=tmp_outcnt-kc_rec.tradenum;

if cnt>=0 then
out_outcnt:=kc_rec.tradenum;
else
out_outcnt:=tmp_outcnt;
end if;

update xxd_fifo_temp set tradenum=tradenum-out_outcnt,outnum=outnum+out_outcnt where userid=kc_rec.userid and tradeid=kc_rec.tradeid;

if kc_rec.initiator=2 then
tmp_interest:=out_outcnt;
else
tmp_interest:=0;
end if;

tmp_outcnt:=cnt;

end if;

commit;



    end loop;
    close kc;
  end loop;
  close ck;

insert into temp_fifo_daily(id,indate,tradeid,userid,productcode,productname,initiator,tradenum,innum,outnum,CREATEDATE,servicenum,employeeid,departmentid)
select seq_fifo_daily.nextval,trunc(v_in_date)-1,tradeid,userid,productcode,productname,initiator,tradenum,innum,outnum,CREATEDATE,servicenum,employeeid,departmentid
from xxd_fifo_temp;


commit;



end;

/
