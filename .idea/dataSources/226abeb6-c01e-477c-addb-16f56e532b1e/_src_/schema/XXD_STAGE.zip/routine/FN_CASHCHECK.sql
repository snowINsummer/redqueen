CREATE function fn_cashcheck(p_userid in number) return number is
  result number;
  /*
  返回结果0表示可以体现1表示禁止提现
  */
begin
  select count(1)
    into result
    from xxd_account_cashprohibit t
   where t.userid = p_userid;
  return(result);
end fn_cashcheck;
/
