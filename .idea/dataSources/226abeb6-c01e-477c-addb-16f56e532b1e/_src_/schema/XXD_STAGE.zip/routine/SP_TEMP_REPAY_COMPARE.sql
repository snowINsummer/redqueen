CREATE PROCEDURE SP_TEMP_REPAY_COMPARE IS

  /********************************************************
        功能：月滚动补录还款
              对提供的数据做筛选，匹配出正确用户和标的
        日期：20151201
  ********************************************************/
  --定义游标
  CURSOR C_USERID_BORROWID IS
    SELECT ID,USERID, BORROWID, PORDER
      FROM TEMP_REPAY_USERINFO_RESULT
     WHERE FLAG IN (2，3);

  C_ROW_ID C_USERID_BORROWID%rowtype;
  P_RESULT NUMBER;

BEGIN

  /*******************************数据匹配、筛选*****************************************/
  ---匹配用户
  INSERT INTO TEMP_CHECK_USERID
    (ID, USERID, PORDER, REPAYMENTTIME, FLAG)
    SELECT distinct RU.ID,
                    RA.USERID,
                    RU.PORDER,
                    RU.REPAYMENTTIME,
                    1 AS FLAG
      FROM TEMP_REPAY_USERINFO RU, XXD_REALNAME_APPRO RA
     WHERE RU.REALNAME = RA.REALNAME
       AND UPPER(RU.IDCARDNO) = UPPER(RA.IDCARDNO)
       AND RA.STATUS = 1
       AND NOT EXISTS
     (SELECT USERID FROM XXD_TRADE_PACK TP WHERE RA.USERID = TP.USERID)
       AND NOT EXISTS (SELECT USERID
              FROM XXD_BORROW_TENDER BT
             WHERE RA.USERID = BT.USERID)
       AND NOT EXISTS (SELECT USERID
              FROM XXD_OPTIMIZE_USERSCHEME OU
             WHERE RA.USERID = OU.USERID);

  ---清除用户脏数据(同一条件匹配出多个userid)
  DELETE FROM TEMP_CHECK_USERID
   WHERE ID IN
         (SELECT ID FROM TEMP_CHECK_USERID GROUP BY ID HAVING COUNT(*) > 1);

  ---匹配标的（仅有一个标的）
  INSERT INTO TEMP_CHECK_BORROWID
    (ID, USERID, BORROWID, FLAG)
    SELECT CU.ID, CU.USERID, B.BORROWID, 2 AS FLAG
      FROM TEMP_CHECK_USERID CU, XXD_BORROW B, XXD_BORROW_REPAYMENT BR
     WHERE CU.PORDER = BR.PORDER
       AND B.BORROWID = BR.BORROWID
       AND CU.USERID = B.USERID
       AND CU.USERID IN (select a.userid
                           from (select distinct userid from TEMP_CHECK_USERID) a, xxd_borrow b
                          where a.userid = b.userid
                          group by a.userid
                         having count(*) = 1);

  ---匹配标的（有多个标的）
  INSERT INTO TEMP_CHECK_BORROWID
    (ID, USERID, BORROWID, FLAG)
    SELECT CU.ID, CU.USERID, B.BORROWID, 3 AS FLAG
      FROM TEMP_CHECK_USERID CU, XXD_BORROW B, XXD_BORROW_REPAYMENT BR
     WHERE TRUNC(CU.REPAYMENTTIME) >= TRUNC(BR.REPAYMENTTIME) - 7
       AND TRUNC(CU.REPAYMENTTIME) <= TRUNC(BR.REPAYMENTTIME) + 7
       AND CU.PORDER = BR.PORDER
       AND B.BORROWID = BR.BORROWID
       AND CU.USERID = B.USERID
       AND CU.USERID IN (select a.userid
                           from (select distinct userid from TEMP_CHECK_USERID) a, xxd_borrow b
                          where a.userid = b.userid
                          group by a.userid
                         having count(*) > 1);

  /**************************写入结果集*************************************/
  ---成功匹配USERID和BORROWID
  INSERT INTO TEMP_REPAY_USERINFO_RESULT
    (ID,
     REALNAME,
     IDCARDNO,
     PORDER,
     REPAYMENTTIME,
     USERID,
     BORROWID,
     FLAG,
     REMARK)

    SELECT U.ID,
           U.REALNAME,
           U.IDCARDNO,
           U.PORDER,
           U.REPAYMENTTIME,
           BI.USERID,
           BI.BORROWID,
           BI.FLAG,
           CASE
             WHEN BI.FLAG = 2 THEN
              '匹配出系统用户和标的(用户只存在单个标的)'
             WHEN BI.FLAG = 3 THEN
              '匹配出系统用户和标的(用户存在多个标的)'
           END REMARK
      FROM TEMP_CHECK_BORROWID BI, TEMP_REPAY_USERINFO U
     WHERE BI.ID = U.ID;

  ---只能成功匹配USERID
  INSERT INTO TEMP_REPAY_USERINFO_RESULT
    (ID,
     REALNAME,
     IDCARDNO,
     PORDER,
     REPAYMENTTIME,
     USERID,
     BORROWID,
     FLAG,
     REMARK)

    SELECT U.ID,
           U.REALNAME,
           U.IDCARDNO,
           U.PORDER,
           U.REPAYMENTTIME,
           CU.USERID,
           NULL,
           1,
           '只匹配出系统用户，未匹配出标的'
      FROM TEMP_REPAY_USERINFO U,
           (SELECT *
              FROM TEMP_CHECK_USERID A
             WHERE NOT EXISTS (SELECT USERID
                      FROM TEMP_CHECK_BORROWID B
                     WHERE A.USERID = B.USERID)) CU
     WHERE U.ID = CU.ID;

  ----未能匹配出USERID和BORROWID
  INSERT INTO TEMP_REPAY_USERINFO_RESULT
    (ID,
     REALNAME,
     IDCARDNO,
     PORDER,
     REPAYMENTTIME,
     USERID,
     BORROWID,
     FLAG,
     REMARK)
    SELECT U.ID,
           U.REALNAME,
           U.IDCARDNO,
           U.PORDER,
           U.REPAYMENTTIME,
           NULL,
           NULL,
           0,
           '未匹配出系统用户'
      FROM TEMP_REPAY_USERINFO U
     WHERE U.ID NOT IN (SELECT ID FROM TEMP_CHECK_USERID);

  /*****************************游标调入子过程，做补录还款***************************/
  OPEN C_USERID_BORROWID;
  LOOP

    FETCH C_USERID_BORROWID
      INTO C_ROW_ID;

    EXIT WHEN C_USERID_BORROWID%NOTFOUND;

    --补录还款子过程
    SP_TEMP_REPAY_SUPPLEMENT(C_ROW_ID.BORROWID,
                             C_ROW_ID.USERID,
                             C_ROW_ID.PORDER,
                             P_RESULT);

    ---标记结果集（成功或不予处理）
    IF P_RESULT = 1 THEN

      UPDATE TEMP_REPAY_USERINFO_RESULT
         SET REMARK2 = '处理成功'
       WHERE BORROWID = C_ROW_ID.BORROWID
         AND USERID = C_ROW_ID.USERID
         AND PORDER = C_ROW_ID.PORDER
         AND ID=C_ROW_ID.ID;
    ELSE

      UPDATE TEMP_REPAY_USERINFO_RESULT
         SET REMARK2 = '已还，不予处理'
       WHERE BORROWID = C_ROW_ID.BORROWID
         AND USERID = C_ROW_ID.USERID
         AND PORDER = C_ROW_ID.PORDER
         AND ID=C_ROW_ID.ID;

    END IF;

  END LOOP;
  --关闭游标
  CLOSE C_USERID_BORROWID;

  /**********************************已还数据清零***************************/
  ----清零子过程
  SP_TEMP_REPAY_CLEAR;

end SP_TEMP_REPAY_COMPARE;

/
