CREATE procedure dt_proc_user is
  cursor cur_xxdai_user is
    select * from xxdai_user t  ;
  row_cur_user cur_xxdai_user%rowtype;
  m_count  integer;
  m_jointime date;
begin
  delete from xxd_user;
    delete from xxd_company;
 commit;
 insert into xxd_user
      (USERID,        USERNAME,       NICKNAME,       EMAIL,       MOBILE,
       HEADIMG,       PASSWORD,       PAYPASSWORD,    REGSOURCE,   REGION,
       REFERER,       EXPIREDATE,     STATUS,         ADDTIME,     ADDIP,
       MODIFYDATE,    USERNAME_MD5,   SECURITYQID,    SECURITYANS)
    values
      (0,             'sys',            0,              0,           0,
      'static/image/data/avatar/no_pic.gif',              null,           null,           1,           null,
      null,           sysdate,        1,              sysdate,      '127.0.0.1',
      sysdate,        null,           null,           null);
      commit;
  open cur_xxdai_user;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_xxdai_user
      into row_cur_user;
    exit when cur_xxdai_user%notfound;
    insert into xxd_user
      (USERID,        USERNAME,       NICKNAME,       EMAIL,       MOBILE,
       HEADIMG,       PASSWORD,       PAYPASSWORD,    REGSOURCE,   REGION,
       REFERER,       EXPIREDATE,     STATUS,         ADDTIME,     ADDIP,
       MODIFYDATE,    USERNAME_MD5,   SECURITYQID,    SECURITYANS)
    values
      (row_cur_user.id,       nvl(row_cur_user.username,'a||row_cur_user.id'),    null,                     row_cur_user.email,                               null,
       replace(row_cur_user.headimg,'image/','static/image/'),                    null,                   null,                     decode(trim(row_cur_user.regType),1,1,2,2,3,5,1),                                              null,
       null,                  nvl(FROM_UNIXTIME(row_cur_user.addtime),sysdate),   decode(row_cur_user.status,0,1,1,2,2,3,1),      nvl(FROM_UNIXTIME(row_cur_user.addtime),sysdate), row_cur_user.addip,
       sysdate,               null,                                               row_cur_user.securityqid, decode(trim(row_cur_user.securityans),null,null,FN_PASSUP(row_cur_user.securityans)));
    insert into xxd_company
           (id,                        property1,                                 property2)
    values
           (fn_md5(row_cur_user.ID),    FN_PASSUP(row_cur_user.logpassword) ,   FN_PASSUP(row_cur_user.paypassword))  ;
    if row_cur_user.popularizeagreement = 1      then
       --- adddate 时间在v5中没有记录，取用户注册时间 与活动开始时间中较大的
       if row_cur_user.ADDTIME >1407701689 then
           m_jointime := from_unixtime(row_cur_user.ADDTIME);
         else
           m_jointime := from_unixtime(1407701689);
        end if;
     insert into xxd_alliance_useragreement (  id,      userid,             status,    adddate,      addip)
            values (seq_alliance_useragreement.nextval, row_cur_user.id,    1,        m_jointime,   '127.0.0.1');
    end if;
      if mod(m_count,2000)=0 then
    commit;
    end if;
  end loop;
  commit;
  close cur_xxdai_user;
end dt_proc_user;



/
