CREATE procedure  compute_performance(in_date date)
is
v_in_date date:=in_date;

begin

step_performance(v_in_date);
insert into xxd_performance_log(id,procedure_name,remark,addtime)
values (seq_performance_log.nextval,'step_performance','1.步步高升业绩计算完成',sysdate);

commprod_performance(v_in_date);
insert into xxd_performance_log(id,procedure_name,remark,addtime)
values (seq_performance_log.nextval,'commprod_performance','2.七天大圣，月进斗金业绩计算完成',sysdate);

fund_performance(v_in_date);
insert into xxd_performance_log(id,procedure_name,remark,addtime)
values (seq_performance_log.nextval,'fund_performance','3.日日盈业绩计算完成',sysdate);

reglintst_performance(v_in_date);
insert into xxd_performance_log(id,procedure_name,remark,addtime)
values (seq_performance_log.nextval,'reglintst_performance','4.月月派业绩计算完成',sysdate);

optimize_performance(v_in_date);
insert into xxd_performance_log(id,procedure_name,remark,addtime)
values (seq_performance_log.nextval,'optimize_performance','5.新元宝业绩计算完成',sysdate);

tender_performance(v_in_date);
insert into xxd_performance_log(id,procedure_name,remark,addtime)
values (seq_performance_log.nextval,'tender_performance','6.散标业绩计算完成',sysdate);

commit;
end;

/
