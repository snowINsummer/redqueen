CREATE function calcage (idcard in varchar2)
return varchar2
is
age varchar2(10);
begin
if length(idcard)=18 then
age := to_number(to_char(sysdate,'yyyy'))-to_number(substr(idcard,7,4));
elsif length(idcard)=15 then
age := to_number(to_char(sysdate,'yyyy'))-to_number('19'||substr(idcard,7,2));
else 
age := '非身份证';
end if;
return age;
exception when others then
return '数据错误';
end;
/
