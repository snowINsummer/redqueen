CREATE function tterm(instra in varchar2)
return varchar2
is
terminalv varchar2(4000);
retval varchar2(20);
begin
terminalv:=instra;
if
lower(terminalv) like '%msie%' and (lower(terminalv) like '360se' or lower(terminalv) like '360ee')
or
lower(terminalv) like '%se%' and lower(terminalv) like '%metasr%' and lower(terminalv) like '%msie%'
or
lower(terminalv) like '%tencenttraveler%'
or
lower(terminalv) like '%qqbrowser%'
or
lower(terminalv) like '%mozilla%'
or
lower(terminalv) like '%maxthon%' and lower(terminalv) like '%msie%'
or
lower(terminalv) like '%ucbrowser%' and lower(terminalv) like '%ucweb%'
or
lower(terminalv) like '%theworld%' and lower(terminalv) like '%msie%'
or
lower(terminalv) like '%avant%' and lower(terminalv) like '%msie%'
or
lower(terminalv) like '%baidubrowser%'
or
lower(terminalv) like '%lbbbrowser%'
or
lower(terminalv) like '%opera%' and lower(terminalv) like '%mozilla%'
or
lower(terminalv) like '%chrome%' and lower(terminalv) like '%safari%'
or
lower(terminalv) like '%safari%' and lower(terminalv) like '%chrome%'
or
lower(terminalv) like '%msie 11.0%' and lower(terminalv) like '%mozilla%'
or
lower(terminalv) like '%msie 10.0%' and lower(terminalv) like '%mozilla%'
or
lower(terminalv) like '%msie 9.0%' and lower(terminalv) like '%mozilla%'
or
lower(terminalv) like '%msie 8.0%' and lower(terminalv) like '%mozilla%'
or
lower(terminalv) like '%msie 7.0%' and lower(terminalv) like '%mozilla%'
or
lower(terminalv) like '%msie 6.0%' and lower(terminalv) like '%mozilla%'
or
lower(terminalv) like '%msie 5%' and lower(terminalv) like '%mozilla%'
or
lower(terminalv) like '%msie 4%' and lower(terminalv) like '%mozilla%'
then
  retval:='pc';
else
  retval:='fei';
return retval;
end if;
end;
/
