CREATE procedure reglintst_performance(in_date date)
is
v_in_date date:=in_date;

begin

--计算月月派业绩


/*insert into xxd_product_out(id,outtradeid,userid,productcode,productname,outtradenum,tradeid,tradenum,CREATEDATE,servicenum,employeeid,initiator,OUTTYPE,KEEPDAYS,terms,departmentid)
select  seq_product_out.nextval,outtradeid,userid,productcode,productname,outtradenum,tradeid,tradenum,endtime,servicenum,employeeid,initiator,OUTTYPE,KEEPDAYS,terms,dept4id from
(select  a.joinid outtradeid,a.userid,97 productcode,'月月派' productname,a.account outtradenum,a.joinid tradeid,a.account tradenum,a.endtime,b.servicenum,b.employeeid,1 initiator,2 OUTTYPE,null KEEPDAYS,a.terms,b.dept4id
from xxd_reglintst_join a inner join xxd_order_record b
on a.joinid=b.orderno
where expiretime>=trunc(v_in_date)-1 and expiretime<trunc(v_in_date)
and status<>3
union all
select  a.joinid,a.userid,97,'月月派',a.account ,a.joinid,a.account,a.endtime,b.servicenum,b.employeeid,1 initiator,1 OUTTYPE,trunc(a.endtime-a.addtime) KEEPDAYS,a.terms,b.dept4id
from xxd_reglintst_join a inner join xxd_order_record b
on a.joinid=b.orderno
where endtime>=trunc(v_in_date)-1 and endtime<trunc(v_in_date));
*/

--生成退出信息，包含正常退出和提前退出
insert into xxd_product_out(id,outtradeid,userid,productcode,productname,outtradenum,tradeid,tradenum,CREATEDATE,servicenum,employeeid,initiator,OUTTYPE,KEEPDAYS,terms,departmentid)
select  seq_product_out.nextval,outtradeid,userid,productcode,productname,outtradenum,tradeid,tradenum,endtime,servicenum,employeeid,initiator,OUTTYPE,KEEPDAYS,terms,dept4id from
(select  a.joinid outtradeid,a.userid,97 productcode,'月月派' productname,a.account OUTTRADENUM,a.joinid tradeid,a.account tradenum,a.endtime,b.servicenum,b.employeeid,1 initiator,
case when a.status=2 then 2 when a.status=3 then 1 end OUTTYPE, case when a.status=3 then trunc(a.endtime-a.addtime) end KEEPDAYS,a.terms,b.dept4id
from xxd_reglintst_join a inner join xxd_order_record b
on a.joinid=b.orderno
where endtime>=trunc(v_in_date)-1 and endtime<trunc(v_in_date)
and b.ptype=97);


--生成利息
insert into xxd_product_out(id,outtradeid,userid,productcode,productname,outtradenum,tradeid,tradenum,CREATEDATE,servicenum,employeeid,initiator,OUTTYPE,KEEPDAYS,terms,departmentid,interest)
select  seq_product_out.nextval,outtradeid,userid,productcode,productname,outtradenum,tradeid,tradenum,realtime,servicenum,employeeid,initiator,OUTTYPE,KEEPDAYS,terms,dept4id,realinterest from
(select  a.joinid outtradeid,a.userid,97 productcode,'月月派' productname,0 OUTTRADENUM,a.joinid tradeid,0 tradenum,a.realtime,b.servicenum,b.employeeid,2 initiator,
3 OUTTYPE,null keepdays,null terms,b.dept4id,a.realinterest
from xxd_reglintst_repayment a inner join xxd_order_record b
on a.joinid=b.orderno
where realtime>=trunc(v_in_date)-1 and realtime<trunc(v_in_date)
and b.ptype=97);




commit;


--计算每日年化

insert into xxd_performance_daily(id,adddate,userid,servicenum,employeeid,ptype,departmentid,addamount,scaleamount,annualamount,outtype)
select seq_performance_daily.nextval,addtime,userid,servicenum,employeeid,ptype,departmentid,addaccount,addaccount scaleamount,annual_amount,outtype from
(select addtime,userid,servicenum,employeeid,ptype,departmentid,sum(addaccount) addaccount,sum(scaleamount) scaleamount,sum(annual_amount) annual_amount,outtype from
(select trunc(addtime) addtime,userid,nvl(servicenum,0) servicenum,nvl(employeeid,0) employeeid,ptype,nvl(dept4id,0) departmentid,addaccount,addaccount scaleamount,
addaccount*terms/12 annual_amount,null outtype
from xxd_order_record a
where ptype=97
and addtime>=trunc(v_in_date)-1 and  addtime<trunc(v_in_date)
and userid not in (select userid from xxd_account_cashprohibit)
union all
select trunc(createdate),userid,nvl(servicenum,0) servicenum,nvl(employeeid,0) employeeid,productcode,nvl(departmentid,0) departmentid,0,(-1*tradenum) tradenum,
case when round(-1*(tradenum*terms/12-tradenum*keepdays/360),6)>0 then 0
     else round(-1*(tradenum*terms/12-tradenum*keepdays/360),6) end annual_amount,1 outtype
from xxd_product_out b
where productcode=97
and OUTTYPE=1
and createdate>=trunc(v_in_date)-1 and  createdate<trunc(v_in_date)
and userid not in (select userid from xxd_account_cashprohibit))
group by addtime,userid,servicenum,employeeid,ptype,departmentid,outtype);


commit;


--计算每月年化


delete from xxd_performance_month where PTYPE=97 and ADDDATE=trunc(trunc(v_in_date)-1,'month');

insert into xxd_performance_month(id,adddate,employeeid,ptype,addamount,scaleamount,annualamount,departmentid)
select seq_performance_month.nextval,adddate,employeeid,ptype,addamount,scaleamount,annualamount,departmentid from
(select trunc(adddate,'month') adddate,employeeid,ptype,sum(addamount) addamount,
sum(scaleamount) scaleamount,
sum(annualamount) annualamount,departmentid
from xxd_performance_daily
where adddate>=trunc(trunc(v_in_date)-1,'month')
and adddate<add_months(trunc(trunc(v_in_date)-1,'month'),1)
and ptype=97
group by trunc(adddate,'month'),employeeid,ptype,departmentid);


/*
merge into (select * from xxd_performance_month where  ptype=97 and adddate=trunc(trunc(v_in_date)-1,'month')) a
using (select trunc(adddate,'month') adddate,employeeid,ptype,sum(addamount) addamount,sum(scaleamount) scaleamount,sum(annualamount) annualamount,departmentid from xxd_performance_daily
where adddate=trunc(v_in_date)-1
and ptype=97
group by trunc(adddate,'month'),employeeid,ptype,departmentid) b
on (a.adddate=b.adddate and nvl(a.employeeid,0)=nvl(b.employeeid,0) and a.ptype=b.ptype and nvl(a.departmentid,0)=nvl(b.departmentid,0))
when matched  then
  update set a.addamount=a.addamount+b.addamount,
         a.scaleamount=a.scaleamount+b.scaleamount,
         a.annualamount=a.annualamount+b.annualamount
when not matched then
  insert values ( seq_performance_month.nextval,b.adddate,b.employeeid,b.ptype,b.addamount,b.scaleamount,b.annualamount,b.departmentid);
*/

commit;

end;


/
