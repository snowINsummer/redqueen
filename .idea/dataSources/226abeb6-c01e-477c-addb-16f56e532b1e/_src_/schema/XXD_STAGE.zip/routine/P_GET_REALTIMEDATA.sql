CREATE procedure p_get_realtimedata(in_date date)
is
  v_in_date date:=in_date;
  v_loginpchour  number(22);
  v_loginpctotal  number(22);
  v_loginpthour  number(22);
  v_loginpttotal  number(22);
  v_registerhour  number(22);
  v_registertotal  number(22);
  v_realnamehour  number(22);
  v_realnametotal  number(22);
  v_bankbindhour  number(22);
  v_bankbindtotal  number(22);
  v_investpchour  number(22);
  v_investpctotal  number(22);
  v_investpthour  number(22);
  v_investpttotal  number(22);
  v_investahour  number(22,2);
  v_investatotal  number(22,2);
  v_onrechargehour  number(22,2);
  v_onrechargetotal number(22,2);
  v_offrechargehour number(22,2);
  v_offrechargetotal number(22,2);
  v_timebucket  number(2);
  v_begindate  date;
  v_enddate  date;
begin


  --1.登录人数
  select count(min(userid)) into v_loginpchour from xxd_user_logins where logintime >= trunc((v_in_date-1/24),'HH') and logintime < trunc(v_in_date,'HH')  and userid not in (select userid from xxd_account_cashprohibit)  group by userid;
  select count(min(userid)) into v_loginpctotal from xxd_user_logins where logintime >= trunc(v_in_date-1/24) and logintime < trunc(v_in_date,'HH') and userid not in (select userid from xxd_account_cashprohibit) group by userid;

  --2.登录人次
  select count(userid) into v_loginpthour from xxd_user_logins where logintime >= trunc((v_in_date-1/24),'HH') and logintime < trunc(v_in_date,'HH') and userid not in (select userid from xxd_account_cashprohibit);
  select count(userid) into v_loginpttotal from xxd_user_logins where logintime >= trunc(v_in_date-1/24) and logintime < trunc(v_in_date,'HH') and userid not in (select userid from xxd_account_cashprohibit);

  --3.注册人数
  select count(userid) into v_registerhour from xxd_user where addtime >= trunc((v_in_date-1/24),'HH') and addtime < trunc(v_in_date,'HH') and userid not in (select userid from xxd_account_cashprohibit);
  select count(userid) into v_registertotal from xxd_user where addtime >= trunc(v_in_date-1/24) and addtime < trunc(v_in_date,'HH') and userid not in (select userid from xxd_account_cashprohibit);

  --4.实名认证人数
  select count(userid) into v_realnamehour from xxd_realname_appro where status = 1 and approdate >= trunc((v_in_date-1/24),'HH') and approdate < trunc(v_in_date,'HH') and userid not in (select userid from xxd_account_cashprohibit);
  select count(userid) into v_realnametotal from xxd_realname_appro where status = 1 and approdate >= trunc(v_in_date-1/24) and approdate < trunc(v_in_date,'HH') and userid not in (select userid from xxd_account_cashprohibit);

  --5.绑定银行卡人数
  select count(min(userid)) into v_bankbindhour from xxd_user_bank where banded=1 and addtime >= trunc((v_in_date-1/24),'HH') and addtime < trunc(v_in_date,'HH') and userid not in (select userid from xxd_account_cashprohibit)  group by userid;
  select count(min(userid)) into v_bankbindtotal from xxd_user_bank where banded=1 and addtime >= trunc(v_in_date-1/24) and addtime < trunc(v_in_date,'HH') and userid not in (select userid from xxd_account_cashprohibit) group by userid;

  --6.投资人数
  select count(min(userid)) into v_investpchour from xxd_order_record where initiator=1 and addtime >= trunc((v_in_date-1/24),'HH') and addtime < trunc(v_in_date,'HH')  and userid not in (select userid from xxd_account_cashprohibit) group by userid;
  select count(min(userid)) into v_investpctotal from xxd_order_record  where initiator=1 and addtime >= trunc(v_in_date-1/24) and addtime < trunc(v_in_date,'HH')  and userid not in (select userid from xxd_account_cashprohibit) group by userid;

  --7.投资人次
  select count(userid) into v_investpthour from xxd_order_record  where initiator=1 and addtime >= trunc((v_in_date-1/24),'HH') and addtime < trunc(v_in_date,'HH')  and userid not in (select userid from xxd_account_cashprohibit);
  select count(userid) into v_investpttotal from xxd_order_record where initiator=1 and addtime >= trunc(v_in_date-1/24) and addtime < trunc(v_in_date,'HH')  and userid not in (select userid from xxd_account_cashprohibit);

  --8.投资额(万)
  select nvl(sum(addaccount)/10000,0) into v_investahour from xxd_order_record where initiator=1 and addtime >= trunc((v_in_date-1/24),'HH') and addtime < trunc(v_in_date,'HH') and userid not in (select userid from xxd_account_cashprohibit);
  select nvl(sum(addaccount)/10000,0) into v_investatotal from xxd_order_record  where initiator=1 and addtime >= trunc(v_in_date-1/24) and addtime < trunc(v_in_date,'HH') and userid not in (select userid from xxd_account_cashprohibit);

  --9.线上充值
  select nvl(sum(amount),0) into v_onrechargehour  from xxd_account_recharge where status=1 and type=1 and rechargeid not in (select rechargeid from xxd_borrow_offlinerepay) and verifydate >= trunc((v_in_date-1/24),'HH') and verifydate < trunc(v_in_date,'HH') and userid not in (select userid from xxd_account_cashprohibit);
  select nvl(sum(amount),0) into v_onrechargetotal from xxd_account_recharge where status=1 and type=1 and rechargeid not in (select rechargeid from xxd_borrow_offlinerepay) and verifydate >= trunc(v_in_date-1/24) and verifydate < trunc(v_in_date,'HH') and userid not in (select userid from xxd_account_cashprohibit);

  --10.线下充值
  select nvl(sum(amount),0) into v_offrechargehour from xxd_account_recharge where status=1 and type=1 and rechargeid in (select rechargeid from xxd_borrow_offlinerepay) and verifydate >= trunc((v_in_date-1/24),'HH') and verifydate < trunc(v_in_date,'HH') and userid not in (select userid from xxd_account_cashprohibit);
  select nvl(sum(amount),0) into v_offrechargetotal from xxd_account_recharge where status=1 and type=1 and rechargeid in (select rechargeid from xxd_borrow_offlinerepay) and verifydate >= trunc(v_in_date-1/24) and verifydate < trunc(v_in_date,'HH') and userid not in (select userid from xxd_account_cashprohibit);


  select to_char(trunc(v_in_date-1/24,'HH'),'hh24'),trunc((v_in_date-1/24),'HH'),trunc(v_in_date,'HH')-1/86400 into v_timebucket,v_begindate,v_enddate from dual;

  insert into xxd_realtimedata (id,addtime,begindate,enddate,timebucket,loginpchour,loginpctotal,loginpthour,loginpttotal,registerhour,registertotal,realnamehour,realnametotal,bankbindhour,bankbindtotal,investpchour,investpctotal,investpthour,investpttotal,investahour,investatotal,ONRECHARGEHOUR,ONRECHARGETOTAL,OFFRECHARGEHOUR,OFFRECHARGETOTAL)
  values (seq_xxd_realtimedata.nextval,v_in_date,v_begindate,v_enddate,v_timebucket,v_loginpchour,v_loginpctotal,v_loginpthour,v_loginpttotal,v_registerhour,v_registertotal,v_realnamehour,v_realnametotal,v_bankbindhour,v_bankbindtotal,v_investpchour,v_investpctotal,v_investpthour,v_investpttotal,v_investahour,v_investatotal,v_onrechargehour,v_onrechargetotal,v_offrechargehour,v_offrechargetotal);

  commit;
end p_get_realtimedata;
/
