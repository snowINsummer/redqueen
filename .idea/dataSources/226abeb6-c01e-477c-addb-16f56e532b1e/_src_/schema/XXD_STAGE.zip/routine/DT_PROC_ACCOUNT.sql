CREATE procedure dt_proc_account(p_commitrow in number) is
  --   hummer 20141118  用户账户，充值，体现冻结等数据
  --  账户
  cursor cur_account is
    select t.*
      from xxdai_account t, xxdai_user u
     where t.userid = u.id
     order by t.userid;
  row_cur_account cur_account%rowtype;
  --  账户待还处理
  cursor cur_accountrepay is
  select sum(t.repaymentaccount) repayment,b.userid from xxdai_borrow_repayment  t,xxdai_borrow b
  where t.status =0
   and t.borrowid = b.id
  group by b.userid
  having sum(t.repaymentaccount)>0;
  row_cur_accountrepay cur_accountrepay%rowtype;

  -- 账户日志
  cursor cur_account_log is
   select t.*
     from xxdai_account_logs t,xxdai_user u
     where t.userid = u.id ;
  row_cur_alogs cur_account_log%rowtype;
  --  账户审计表
  cursor cur_acountaudit is
  select t.*
    from xxdai_account_audit t;
  row_cur_accountaudit cur_acountaudit%rowtype;
  --  充值记录
  cursor cur_a_recharge is
  select t.*
    from xxdai_account_recharge t ,xxdai_user u
    where t.userid = u.id ;
  row_cur_a_recharge cur_a_recharge%rowtype;
  --  体现记录
  cursor cur_a_cash is
  select t.* ,ra.realname
     from xxdai_account_cash t, xxdai_realname_appro ra
 where t.userid = ra.userid(+)
   and ra.ispassed = 1;
  row_cur_a_cash cur_a_cash%rowtype;
  m_count         integer;
  m_userid        integer;
  m_str_sql       varchar2(200);
  m_orderno       varchar2(500);
  m_old_type      integer;
  -- 合作伙伴 id
  m_partnerid     integer;
  --  银行编号
  m_bankcode      varchar2(20);
  m_old_bankcode  varchar2(50);
  m_moneytype     integer;
begin
   --  个人账户
  delete from xxd_account;
  commit;
  m_count := 0;
  -- 基础数据处理
  open cur_account;
  loop
    m_count := m_count + 1;
    fetch cur_account
      into row_cur_account;
    exit when cur_account%notfound;
    m_userid := row_cur_account.userid;
    insert into xxd_account
      (userid,       pcode,       usable,       frozen,
       collection,       repayment,       accounttotal,       lastyearmonth)
    values
      (m_userid,       '1001',       row_cur_account.usemoney,       row_cur_account.nousemoney,
       row_cur_account.collectionmoney,       0,       0,       to_char(sysdate, 'yyyymm'));
    insert into xxd_account
      (userid,       pcode,       usable,       frozen,
       collection,       repayment,       accounttotal,       lastyearmonth)
    values
      (m_userid, '1002', 0, 0, 0, 0, 0, to_char(sysdate, 'yyyymm'));
    insert into xxd_account
      (userid,       pcode,       usable,       frozen,
       collection,       repayment,       accounttotal,       lastyearmonth)
    values
      (m_userid, '1003', 0, 0, 0, 0, 0, to_char(sysdate, 'yyyymm'));
    insert into xxd_account
      (userid,       pcode,       usable,       frozen,
       collection,       repayment,       accounttotal,       lastyearmonth)
    values
      (m_userid, '1004', 0, 0, 0, 0, 0, to_char(sysdate, 'yyyymm'));
    if mod(m_count, p_commitrow) = 0 then
      commit;
    end if;
  end loop;
  commit;
  close cur_account;
  -- 处理待还数据
  execute immediate 'alter trigger trig_a_u_xxd_account disable';
  m_count := 0;
  open cur_accountrepay;
    loop
       m_count := m_count + 1;
       fetch cur_accountrepay
        into row_cur_accountrepay;
        exit when cur_accountrepay%notfound;
        update xxd_account t
           set t.repayment =  row_cur_accountrepay.repayment
         where t.userid = row_cur_accountrepay.userid
          and t.pcode ='1001';
          commit;
    end loop;
    commit;
  close cur_accountrepay;
   --  总额处理
   update xxd_account t
      set t.accounttotal =  t.usable + t.frozen+t.collection-t.repayment
    where t.pcode ='1001';
    commit;
    execute immediate 'alter trigger trig_a_u_xxd_account enable';
     --  账户日志表处理
  m_str_sql:=  'truncate  table  xxd_account_log';
  execute immediate m_str_sql;
  m_count := 0;
  open cur_account_log;
  loop
     m_count:=m_count+1;
     fetch cur_account_log
      into row_cur_alogs;
      exit when cur_account_log%notfound;
      if row_cur_alogs.moneytype =0 then
        m_moneytype:=2;
      elsif row_cur_alogs.moneytype =1 then
        m_moneytype:=1;
      else
         if instr(row_cur_alogs.remark,'冻结') >0 then
           m_moneytype:=5;
         end if;
          if instr(row_cur_alogs.remark,'解冻') >0 then
           m_moneytype:=6;
         end if;
         if   row_cur_alogs.operatetype = 'vip_cold' then
           m_moneytype:=5;
         end if ;
         if    row_cur_alogs.operatetype = 'cash_faild' then
           m_moneytype:=6;
         end if ;
          if    row_cur_alogs.operatetype = 'signing_false' then
           m_moneytype:=6;
         end if ;
          if    row_cur_alogs.operatetype = 'cold_desposit' then
           m_moneytype:=5;
         end if ;
         if    row_cur_alogs.operatetype = 'student_borrow_fee' then
           m_moneytype:=6;
         end if ;
         if    row_cur_alogs.operatetype = 'cash_cold' then
           m_moneytype:=5;
         end if ;
         if    row_cur_alogs.operatetype = 'invest_false' then
           m_moneytype:=6;
         end if ;
      end if;
      insert into xxd_account_log
      (  id           ,  userid       ,  busiid       ,  pcode        ,
         usable       ,  frozen       ,  collection   ,  repayment    ,
         accounttotal ,  addtime      ,  busitime     ,  operatortype ,
         moneytype    ,  workmoney    ,  schemeid     ,  addip        ,
         remark       )
    values
     (row_cur_alogs.id,          row_cur_alogs.userid,                   nvl(to_char(row_cur_alogs.busiid),' '),                  '1001',
      row_cur_alogs.usemoney,    row_cur_alogs.nousemoney,               row_cur_alogs.collectionmoney,          0,
      row_cur_alogs.totalmoney,  from_unixtime(row_cur_alogs.addtime),   from_unixtime(row_cur_alogs.addtime),   nvl(row_cur_alogs.operatetype,'V5空'),
      m_moneytype ,  row_cur_alogs.operatemoney,             0,                                      nvl(row_cur_alogs.addip,'127.0.0.1V5空'),
      nvl(row_cur_alogs.remark,' ')
      );
   if mod(m_count, p_commitrow) = 0 then
      commit;
   end if;
  end loop;
  commit;
  close cur_account_log;
  -- 账户审计记录
     m_str_sql:=  'truncate  table  xxd_account_audit';
  execute immediate m_str_sql;
  m_count := 0;
  open cur_acountaudit;
  loop
     m_count:=m_count+1;
     fetch cur_acountaudit
      into row_cur_accountaudit;
      exit when cur_acountaudit%notfound;
      insert into xxd_account_audit
      (  auditid      ,  auditdate    ,  userid       ,  pcode        ,
         usable       ,  frozen       ,  collection   ,  accounttotal )
    values
     ( row_cur_accountaudit.id ,to_date(row_cur_accountaudit.addtime,'yyyy-mm-dd hh24:mi:ss'),row_cur_accountaudit.userid,'1001',
       row_cur_accountaudit.usemoney,row_cur_accountaudit.nousemoney,row_cur_accountaudit.collectionmoney,row_cur_accountaudit.totalmoney
      );
   if mod(m_count, p_commitrow) = 0 then
      commit;
   end if;
  end loop;
  commit;
  close cur_acountaudit;
  --  充值记录
  delete from xxd_account_recharge;
  commit;
  m_count := 0;
  open cur_a_recharge;
  loop
    m_count := m_count+1;
    fetch cur_a_recharge into row_cur_a_recharge;
    exit when cur_a_recharge%notfound;
    m_orderno := row_cur_a_recharge.ORDERNO;
    if lengthb(row_cur_a_recharge.ORDERNO)>50 then
       m_orderno := ' ';--  处理超长单号，进过查询超长都是乱码的
    end if;
    m_orderno :=nvl(m_orderno,' ');
    --  线上线下
    m_old_type := row_cur_a_recharge.type;
    m_old_bankcode :=row_cur_a_recharge.bankorderno;

    select decode(m_old_bankcode,'31','icbc','32','gopay','35','pingan','36','alipay','37','yeepay','38','icbc','39','FYYX','40','FYYH','icbc') into m_bankcode from dual;
    --  线上
    if m_old_type =1 then
      select decode(m_old_bankcode,'31',37,'32',32,'37',37,'38',0,0)
        into m_partnerid
        from dual;
     else
      --  线下
      select decode(m_old_bankcode,'31',0,'32',43,'35',0,'36',36,'37',44,'39',0,'40',0,'41',0,0)
        into m_partnerid
        from dual;
    end if;
    insert into xxd_account_recharge
    (  rechargeid   ,  userid       ,  type         ,  partnerid    ,  bankcode     ,
       orderno      ,  amount       ,  fee          ,  terminalver  ,  addtime      ,
       rechargeip   ,  verifyuserid ,  verifydate   ,  verifyip     ,  status       ,
       remark       )
   values(   row_cur_a_recharge.ID        ,  row_cur_a_recharge.USERID ,              1,         m_partnerid,        m_bankcode,
             m_orderno    ,  row_cur_a_recharge.RECHARGEMONEY ,       0,       ' ',   from_unixtime(row_cur_a_recharge.RECHARGETIME),
             row_cur_a_recharge.rechargeip,  row_cur_a_recharge.verifyuserid,  from_unixtime(row_cur_a_recharge.verifytime),row_cur_a_recharge.verifyip,row_cur_a_recharge.status,
             row_cur_a_recharge.verifyremark );
  if mod(m_count, p_commitrow) = 0 then
      commit;
   end if;
  end loop;
  commit;
  close cur_a_recharge;
--  体现处理
   /*
状态： V5 0审核中  1待放款     -1被拒绝    2已放款    -2放款失败  -7已忽略
状态： V6 1审核中  2提现中     -1审核失败  3提现成功  -2提现失败'  -1
其它 置-1*/

   m_count :=0;
  delete  from xxd_account_cash ;
  commit;
  open cur_a_cash;
  loop
    m_count:= m_count+1;
    fetch cur_a_cash into row_cur_a_cash;
    exit when cur_a_cash%notfound;
    insert into xxd_account_cash
           (cashid         ,  userid         ,  amount         ,  bankcode       ,  account        ,
            accountname    ,  fee            ,  realamount     ,  terminalver    ,  addtime        ,
            addip          ,  verifyoperator ,  verifydate     ,  verifyip       ,  verifyremark   ,
            remitoperator  ,  remitdate      ,  remitip        ,  remitremark    ,  status         ,
            branchname)
      values(row_cur_a_cash.id,row_cur_a_cash.userid,row_cur_a_cash.cashamount,' ',substr(nvl(replace(row_cur_a_cash.bankcode,' ',''),' '),1,20),
             nvl(trim(row_cur_a_cash.realname),' '),row_cur_a_cash.cashfee,row_cur_a_cash.realamount,'历史数据',from_unixtime(row_cur_a_cash.cashtime),
             row_cur_a_cash.caship,row_cur_a_cash.verifyuserid,from_unixtime(row_cur_a_cash.verifytime),row_cur_a_cash.verifyip,row_cur_a_cash.verifyremark,
             row_cur_a_cash.remituserid,from_unixtime(row_cur_a_cash.remittime),row_cur_a_cash.remitip,' ',
             decode(row_cur_a_cash.cashstatus,0,1,1,2,2,3,-1,-1,-2,-2,-7,-1,-1),trim(row_cur_a_cash.bankname));

    if mod(m_count, p_commitrow) = 0 then
      commit;
   end if;
  end loop;
  -- 更新提现银汉信息
      update xxd_account_cash t
         set t.bankcode =
             (select b.bankcode
                from xxd_user_bank b
               where b.userid = t.userid
                 and t.account = b.bankaccount
                 and b.banded = 1)
       where exists (select '1'
                       from xxd_user_bank ba
                      where ba.userid = t.userid
                        and t.account = ba.bankaccount
                        and ba.banded = 1);
  commit;
  close cur_a_cash;
end dt_proc_account;



/
