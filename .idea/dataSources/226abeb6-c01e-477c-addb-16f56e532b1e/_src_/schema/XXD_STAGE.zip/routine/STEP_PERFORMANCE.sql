CREATE procedure step_performance(in_date date)
is
v_in_date date:=in_date;
cursor ck is
select stepquitid,userid,stepjoinid,quitaccount outaccount,addtime,interest from xxd_step_quit
where addtime>=trunc(v_in_date)-1 and addtime<trunc(v_in_date);

ck_rec ck%rowtype;
servicenum varchar2(20);


begin

--计算步步高升业绩

execute immediate 'truncate table  xxd_product_temp';

--生成每日计算数据=昨天日结+今天的增量
insert into xxd_product_temp(indate,tradeid,userid,productcode,productname,tradenum,innum,outnum,CREATEDATE,servicenum,employeeid,departmentid)
select
trunc(a.addtime)，
a.stepjoinid,a.userid,'96','步步高升',a.account,a.account,0,a.addtime,b.servicenum,b.employeeid,b.dept4id
from xxd_step_join a left join xxd_order_record b
on a.stepjoinid =b.orderno
where a.addtime>=trunc(v_in_date)-1 and a.addtime<trunc(v_in_date)
union all
select indate,tradeid,userid,productcode,productname,tradenum,innum,outnum,CREATEDATE,servicenum,employeeid,departmentid
from xxd_product_daily
where indate=trunc(v_in_date)-2
and productcode=96
and tradenum>0;

commit;

open ck;
  loop
    fetch ck into  ck_rec;
    exit when ck%notfound;

--计算去掉退出后的金额
update xxd_product_temp set outnum=outnum+ck_rec.outaccount,tradenum=tradenum-ck_rec.outaccount where tradeid=ck_rec.stepjoinid;


--计算退出信息
insert into xxd_product_out(id,outtradeid,userid,productcode,productname,outtradenum,tradeid,tradenum,CREATEDATE,servicenum,employeeid,initiator,keepdays,departmentid,interest)
select seq_product_out.nextval,ck_rec.stepquitid,ck_rec.userid,'96','步步高升',ck_rec.outaccount,ck_rec.stepjoinid,ck_rec.outaccount,ck_rec.addtime,servicenum,employeeid,
1,trunc(ck_rec.addtime-createdate),departmentid,ck_rec.interest from
xxd_product_temp  where tradeid=ck_rec.stepjoinid;


commit;

    end loop;
    close ck;

--计算完毕，生成新的日结表
insert into xxd_product_daily(id,indate,tradeid,userid,productcode,productname,tradenum,innum,outnum,CREATEDATE,servicenum,employeeid,departmentid)
select seq_product_daily.nextval,trunc(v_in_date)-1,tradeid,userid,productcode,productname,tradenum,innum,outnum,CREATEDATE,servicenum,employeeid,departmentid from xxd_product_temp;


commit;

--计算每日年化
insert into xxd_performance_daily(id,adddate,userid,servicenum,employeeid,departmentid,ptype,addamount,scaleamount,annualamount)
select seq_performance_daily.nextval,indate,userid,servicenum,employeeid,departmentid,productcode,addamount,scaleamount,annualamount from(
select  indate,userid,nvl(servicenum,0) servicenum,nvl(employeeid,0) employeeid,nvl(departmentid,0) departmentid,productcode,
sum(case when createdate>=trunc(v_in_date)-1 and createdate<trunc(v_in_date) then innum else 0 end) addamount,
sum(tradenum) scaleamount,
round(sum(tradenum)/360,6) annualamount
from xxd_product_daily
where indate=trunc(v_in_date)-1
and productcode=96
and userid not in (select userid from xxd_account_cashprohibit)
group by indate,userid,nvl(servicenum,0),nvl(employeeid,0),nvl(departmentid,0),productcode);

--计算每月年化
--步步高升规模业绩等于过夜资金，所以先清0
update  xxd_performance_month set scaleamount=0 where  ptype=96 and adddate=trunc(trunc(v_in_date)-1,'month');

merge into (select * from xxd_performance_month where  ptype=96 and adddate=trunc(trunc(v_in_date)-1,'month')) a
using (select trunc(adddate,'month') adddate,employeeid,ptype,sum(addamount) addamount,sum(scaleamount) scaleamount,sum(annualamount) annualamount,departmentid
from xxd_performance_daily
where adddate=trunc(v_in_date)-1
and ptype=96
group by trunc(adddate,'month'),employeeid,ptype,departmentid) b
on (a.adddate=b.adddate and a.employeeid=b.employeeid and a.ptype=b.ptype and a.departmentid=b.departmentid)
when matched  then
  update set a.addamount=a.addamount+b.addamount,
         a.scaleamount=b.scaleamount,
         a.annualamount=a.annualamount+b.annualamount
when not matched then
  insert values ( seq_performance_month.nextval,b.adddate,b.employeeid,b.ptype,b.addamount,b.scaleamount,b.annualamount,b.departmentid,null,null);

commit;

end;


/
