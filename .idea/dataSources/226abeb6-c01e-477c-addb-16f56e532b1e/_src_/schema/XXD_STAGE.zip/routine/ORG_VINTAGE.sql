CREATE procedure ORG_VINTAGE(p_borrowid in VARCHAR2) is
 m_count  integer:=0;
begin
loop
merge into temp_vintage t
using (select b.borrowid,to_char(b.addtime,'yyyymm') addtime,b.timelimit,sum(br.repaymentaccount) srepay,
to_char(add_months(to_date('20160101','yyyymmdd'),m_count),'yyyymm') repaytime,
decode(trunc((add_months(to_date('20160201','yyyymmdd'),m_count)-min(repaymenttime))/30),0,'m1',1,'m2',2,'m3',3,'m4',4,'m5',5,'m6','m7') ld
         from xxd_borrow b,xxd_borrow_repayment br
        where b.borrowid = br.borrowid
          --and br.repaymenttime<add_months(to_date('20160201','yyyymmdd'),m_count)
          and nvl(br.repaymentyestime,sysdate)>add_months(to_date('20160201','yyyymmdd'),m_count)
          and b.borrowid=p_borrowid
          and b.borrowid in (select borrowid from xxd_borrow_repayment
                              where repaymenttime<add_months(to_date('20160201','yyyymmdd'),m_count)
                                and nvl(repaymentyestime,sysdate)>add_months(to_date('20160201','yyyymmdd'),m_count))
        group by b.borrowid,b.addtime,b.timelimit
       ) e
   on (t.addtime=e.addtime and t.timelimit=e.timelimit and t.repaymenttime=e.repaytime  and t.laterdays=e.ld)
 when matched then update set t.money=t.money+e.srepay ;
commit;
m_count:=m_count+1;
exit when m_count> 15;
end loop;
end ORG_VINTAGE;
/
