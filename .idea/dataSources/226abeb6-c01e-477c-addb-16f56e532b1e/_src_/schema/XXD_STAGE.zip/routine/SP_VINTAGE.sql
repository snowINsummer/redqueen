CREATE procedure SP_VINTAGE(p_borrowid in VARCHAR2) is
cursor cur_bw is
select b.borrowid,b.addtime,b.timelimit,br.status,br.repaymenttime,nvl(br.repaymentyestime,sysdate) repayyes from xxd_borrow b,xxd_borrow_repayment br
                     where b.borrowid = br.borrowid
                       and nvl(br.repaymentyestime,sysdate)-br.repaymenttime>=1
                       and b.borrowid = p_borrowid;
row_cur_bw cur_bw%rowtype;
begin
open cur_bw;
loop
fetch cur_bw into row_cur_bw;
exit when cur_bw%notfound;
  update temp_vintage set money=money+
 (select nvl(sum(repaymentaccount),0) from xxd_borrow_repayment
   where borrowid=p_borrowid
     and nvl(repaymentyestime,sysdate)>row_cur_bw.repaymenttime)
   where addtime=to_char(row_cur_bw.addtime,'yyyymm')
     and timelimit=row_cur_bw.timelimit     
     and decode(laterdays,'m1',1,'m2',31,'m3',61,'m4',91,'m5',121,'m6',151,'m7',181)<=row_cur_bw.repayyes-row_cur_bw.repaymenttime
     and repaymenttime=to_char(row_cur_bw.repaymenttime,'yyyymm');
commit;
end loop;
close cur_bw;
end SP_VINTAGE;
/
