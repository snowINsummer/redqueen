CREATE procedure SP_ACCOUNT_YEARSTATUS(L_startdate in date,
                                                  L_enddate   in date,
                                                  L_TYPE      number) is
  /************************************************
  creator zhangyan
  date    20150629
  按照时间段统计业务数据，及时点账户金额
     L_TYPE 1表示重跑历史数据
            其他表示不需要重跑历史，只需要查询
   **********************************************/
  --  待收金额本金游标(债券转让会有部分问题有待处理)
  cursor c_colloection is
    select t.userid，sum(t.repaycapital) capital,
           sum(t.repayinterest) interest
      from xxd_borrow_collection t
     where t.addtime < L_enddate + 1
       and nvl(t.repayyestime, sysdate) > L_enddate + 1
     group by t.userid;
  row_c_colloection c_colloection%rowtype;

  --  待还金额利息游标
  cursor c_repayment is
    select t.userid,
           sum(t.repaymentAccount) repaymentaccount,
           sum(t.repaymentInterest) repaymentinterest
      from xxd_borrow_repayment t
     where t.addtime < L_enddate + 1
       and nvl(t.repaymentTime, sysdate) > L_enddate + 1
     group by t.userid;
  row_c_repayment c_repayment%rowtype;

  -- 账户余额游标
   cursor c_accountremain is
     select p.userid,
               p.busiid,
               p.addtime,
               '账户余额',
               sum(nvl(p.usable, 0)) accountremain
          from (select l.*
                  from (select max(t.id) id
                          from xxd_account_log t
                         where t.addtime < L_enddate + 1
                         group by t.userid, t.pcode) ta,
                       xxd_account_log l
                 where ta.id = l.id) p
         group by p.userid,p.busiid,p.addtime;
     row_c_accountremain c_accountremain%rowtype;


begin
  if L_TYPE = 1 then
    begin
      ----插入脚本，记录账户信息至临时表
      delete from pang_data_analysis;
      commit;
      -- 充值
      insert into pang_data_analysis
        (user_id, busi_id, changedate, btype, recharge, rechargefee)
        select t.userid, t.rechargeid, VERIFYDATE, '充值', amount, fee
          from xxd_account_recharge t
         where t.status = 1;
      -- 提现
      insert into pang_data_analysis
        (user_id, busi_id, changedate, btype, cash)
        select t.userid, t.cashid, VERIFYDATE, '提现', amount
          from xxd_account_cash t
         where t.status = 3;
      -- 投标，投标奖励
      insert into pang_data_analysis
        (user_id, busi_id, changedate, btype, tender, tenderfunds)
        select bt.userid,
               bt.tenderid,
               ba.approveTime4,
               '投标',
               bt.effectiveMoney,
               case
                 when award = 1 then
                  round(bt.effectiveMoney * bor.funds * 0.01 / bor.account,
                        2)
                 when award = 2 then
                  round(bt.effectiveMoney * bor.funds * 0.01, 2)
                 else
                  null
               end
          FROM xxd_borrow_approved ba, xxd_borrow_tender bt, xxd_borrow bor
         WHERE bor.borrowid = ba.borrowId
           AND bor.borrowid = bt.borrowId
           AND bor.status IN (4, 5);
      -- 新新币
      insert into pang_data_analysis
        (user_id, busi_id, changedate, btype, xxcoin)
        SELECT t.USERID,
               t.busiid,
               t.CHANGETIME,
               '新新币兑换',
               abs(t.CHANGENUM * 0.02)
          FROM xxd_level_logs t
         WHERE CHANGETYPE = 'xinxincoin'
           AND t.CHANGENUM < 0
           AND t.REMARK = '新新币兑换';
      -- 投资回款，收益管理费
      insert into pang_data_analysis
        (user_id,
         busi_id,
         changedate,
         btype,
         COLLECTION,
         LATERINTEGERERESTADD,
         EMFEE,
         INTEGEREREST)
        SELECT bt.userId,
               bc.tenderId,
               bc.repayyestime,
               '投资回款',
               bc.repayYesAccount,
               bc.laterInterest,
               round((bc.repayYesAccount - bc.repayCapital) * 0.1, 2) emfee,
               bc.repayYesInterest
          FROM xxd_borrow_collection bc, xxd_borrow_tender bt
         WHERE bc.tenderId = bt.tenderId
           AND bc.status IN (1, 3, 4);
      -- 借款管理金额 借款管理费
      insert into pang_data_analysis
        (user_id, busi_id, changedate, btype, BORROWACCOUNT, BORROWAFEE)
        SELECT t.userId,
               t.borrowid,
               tt.approveTime4,
               '借款标借款',
               t.accountYes,
               round(CASE
                       WHEN t.type = 1 THEN
                        0.01
                       WHEN t.type = 2 THEN
                        0.005
                       WHEN t.type = 3 THEN
                        0.002
                       WHEN t.type = 4 THEN
                        0
                       WHEN t.type = 5 THEN
                        0
                       WHEN t.type = 6 THEN
                        0.01
                     END * t.accountYes * t.timeLimit,
                     2) borrowfee借款管理费
          FROM xxd_borrow t, xxd_borrow_approved tt
         WHERE t.borrowid = tt.borrowId
           AND t.status IN (4, 5);
      -- 借款标还款
      insert into pang_data_analysis
        (user_id,
         busi_id,
         changedate,
         btype,
         REPAYMENT,
         LATERINTEGERERESTMINUS)
        SELECT nb.userId,
               t.repaymentid,
               t.repaymentYesTime,
               '借款标还款',
               t.repaymentAccount,
               t.laterInterest
          FROM xxd_borrow_repayment t, xxd_borrow nb
         WHERE nb.borrowid = t.borrowId
           AND t.status IN (1, 2);
      --  推广提成
      insert into pang_data_analysis
        (user_id, busi_id, changedate, btype, TICHENG)
        SELECT t.userId, t.id, t.addTime, '推广提成', t.workmoney
          FROM xxd_account_log t
         WHERE t.operatorType = 'ticheng'
           and t.workmoney > 0;
      --  发标奖励
      insert into pang_data_analysis
        (user_id, busi_id, changedate, btype, AWARD_DEDUCT)
        SELECT t.userId,
               t.borrowid,
               tt.approveTime4,
               '借款标借款奖励',
               case
                 when t.award = 1 then
                  funds
                 when t.award = 2 then
                  round(t.account * t.funds * 0.01, 2)
                 when t.award = 0 then
                  0
                 else
                  null
               end as 发标奖励
          FROM xxd_borrow t, xxd_borrow_approved tt
         WHERE t.borrowid = tt.borrowId
           AND t.status IN (4, 5);
      -- 学生信息费
      insert into pang_data_analysis
        (user_id, busi_id, changedate, btype, STUDENT_BORROW_FEE)
        SELECT t.userId, t.busiid, t.addTime, '学生信息费', t.workmoney
          from xxd_account_log t
         where t.operatortype = 'student_borrow_fee';
      --  系统调整
      insert into pang_data_analysis
        (user_id, busi_id, changedate, btype, WUYI)
        SELECT t.userId, t.busiid, t.addTime, '系统调整', t.workmoney
          from xxd_account_log t
         where operatorType = 'handle_back';
      --  体验金
      insert into pang_data_analysis
        (user_id, busi_id, changedate, btype, TIYANJIN)
        SELECT t.userId, t.busiid, t.addTime, '系统扣款', t.workmoney
          from xxd_account_log t
         where operatortype = 'handle';
      --  签约失败信息费返还
      insert into pang_data_analysis
        (user_id, busi_id, changedate, btype, SIGNING_FALSE)
        SELECT t.userId, t.id, t.addTime, '签约失败信息费返还', t.workmoney
          from xxd_account_log t
         where operatortype = 'signing_false';
      --  实名认证费用扣除
      insert into pang_data_analysis
        (user_id, busi_id, changedate, btype, REALNAME)
        SELECT t.userId, t.id, t.addTime, '实名认证费用扣除', t.workmoney
          from xxd_account_log t
         where operatortype = 'realname';
      --转让金额(卖出)
      insert into pang_data_analysis
        (user_id, busi_id, changedate, btype, requestamount)
        select xxd_trade_request.userid,
               xxd_trade_request.requestid,
               xxd_trade_pack.addtime,
               '卖出转让金额',
               xxd_trade_request.amount
          from xxd_trade_request, xxd_user, xxd_trade_pack
         where xxd_trade_request.userid = xxd_user.userid
           and xxd_trade_pack.requestid = xxd_trade_request.requestid;

      --转让成功手续费
      insert into pang_data_analysis
        (user_id, busi_id, changedate, btype, rate)
        select xxd_trade_request.userid,
               xxd_trade_request.requestid,
               xxd_trade_pack.addtime,
               '债券转让手续费',
               xxd_trade_request.transfee
          from xxd_trade_request, xxd_user, xxd_trade_pack
         where xxd_trade_request.userid = xxd_user.userid
           and xxd_trade_pack.requestid = xxd_trade_request.requestid;

      --转让奖励（卖出人）
      insert into pang_data_analysis
        (user_id, busi_id, changedate, btype, requestfunds)
        select xxd_trade_request.userid,
               xxd_trade_request.requestid,
               xxd_trade_pack.addtime,
               '卖出人转让奖励',
               xxd_trade_request.funds
          from xxd_trade_request, xxd_user, xxd_trade_pack
         where xxd_trade_request.userid = xxd_user.userid
           and xxd_trade_pack.requestid = xxd_trade_request.requestid;

      --购买债券转让金额
      insert into pang_data_analysis
        (user_id, busi_id, changedate, btype, packamount)
        select xxd_trade_pack.userid,
               xxd_trade_pack.packid,
               xxd_trade_pack.addtime,
               '买入转让金额',
               xxd_trade_pack.collectamount
          from xxd_trade_request, xxd_user, xxd_trade_pack
         where xxd_trade_pack.userid = xxd_user.userid
           and xxd_trade_pack.requestid = xxd_trade_request.requestid;

      --转让奖励(买入人)
      insert into pang_data_analysis
        (user_id, busi_id, changedate, btype, packfunds)
        select xxd_trade_pack.userid,
               xxd_trade_pack.packid,
               xxd_trade_pack.addtime,
               '买入人转让奖励',
               xxd_trade_request.funds
          from xxd_trade_request, xxd_user, xxd_trade_pack
         where xxd_trade_request.userid = xxd_user.userid
           and xxd_trade_pack.requestid = xxd_trade_request.requestid;

     /* ------------------插入账户可用余额并且判断日期
      insert into pang_data_analysis
        (user_id, busi_id, changedate, btype, accountremain)
        select p.userid,
               p.busiid,
               p.addtime,
               '账户余额',
               sum(nvl(p.usable, 0)) accountremain
          from (select l.*
                  from (select max(t.id) id
                          from xxd_account_log t
                         where t.addtime < L_enddate + 1
                         group by t.userid, t.pcode) ta,
                       xxd_account_log l
                 where ta.id = l.id) p
         group by p.userid,p.busiid,p.addtime;
      commit;*/

    end;
  end if;

  ------------------统计当年的数据
  begin
    delete from temp_account_yearstatus t where t.staticdate = L_enddate;
    commit;
    insert into temp_account_yearstatus
      (USER_ID,
       RECHARGE,
       RECHARGEFEE,
       CASH,
       TENDER,
       TENDERFUNDS,
       XXCOIN,
       COLLECTION,
       LATERINTEGERERESTADD,
       EMFEE,
       BORROWACCOUNT,
       BORROWAFEE,
       REPAYMENT,
       LATERINTEGERERESTMINUS,
       TICHENG,
       INTEGEREREST,
       AWARD_DEDUCT,
       STUDENT_BORROW_FEE,
       WUYI,
       TIYANJIN,
       SIGNING_FALSE,
       REALNAME,
       REQUESTAMOUNT,
       RATE,
       REQUESTFUNDS,
       PACKAMOUNT,
       PACKFUNDS,
       ACCOUNTREMAIN,
       STATICDATE)
      select t.user_id user_id,
             sum(t.recharge) RECHARGE,
             sum(t.rechargefee) RECHARGEFEE,
             sum(t.cash) CASH,
             sum(t.tender) TENDER,
             sum(t.tenderfunds) TENDERFUNDS,
             sum(t.xxcoin) XXCOIN,
             sum(t.collection) COLLECTION,
             sum(t.laterintegererestadd) LATERINTEGERERESTADD,
             sum(t.emfee) EMFEE,
             sum(t.borrowaccount) BORROWACCOUNT,
             sum(t.borrowafee) BORROWAFEE,
             sum(t.repayment) REPAYMENT,
             sum(t.laterintegererestminus) LATERINTEGERERESTMINUS,
             sum(t.ticheng) TICHENG,
             sum(t.integererest) INTEGEREREST,
             sum(t.award_deduct) AWARD_DEDUCT,
             sum(t.student_borrow_fee) STUDENT_BORROW_FEE,
             sum(t.wuyi) WUYI,
             sum(t.tiyanjin) TIYANJIN,
             sum(t.signing_false) SIGNING_FALSE,
             sum(t.realname) REALNAME,
             sum(t.requestamount) REQUESTAMOUNT,
             sum(t.rate) RATE,
             sum(t.requestfunds) REQUESTFUNDS,
             sum(t.packamount) PACKAMOUNT,
             sum(t.packfunds) PACKFUNDS,
             sum(t.accountremain) ACCOUNTREMAIN,
             L_enddate STATICDATE
        FROM pang_data_analysis t, xxd_user u
       where t.changedate >= L_startdate
         and t.changedate < L_enddate + 1
         and t.user_id = u.userid
         and u.expiredate < L_enddate + 1
       GROUP BY t.user_id;
    commit;
    open c_colloection;
    loop
      fetch c_colloection
        into row_c_colloection;
      exit when c_colloection%notfound;
      update temp_account_yearstatus t
         set t.c_capital  = row_c_colloection.capital,
             t.c_interest = row_c_colloection.interest
       where t.user_id = row_c_colloection.userid
         and t.staticdate = L_enddate;
    end loop;
    close c_colloection;
    commit;

    open c_repayment;
    loop
      fetch c_repayment
        into row_c_repayment;
      exit when c_repayment%notfound;
      update temp_account_yearstatus t
         set t.r_capital  = row_c_repayment.repaymentaccount,
             t.r_interest = row_c_repayment.repaymentinterest
       where t.user_id = row_c_repayment.userid
         and t.staticdate = L_enddate;
    end loop;
    close c_repayment;
    commit;

   open c_accountremain;
    loop
      fetch c_accountremain
        into row_c_accountremain;
      exit when c_accountremain%notfound;
      update temp_account_yearstatus t
         set t.accountremain  = row_c_accountremain.accountremain
       where t.user_id = row_c_accountremain.userid
         and t.staticdate = L_enddate;
    end loop;
    close c_accountremain;
    commit;


  end;

end SP_ACCOUNT_YEARSTATUS;

/
