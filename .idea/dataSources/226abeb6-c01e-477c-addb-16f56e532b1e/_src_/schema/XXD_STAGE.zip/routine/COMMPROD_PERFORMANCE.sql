CREATE procedure commprod_performance(in_date date)
is
v_in_date date:=in_date;

begin



insert into xxd_product_out(id,outtradeid,userid,productcode,productname,outtradenum,tradeid,tradenum,createdate,servicenum,employeeid,initiator,outtype,terms,interest,departmentid)
select seq_product_out.nextval,a.orderno,a.userid,a.ptype,
case when ptype=94 then '七天大胜'
     when ptype=95 then '月进斗金'
     when ptype=16 then '新手标'  end productname,ADDACCOUNT,orderno,ADDACCOUNT,
b.endtime,
SERVICENUM,employeeid,initiator,2,
case when ptype=94 then  7/30
     when ptype=95 then  31/30
     when ptype=16 then  a.terms end terms,a.plannedinterest,a.dept4id
from xxd_order_record a inner join xxd_reglintst_join b
on a.orderno=b.joinid
where ptype in (94,95,16)
and  b.endtime>=trunc(v_in_date)-1 and b.endtime<trunc(v_in_date);

commit;

insert into xxd_performance_daily(id,adddate,userid,servicenum,employeeid,ptype,departmentid,addamount,scaleamount,annualamount,outtype)
select seq_performance_daily.nextval,addtime,userid,servicenum,employeeid,ptype,departmentid,addaccount,addaccount scaleamount,annual_amount,outtype from
(select addtime,userid,servicenum,employeeid,ptype,departmentid,sum(addaccount) addaccount,sum(annual_amount) annual_amount,outtype from
(select trunc(addtime) addtime,userid,nvl(servicenum,0) servicenum,nvl(employeeid,0) employeeid,ptype,nvl(dept4id,0) departmentid,addaccount,addaccount*terms/12 annual_amount,null outtype
from xxd_order_record a
where ptype in (94,95,16)
and addtime>=trunc(v_in_date)-1 and  addtime<trunc(v_in_date))
group by addtime,userid,servicenum,employeeid,ptype,departmentid,outtype);

commit;



delete from xxd_performance_month where PTYPE in (94,95,16)  and ADDDATE=trunc(trunc(v_in_date)-1,'month');

insert into xxd_performance_month(id,adddate,employeeid,ptype,addamount,scaleamount,annualamount,departmentid)
select seq_performance_month.nextval,adddate,employeeid,ptype,addamount,scaleamount,annualamount,departmentid from
(select trunc(adddate,'month') adddate,employeeid,ptype,sum(addamount) addamount,
sum(scaleamount) scaleamount,
sum(annualamount) annualamount,departmentid
from xxd_performance_daily
where adddate>=trunc(trunc(v_in_date)-1,'month')
and adddate<add_months(trunc(trunc(v_in_date)-1,'month'),1)
and ptype in (94,95,16)
group by trunc(adddate,'month'),employeeid,ptype,departmentid);

commit;

end;

/
