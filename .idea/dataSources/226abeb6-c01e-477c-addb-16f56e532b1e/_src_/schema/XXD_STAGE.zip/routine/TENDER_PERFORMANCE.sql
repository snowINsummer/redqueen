CREATE procedure tender_performance(in_date date)
is

--计算散标业绩 不包括步步高升，七天大圣

v_in_date date:=in_date;
cursor ck is
select  a.requestid,a.tenderid,b.packid,a.userid,b.addtime,a.addtime reqaddtime,b.collectinterest
from xxd_trade_request a inner join xxd_trade_pack b
on a.requestid=b.requestid
where a.reqmethod=1
and a.status<>6    --有2条问题数据
and b.addtime>=trunc(v_in_date)-1 and b.addtime<trunc(v_in_date);

ck_rec ck%rowtype;
tmp_cnt2 number;
tmp_cnt3 number;
tmp_ptype number;
tmp_addaccount number;
tmp_servicenum varchar2(30);
tmp_employeeid number;
tmp_dept4id number;
tmp_terms number;
tmp_keepdays number;
tmp_packid varchar2(30);
tmp_plannedinterest  number;


begin

--计算散标提前转让




open ck;
  loop
    fetch ck into  ck_rec;
    exit when ck%notfound;


select count(*) into tmp_cnt2
from xxd_trade_request a inner join xxd_trade_pack b
on a.requestid=b.requestid
and a.tenderid=ck_rec.tenderid
and a.addtime<ck_rec.reqaddtime ;

select count(*) into tmp_cnt3
from xxd_order_record d
where d.orderno in (
select max(packid)
from xxd_trade_request a inner join xxd_trade_pack b
on a.requestid=b.requestid
and a.tenderid=ck_rec.tenderid
and a.addtime<ck_rec.reqaddtime );





if tmp_cnt2=0 then
select ptype,addaccount,servicenum,employeeid,dept4id,trunc(ck_rec.addtime-addtime)  keepdays,terms,plannedinterest
into  tmp_ptype,tmp_addaccount,tmp_servicenum,tmp_employeeid,tmp_dept4id,tmp_keepdays,tmp_terms,tmp_plannedinterest
from xxd_order_record where  orderno=ck_rec.tenderid;


insert into xxd_product_out(id,outtradeid,userid,productcode,productname,outtradenum,tradeid,tradenum,CREATEDATE,servicenum,employeeid,initiator,keepdays,terms,outtype,departmentid,interest)
values(seq_product_out.nextval,ck_rec.requestid,ck_rec.userid,tmp_ptype,'第一次债权转让',tmp_addaccount,ck_rec.tenderid,tmp_addaccount,ck_rec.addtime,tmp_servicenum,tmp_employeeid,
1,tmp_keepdays,tmp_terms,1,tmp_dept4id,tmp_plannedinterest-ck_rec.collectinterest);

end if;


if tmp_cnt2 >0 and tmp_cnt3 >0 then
select d.ptype,d.addaccount,d.servicenum,d.employeeid,d.dept4id,trunc(ck_rec.addtime-d.addtime) keepdays,d.terms terms,d.orderno,d.plannedinterest
into  tmp_ptype,tmp_addaccount,tmp_servicenum,tmp_employeeid,tmp_dept4id,tmp_keepdays,tmp_terms,tmp_packid,tmp_plannedinterest
from xxd_order_record d
where d.orderno in (
select max(packid)
from xxd_trade_request a inner join xxd_trade_pack b
on a.requestid=b.requestid
and a.tenderid=ck_rec.tenderid
and a.addtime<ck_rec.reqaddtime );


insert into xxd_product_out(id,outtradeid,userid,productcode,productname,outtradenum,tradeid,tradenum,CREATEDATE,servicenum,employeeid,initiator,keepdays,terms,outtype,departmentid,tenderid,interest)
values(seq_product_out.nextval,ck_rec.requestid,ck_rec.userid,tmp_ptype,'非第一次债权转让',tmp_addaccount,tmp_packid,tmp_addaccount,ck_rec.addtime,tmp_servicenum,tmp_employeeid,
1,tmp_keepdays,tmp_terms,1,tmp_dept4id,ck_rec.tenderid,tmp_plannedinterest-ck_rec.collectinterest);

end if;




commit;

    end loop;
    close ck;


--计算到期散标


insert into xxd_product_out(id,outtradeid,userid,productcode,productname,outtradenum,tradeid,tradenum,CREATEDATE,servicenum,employeeid,initiator,outtype,keepdays,terms,departmentid,tenderid,interest)
select seq_product_out.nextval,orderno,userid,ptype,
case when a.orderno like 'TP%' then '最后一次债权转让'
     when a.ptype=94 then '七天大胜'
     when a.ptype=95 then '月进斗金'
     when a.ptype=96 then '步步高升'
     when a.ptype=97 then '月月派'
     when a.ptype=98 then '新元宝'
     when a.ptype=99 then '日日盈'
     when a.ptype=1  then '信用标'
     when a.ptype=2  then '推荐标'
     when a.ptype=3  then '净值标'
     when a.ptype=4  then '秒还标'
     when a.ptype=5  then '调剂标'
     when a.ptype=6  then '抵押标'
     when a.ptype=7  then '新新宝'
     when a.ptype=8  then '新生贷'
     when a.ptype=9  then '新商贷'
     when a.ptype=10 then '新房贷'
     when a.ptype=11 then '菁英贷'
     when a.ptype=12 then '信网贷'
     when a.ptype=13 then '票小宝'
     when a.ptype=14 then '新车贷'
     when a.ptype=15 then '分期贷'
     when a.ptype=16 then '新手标'
     when a.ptype=18 then '电商贷'
     when a.ptype=19 then '新业贷' end ,ADDACCOUNT,orderno,ADDACCOUNT,plannedtime,servicenum,employeeid,1,2,null,terms,dept4id,null,plannedinterest
from xxd_order_record a
where plannedtime>=trunc(v_in_date)-1
and plannedtime<trunc(v_in_date)
and ((ptype <90 and ptype <>16) or ptype>1000)
and orderno not in (select tradeid from xxd_product_out);




insert into xxd_performance_daily(id,adddate,userid,servicenum,employeeid,ptype,departmentid,addamount,scaleamount,annualamount,outtype)
select seq_performance_daily.nextval,addtime,userid,servicenum,employeeid,ptype,departmentid,addaccount,addaccount scaleamount,annual_amount,outtype from
(select addtime,userid,servicenum,employeeid,ptype,departmentid,sum(addaccount) addaccount,sum(annual_amount) annual_amount,outtype from
(select trunc(addtime) addtime,userid,nvl(servicenum,0) servicenum,nvl(employeeid,0) employeeid,ptype,nvl(dept4id,0) departmentid,addaccount,addaccount*terms/12 annual_amount,null outtype
from xxd_order_record a
where ((ptype <90 and ptype <>16) or ptype>1000)
and addtime>=trunc(v_in_date)-1 and  addtime<trunc(v_in_date)
and userid not in (select userid from xxd_account_cashprohibit)
union all
select trunc(createdate),userid,nvl(servicenum,0) servicenum,nvl(employeeid,0) employeeid,productcode,nvl(departmentid,0) departmentid,0,
case when round(-1*(tradenum*terms/12-tradenum*keepdays/360),6)>0 then 0
     else round(-1*(tradenum*terms/12-tradenum*keepdays/360),6) end annual_amount,1 outtype
from xxd_product_out b
where ((productcode <90 and productcode <>16) or productcode>1000)
and OUTTYPE=1
and createdate>=trunc(v_in_date)-1 and  createdate<trunc(v_in_date)
and userid not in (select userid from xxd_account_cashprohibit))
group by addtime,userid,servicenum,employeeid,ptype,departmentid,outtype);



--计算业绩


delete from xxd_performance_month where PTYPE<90 and ptype<>16 and ADDDATE=trunc(trunc(v_in_date)-1,'month');


insert into xxd_performance_month(id,adddate,employeeid,ptype,addamount,scaleamount,annualamount,departmentid)
select seq_performance_month.nextval,adddate,employeeid,ptype,addamount,scaleamount,annualamount,departmentid from
(select trunc(adddate,'month') adddate,employeeid,ptype,sum(addamount) addamount,
sum(scaleamount) scaleamount,
sum(annualamount) annualamount,departmentid
from xxd_performance_daily
where adddate>=trunc(trunc(v_in_date)-1,'month')
and adddate<add_months(trunc(trunc(v_in_date)-1,'month'),1)
and ((ptype <90 and ptype <>16) or ptype>1000)
group by trunc(adddate,'month'),employeeid,ptype,departmentid);


commit;



end;

/
