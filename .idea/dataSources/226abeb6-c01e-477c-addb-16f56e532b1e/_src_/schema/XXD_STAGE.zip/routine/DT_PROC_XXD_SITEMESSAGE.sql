CREATE procedure dt_proc_xxd_sitemessage is
cursor cur_xxd_message_site is  select
 t.ID,t.RECEIVERID,t.SENDERID,t.TITLE,t.CONTENT,t.STATUS,t.DELSTATUS,t.SENDTIME,t.SENDIP,t.REVIEWTIME,t.REVIEWIP
  from xxdai_message_site t ;--站内信xxd_message_site表游标
 row_cur_xxd_message_site cur_xxd_message_site%rowtype;--xxd_message_site行类型
 --
 cursor cur_xxd_message_site_sendlogs is  select
 t.ID,t.USERID,t.SENDTYPE,t.SENDREASON,t.CONTEXT,t.SENDTIME,t.SENDIP
  from xxdai_sendmessage_logs t ;--站内信xxd_message_site_sendlogs表游标
 row_xxd_message_site_sendlogs cur_xxd_message_site_sendlogs%rowtype;--xxd_message_site_sendlogs行类型
 --
 m_count  integer;--提交计数器
begin
  --xxd_message_site表处理
  delete from xxd_message_site t;
  commit;
  open cur_xxd_message_site;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_xxd_message_site
      into row_cur_xxd_message_site;
    exit when cur_xxd_message_site%notfound;
    insert into  xxd_message_site
    (ID,          RECEIVERID,           SENDERID,          TITLE,            CONTENT,
    STATUS,       DELSTATUS,            SENDTIME,          SENDIP,        REVIEWTIME,
    REVIEWIP)
    values
      (row_cur_xxd_message_site.ID,       row_cur_xxd_message_site.RECEIVERID,                               row_cur_xxd_message_site.SENDERID,    row_cur_xxd_message_site.TITLE,                               row_cur_xxd_message_site.CONTENT,
      row_cur_xxd_message_site.STATUS,    row_cur_xxd_message_site.DELSTATUS,    nvl(FROM_UNIXTIME(row_cur_xxd_message_site.SENDTIME),sysdate),   row_cur_xxd_message_site.SENDIP,  nvl(FROM_UNIXTIME(row_cur_xxd_message_site.REVIEWTIME),sysdate),
      row_cur_xxd_message_site.REVIEWIP);
     if mod(m_count,2000)=0 then
     commit;
     end if;
  end loop;
  commit;
  close cur_xxd_message_site;
--xxd_message_site表处理
  delete from xxd_message_site_sendlogs t;
  commit;
  open cur_xxd_message_site_sendlogs;
  m_count:=0;
  loop
    m_count:=m_count+1;
    fetch cur_xxd_message_site_sendlogs
      into row_xxd_message_site_sendlogs;
    exit when cur_xxd_message_site_sendlogs%notfound;
    insert into  xxd_message_site_sendlogs

    (ID,    USERID,   SENDTYPE,  SENDREASON,
     CONTEXT, SENDTIME,   SENDIP)
    values
      (row_xxd_message_site_sendlogs.ID,                row_xxd_message_site_sendlogs.USERID,         row_xxd_message_site_sendlogs.SENDTYPE,
      row_xxd_message_site_sendlogs.SENDREASON,        row_xxd_message_site_sendlogs.CONTEXT,          nvl(FROM_UNIXTIME(row_xxd_message_site_sendlogs.SENDTIME),sysdate),
      row_xxd_message_site_sendlogs.SENDIP);
     if mod(m_count,2000)=0 then
     commit;
     end if;
  end loop;
  commit;
  close cur_xxd_message_site_sendlogs;
end dt_proc_xxd_sitemessage;



/
