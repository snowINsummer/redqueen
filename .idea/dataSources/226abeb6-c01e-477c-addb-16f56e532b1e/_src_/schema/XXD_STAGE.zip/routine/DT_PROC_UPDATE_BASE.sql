CREATE procedure DT_PROC_UPDATE_BASE is
CURSOR cur_update_base IS SELECT
  a.userid,a.realname,a.idcardno,a.idcardtype,a.approtime,a.approip
  FROM  xxdai_realname_appro a where a.ispassed=1 and a.userid not in (select userid from xxd_user_baseinfo);
  row_cur_update_base cur_update_base%rowtype;

CURSOR cur_update_esab IS SELECT
  a.userid,a.realname,a.idcardno,a.idcardtype
  FROM  xxdai_realname_appro a where a.ispassed=1 and a.userid in (select userid from xxd_user_baseinfo);
  row_cur_update_esab cur_update_esab%rowtype;
  m_count INTEGER ;
BEGIN
-- 插入数据
  OPEN cur_update_base;
  m_count:= 0;
  loop
  m_count:= m_count+1;
FETCH cur_update_base INTO row_cur_update_base;
exit when cur_update_base%notfound;
INSERT INTO xxd_user_baseinfo (
  userid,    IDCARDTYPE,  IDCARDNO,   REALNAME,
  CREATEDATE,CREATEIP,    MODIFYDATE
)
VALUES
  (
  row_cur_update_base.userid,   row_cur_update_base.idcardtype,  row_cur_update_base.idcardno,  row_cur_update_base.realname,
  nvl(from_unixtime(row_cur_update_base.APPROTIME),sysdate),  nvl(row_cur_update_base.APPROIP,'127.0.0.1'),nvl(from_unixtime(row_cur_update_base.APPROTIME),sysdate)
);
  if mod(m_count,5000)=0 then
      commit;
  end if;
  end loop;
    commit;
  close cur_update_base;

-- 更新数据
  OPEN cur_update_esab;
  m_count:= 0;
  loop
  m_count:= m_count+1;
FETCH cur_update_esab INTO row_cur_update_esab;
exit when cur_update_esab%notfound;
update xxd_user_baseinfo
set IDCARDTYPE=row_cur_update_esab.IDCARDTYPE,
    IDCARDNO=row_cur_update_esab.IDCARDNO,
    REALNAME=row_cur_update_esab.REALNAME
where userid= row_cur_update_esab.USERID;
  if mod(m_count,5000)=0 then
      commit;
  end if;
  end loop;
    commit;
  close cur_update_esab;
-- 更新user表
update xxd_mobile_appro
   set status = 0
 where mobileno in (select mobilenum
                      from xxdai_mobile_appro
                     where ispassed = 1
                     GROUP BY mobileNum
                    having count(1) > 1);

commit;

update xxd_user t
   set t.mobile = (select tt.mobileno
               from xxd_mobile_appro tt
              where tt.status = 1
                and tt.userid = t.userid)
    where exists (select '1'
               from xxd_mobile_appro tt1
              where tt1.status = 1
                and tt1.userid = t.userid);
commit;
end DT_PROC_UPDATE_BASE;



/
