CREATE procedure fd_info as
begin
delete from temp_fd_info;
delete from temp_fd_info_dx;
commit;
insert into temp_fd_info select * from temp_fd_info@DBLINKTO7050;
insert into temp_fd_info_dx select * from temp_fd_info@DBLINKTO7050;
commit;
end;
/
