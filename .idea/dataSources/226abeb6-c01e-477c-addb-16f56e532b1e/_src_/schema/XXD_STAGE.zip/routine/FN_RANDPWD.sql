CREATE function fn_randpwd return varchar2 is
--  create by luzhongjie   20150811
-- 随机数字、随机大写字母、随机小写字母
  retval1 varchar2(62);
  retval2 varchar2(2);
  retval3 varchar2(2);
-- 穷举字符串
  retval4 varchar2(2);
-- 穷举字符串随机取数
  retval5 varchar2(2);
  retval6 varchar2(2);
  retval7 varchar2(2);
  retval8 varchar2(2);
  retval9 varchar2(2);
  abc1 number;
  abc2 number;
  abc3 number;
-- 返回结果集
  retval0 varchar2(8);
begin
  retval1 := 'QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890';
  loop
exit when abc1<>abc2 and abc2<>abc3 and abc1<>abc3;
  retval2 := substr(retval1, round(dbms_random.value(1, length(retval1))), 1);
  retval3 := substr(retval1, round(dbms_random.value(1, length(retval1))), 1);
  retval4 := substr(retval1, round(dbms_random.value(1, length(retval1))), 1);
   if ascii(retval2) >=48 and ascii(retval2)<= 57 then abc1 := 1 ;
elsif ascii(retval2) >=65 and ascii(retval2)<= 90 then abc1 := 2 ;
elsif ascii(retval2) >=97 and ascii(retval2)<=122 then abc1 := 3 ;
 else abc1 := 0;
  end if;
   if ascii(retval3) >=48 and ascii(retval3)<= 57 then abc2 := 1 ;
elsif ascii(retval3) >=65 and ascii(retval3)<= 90 then abc2 := 2 ;
elsif ascii(retval3) >=97 and ascii(retval3)<=122 then abc2 := 3 ;
 else abc2 := 0;
  end if;
   if ascii(retval4) >=48 and ascii(retval4)<= 57 then abc3 := 1 ;
elsif ascii(retval4) >=65 and ascii(retval4)<= 90 then abc3 := 2 ;
elsif ascii(retval4) >=97 and ascii(retval4)<=122 then abc3 := 3 ;
 else abc3 := 0;
  end if;
end loop;
  retval5 := substr(retval1, round(dbms_random.value(1, length(retval1))), 1);
  retval6 := substr(retval1, round(dbms_random.value(1, length(retval1))), 1);
  retval7 := substr(retval1, round(dbms_random.value(1, length(retval1))), 1);
  retval8 := substr(retval1, round(dbms_random.value(1, length(retval1))), 1);
  retval9 := substr(retval1, round(dbms_random.value(1, length(retval1))), 1);
  retval0 :=  retval5 || retval6 || retval7 || retval8 || retval9 || retval2 ||  retval3 ||  retval4 ;
  return retval0;
end;
/
