CREATE PROCEDURE addSign
is
columnExistedCount number;
begin
        select count(*) into columnExistedCount from user_tab_columns t where t.table_name = upper('xxd_user')  and t.column_name = upper('SIGNED');
        if columnExistedCount = 0 then
           execute immediate
           'alter table xxd_user add SIGNED CHAR(1) default 0 not null';
        end if;
end;
/
