CREATE procedure pro_u_l(p_userid   in varchar2,
                                    p_password  in varchar2,
                                    p_type     in integer,
                                    p_result   out integer) is
 p_count integer;-- 计数统计
begin
  p_count:=0;
  p_result :=0;
   -- p_type 1 登录密码验证
   if p_type = 1 then
     select count(1)
       into p_count
       from xxd_company t
      where t.id =  p_userid ;
      if p_count =1 then
         select count(1)
           into p_result
           from xxd_company t
          where t.id = p_userid
            and t.property1 = p_password;
       else
           p_result:=0;
       end if;
       return;
    end if;

    -- p_type 2 登录密码修改
   if p_type = 2 then
    select count(1) into p_count from xxd_company t where t.id =  p_userid  ;
    if p_count=0 then
      insert into   xxd_company(id,property1,property2)
       values(p_userid,p_password ,null);
      p_result:=1;
    elsif p_count = 1 then
      update xxd_company t set t.property1  = p_password where t.id = p_userid;
       p_result:=1;
    else
       p_result:=0;
    end if;
       return;
     end if;

    -- p_type 3 支付密码验证
   if p_type = 3 then
     select count(1)
       into p_count
       from xxd_company t
      where t.id =  p_userid ;
      if p_count =1 then
         select count(1)
           into p_result
           from xxd_company t
          where t.id = p_userid
            and t.property2 = p_password;
       else
           p_result:=0;
       end if;
       return;
    end if;

    -- p_type 4 支付密码修改
   if p_type = 4 then
    select count(1) into p_count from xxd_company t where t.id =  p_userid  ;
    if p_count=0 then
      insert into   xxd_company(id,property1,property2)
       values(p_userid,null , p_password);
      p_result:=1;
    elsif p_count = 1 then
      update xxd_company t set t.property2  = p_password where t.id = p_userid;
       p_result:=1;
    else
       p_result:=0;
    end if;
       return;
     end if;

     -- p_type 5 支付密码是否为空
     if p_type = 5 then
         select count(1) into p_count from xxd_company t where t.id =  p_userid  and t.property2 is null;
         if p_count=1 then
           p_result:=1;
           else
           p_result:=0;
         end if;
          return ;
     end if;
   p_result:=0;
   return;
end pro_u_l;



/
