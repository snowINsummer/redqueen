CREATE procedure dt_seqfittotabledata is
-- 调整触发器最小值 与对应表 数据符合
m_tab_maxid integer;
m_seq_last_num  integer;
m_seq_cache_size integer;
m_fitnum integer;
m_str_sql varchar2(400);

m_seq_new_num integer;

l_cursor SYS_REFCURSOR;
s_seqnm  user_sequences.sequence_name%type;
s_tbnm   user_ind_columns.TABLE_NAME%type;
s_clnm   user_ind_columns.COLUMN_NAME%type;

begin
  delete from tmp_seq;
  commit;

  open l_cursor for
       'select a.sequence_name,c.TABLE_NAME, c.COLUMN_NAME,
               a.last_number, a.cache_size
          from user_sequences a, user_ind_columns c, user_constraints d
         where replace(a.sequence_name, ''SEQ'', ''XXD'') = c.TABLE_NAME
           and c.TABLE_NAME = d.table_name
           and c.INDEX_NAME = d.index_name
           and a.cycle_flag = ''N''
           and d.constraint_type = ''P''
           and not exists ( select 1
                              from xxd_busicode_rule b
                             where b.tablename = c.TABLE_NAME
                               and b.tablename not in (''XXD_MARKET_GOODS'', ''XXD_LEVEL_LOGS''))
         order by 1
       '
  ;
  loop
    FETCH l_cursor INTO s_seqnm, s_tbnm, s_clnm, m_seq_last_num, m_seq_cache_size;
    EXIT WHEN l_cursor%NOTFOUND;

    execute immediate
            'select nvl(max(' || s_clnm || '), 0) from ' || s_tbnm
            into m_tab_maxid;


    --select max(t.auditid) into m_tab_maxid from xxd_account_audit t;
    --select T.last_number,t.cache_size  into m_seq_last_num,m_seq_cache_size  from user_sequences t where t.sequence_name = 'SEQ_ACCOUNT_AUDIT';
    if m_tab_maxid >= m_seq_last_num + m_seq_cache_size then

       m_fitnum := m_tab_maxid - m_seq_last_num + 1 + m_seq_cache_size;
       m_str_sql := 'alter sequence ' || s_seqnm || ' increment by '|| m_fitnum || ' nocache';
       execute immediate m_str_sql;

       m_str_sql := 'select ' || s_seqnm || '.nextval from dual';
       execute immediate m_str_sql into m_seq_new_num;

       m_str_sql := 'alter sequence ' || s_seqnm || ' increment by 1 nocache';
       execute immediate m_str_sql;

       m_seq_new_num := m_seq_new_num + 1;

    else
       m_seq_new_num := m_seq_last_num;
    end if;

    insert into tmp_seq(
       seq_name, table_name, column_name,
       tab_maxid, seq_last_number , seq_cache_size,
       seq_new_number)
    values(
       s_seqnm, s_tbnm, s_clnm,
       m_tab_maxid, m_seq_last_num, m_seq_cache_size,
       m_seq_new_num)
    ;
  end loop;

  close l_cursor;

  commit;

end dt_seqfittotabledata;



/
