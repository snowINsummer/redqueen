CREATE procedure SP_TEMP_QILIN(L_startdate in varchar2,
                                          L_enddate   in varchar2) is
  /***************************************************************************
  created by xiaobao 20150601     麒麟数据统计
  type1  0-默认，1-散标出借，2-债权转让，3-新元宝，4-票小宝     (100,web端总体，101,手机端总体)
  type2  0-默认，1-新商贷，2-新网贷，3-新生贷，4-精英贷，5-新房贷，6-新车贷
  type3  0-默认，1-上月贷出余额，2-本月新增回款，3-本月新增贷出
  type4  0-默认，1-（1-3个月），2-（4-7个月），3-（8-12个月），4-（13-24个月），5-（24个月以上）
                 当新元宝时，锁定期存 3.6.12
    ****************************************************************************/

  V_startdate date;
  V_enddate   date;

begin

  V_startdate := to_date(L_startdate, 'YYYYMM'); --统计起始日期（含边界）
  V_enddate   := to_date(L_enddate, 'YYYYMM');   --统计结束日期（不含边界）

  /********************************************************
        part1.  总体数据 （Monthly General Data）
  ********************************************************/

  /*************web端部分***********************/

  --Web端   注册用户数
  insert into TEMP_0601_QILIN
    select to_char(t.expiredate, 'yyyymm'),
           100, --100标记web端,101标记手机端
           0,
           0,
           0,
           '注册用户数' as "统计项目",
           count(*) as "统计数据"
      from xxd_user t
     where t.regsource = '1'
       and t.expiredate >= to_date(L_startdate, 'YYYYMM')
       and t.expiredate < to_date(L_enddate, 'YYYYMM')
     group by to_char(t.expiredate, 'yyyymm');

  commit;

  --Web端  已实名认证的用户数
  insert into TEMP_0601_QILIN
    select mon 月份,
           100, --100标记web端,101标记手机端
           0,
           0,
           0,
           '已实名认证的用户数' as "统计项目",
           count(distinct a.userid) as "统计数据"
      from (select u.userid from xxd_user u where u.regsource = '1') a
     inner join (select userid, to_char(createdate, 'yyyymm') mon
                   from xxd_realname_appro
                  where status = '1'
                    and createdate >= to_date(L_startdate, 'YYYYMM')
                    and createdate <  to_date(L_enddate, 'YYYYMM')) b
        on a.userid = b.userid

     group by mon;

  commit;

  --Web端 已手机认证的用户数
  insert into TEMP_0601_QILIN
    select mon 月份,
           100, --100标记web端,101标记手机端
           0,
           0,
           0,
           '已手机认证的用户数' as "统计项目",
           count(distinct a.userid) as "统计数据"
      from (select u.userid from xxd_user u where u.regsource = '1') a
     inner join (select userid, to_char(createdate, 'yyyymm') mon
                   from xxd_mobile_appro
                  where status = '1'
                    and createdate >= to_date(L_startdate, 'YYYYMM')
                    and createdate <  to_date(L_enddate, 'YYYYMM')) b
        on a.userid = b.userid
     group by mon;

  commit;

  --Web端 VIP认证的用户数
  insert into TEMP_0601_QILIN
    select mon 月份,
           100, --100标记web端,101标记手机端
           0,
           0,
           0,
           'VIP认证的用户数' as "统计项目",
           count(distinct a.userid) as "统计数据"
      from (select u.userid from xxd_user u where u.regsource = '1') a
     inner join (select userid, to_char(createdate, 'yyyymm') mon
                   from xxd_vip_appro
                  where status = '1'
                    and createdate >= to_date(L_startdate, 'YYYYMM')
                    and createdate < to_date(L_enddate, 'YYYYMM')) b
        on a.userid = b.userid
     group by mon;

  commit;

  --Web端 邮箱绑定数
  insert into TEMP_0601_QILIN
    select mon 月份,
           100, --100标记web端,101标记手机端
           0,
           0,
           0,
           '邮箱绑定数' as "统计项目",
           count(distinct a.userid) as "统计数据"
      from (select u.userid from xxd_user u where u.regsource = '1') a
     inner join (select userid, to_char(createdate, 'yyyymm') mon
                   from xxd_email_appro
                  where status = '1'
                    and createdate >= to_date(L_startdate, 'YYYYMM')
                    and createdate <  to_date(L_enddate, 'YYYYMM')) b
        on a.userid = b.userid
     group by mon;

  commit;

  --Web端 已绑定银行卡的用户数（去重复）

  insert into TEMP_0601_QILIN
    select to_char(addtime, 'yyyymm') 月份,
           100, --100标记web端,101标记手机端
           0,
           0,
           0,
           '已绑定银行卡的用户数（去重复）' as "统计项目",
           count(distinct b.userid) as "统计数据"
      from (select u.userid, u.expiredate
              from xxd_user u
             where u.regsource = '1') a
     inner join (select t.userid, t.addtime
                   from xxd_user_bank t
                  where t.banded = 1
                    and t.addtime >= to_date(L_startdate, 'YYYYMM')
                    and t.addtime <  to_date(L_enddate, 'YYYYMM')) b
        on a.userid = b.userid
     group by to_char(addtime, 'yyyymm');

  commit;

  --Web端  总绑卡数
  insert into TEMP_0601_QILIN
    select to_char(addtime, 'yyyymm') 月份,
           100, --100标记web端,101标记手机端
           0,
           0,
           0,
           '总绑卡数' as "统计项目",
           count(*) as "统计数据"
      from (select u.userid, u.expiredate
              from xxd_user u
             where u.regsource = '1') a
     inner join (select t.userid, t.addtime
                   from xxd_user_bank t
                  where t.banded = 1
                    and t.addtime >= to_date(L_startdate, 'YYYYMM')
                    and t.addtime <  to_date(L_enddate, 'YYYYMM')) b
        on a.userid = b.userid
     group by to_char(addtime, 'yyyymm');

  commit;

  --Web端  总交易单数
  insert into TEMP_0601_QILIN
    select to_char(rq, 'yyyymm') 月份,
           100, --100标记web端,101标记手机端
           0,
           0,
           0,
           '总交易单数' as "统计项目",
           count(*) as "统计数据"
      from (select userid from xxd_user t where t.regsource = '1') a
     inner join (select t.userid, trunc(g.addtime) rq, g.effectivemoney je
                   from xxd_borrow_tenderdetail g, xxd_borrow_tender t
                  where t.tenderid = g.tenderid
                    and g.addtime >= to_date(L_startdate, 'YYYYMM')
                    and g.addtime <  to_date(L_enddate, 'YYYYMM')
                    and t.status in ('1', '2')
                 --and t.schemeid = '0'
                 union all
                 select p.userid, trunc(p.addtime), p.collectamount
                   from xxd_trade_pack p
                  where p.addtime >= to_date(L_startdate, 'YYYYMM')
                    and p.addtime <  to_date(L_enddate, 'YYYYMM')) b
        on a.userid = b.userid
     group by to_char(rq, 'yyyymm');

  commit;

  --Web端 总交易金额
  insert into TEMP_0601_QILIN
    select to_char(rq, 'yyyymm') 月份,
           100, --100标记web端,101标记手机端
           0,
           0,
           0,
           '总交易金额' as "统计项目",
           sum(je) as "统计数据"
      from (select userid from xxd_user t where t.regsource = '1') a
     inner join (select t.userid, trunc(g.addtime) rq, g.effectivemoney je
                   from xxd_borrow_tenderdetail g, xxd_borrow_tender t
                  where t.tenderid = g.tenderid
                    and g.addtime >= to_date(L_startdate, 'YYYYMM')
                    and g.addtime <  to_date(L_enddate, 'YYYYMM')
                    and t.status in ('1', '2')
                 --and t.schemeid = '0'
                 union all
                 select p.userid, trunc(p.addtime), p.collectamount
                   from xxd_trade_pack p
                  where p.addtime >= to_date(L_startdate, 'YYYYMM')
                    and p.addtime <  to_date(L_enddate, 'YYYYMM')) b
        on a.userid = b.userid
     group by to_char(rq, 'yyyymm');

  commit;

  /*************手机端部分***********************/

  --手机端 注册用户数
  insert into TEMP_0601_QILIN
    select to_char(t.expiredate, 'yyyymm'),
           101, --100标记web端,101标记手机端
           0,
           0,
           0,
           '注册用户数' as "统计项目",
           count(*) as "统计数据"
      from xxd_user t
     where t.regsource in ('2', '6', '7')
       and t.expiredate >= to_date(L_startdate, 'YYYYMM')
       and t.expiredate <  to_date(L_enddate, 'YYYYMM')
     group by to_char(t.expiredate, 'yyyymm');

  commit;

  --手机端 已实名认证的用户数
  insert into TEMP_0601_QILIN
    select mon 月份,
           101, --100标记web端,101标记手机端
           0,
           0,
           0,
           '已实名认证的用户数' as "统计项目",
           count(distinct a.userid) as "统计数据"
      from (select u.userid
              from xxd_user u
             where u.regsource in ('2', '6', '7')) a
     inner join (select userid, to_char(createdate, 'yyyymm') mon
                   from xxd_realname_appro
                  where status = '1'
                    and createdate >= to_date(L_startdate, 'YYYYMM')
                    and createdate < to_date(L_enddate, 'YYYYMM')) b
        on a.userid = b.userid

     group by mon;

  commit;

  --手机端  已手机认证的用户数
  insert into TEMP_0601_QILIN
    select mon 月份,
           101, --100标记web端,101标记手机端
           0,
           0,
           0,
           '已手机认证的用户数' as "统计项目",
           count(distinct a.userid) as "统计数据"
      from (select u.userid
              from xxd_user u
             where u.regsource in ('2', '6', '7')) a
     inner join (select userid, to_char(createdate, 'yyyymm') mon
                   from xxd_mobile_appro
                  where status = '1'
                    and createdate >= to_date(L_startdate, 'YYYYMM')
                    and createdate <  to_date(L_enddate, 'YYYYMM')) b
        on a.userid = b.userid
     group by mon;

  --手机端 VIP认证的用户数
  insert into TEMP_0601_QILIN
    select mon 月份,
           101, --100标记web端,101标记手机端
           0,
           0,
           0,
           'VIP认证的用户数' as "统计项目",
           count(distinct a.userid) as "统计数据"
      from (select u.userid
              from xxd_user u
             where u.regsource in ('2', '6', '7')) a
     inner join (select userid, to_char(createdate, 'yyyymm') mon
                   from xxd_vip_appro
                  where status = '1'
                    and createdate >= to_date(L_startdate, 'YYYYMM')
                    and createdate <  to_date(L_enddate, 'YYYYMM')) b
        on a.userid = b.userid
     group by mon;

  commit;

  --手机端  邮箱绑定数
  insert into TEMP_0601_QILIN
    select mon 月份,
           101, --100标记web端,101标记手机端
           0,
           0,
           0,
           '邮箱绑定数' as "统计项目",
           count(distinct a.userid) as "统计数据"
      from (select u.userid
              from xxd_user u
             where u.regsource in ('2', '6', '7')) a
     inner join (select userid, to_char(createdate, 'yyyymm') mon
                   from xxd_email_appro
                  where status = '1'
                    and createdate >= to_date(L_startdate, 'YYYYMM')
                    and createdate <  to_date(L_enddate, 'YYYYMM')) b
        on a.userid = b.userid
     group by mon;

  commit;

  --手机端  已绑定银行卡的用户数（去重复）

  insert into TEMP_0601_QILIN
    select to_char(addtime, 'yyyymm') 月份,
           101, --100标记web端,101标记手机端
           0,
           0,
           0,
           '已绑定银行卡的用户数（去重复）' as "统计项目",
           count(distinct b.userid) as "统计数据"
      from (select u.userid, u.expiredate
              from xxd_user u
             where u.regsource in ('2', '6', '7')) a
     inner join (select t.userid, t.addtime
                   from xxd_user_bank t
                  where t.banded = 1
                    and t.addtime >= to_date(L_startdate, 'YYYYMM')
                    and t.addtime <  to_date(L_enddate, 'YYYYMM')) b
        on a.userid = b.userid
     group by to_char(addtime, 'yyyymm');

  commit;

  insert into TEMP_0601_QILIN
    select to_char(addtime, 'yyyymm') 月份,
           101, --100标记web端,101标记手机端
           0,
           0,
           0,
           '总绑卡数' as "统计项目",
           count(*) as "统计数据"
      from (select u.userid, u.expiredate
              from xxd_user u
             where u.regsource in ('2', '6', '7')) a
     inner join (select t.userid, t.addtime
                   from xxd_user_bank t
                  where t.banded = 1
                    and t.addtime >= to_date(L_startdate, 'YYYYMM')
                    and t.addtime <  to_date(L_enddate, 'YYYYMM')) b
        on a.userid = b.userid
     group by to_char(addtime, 'yyyymm');

  commit;

  --手机端  总交易单数
  insert into TEMP_0601_QILIN
    select to_char(rq, 'yyyymm') 月份,
           101, --100标记web端,101标记手机端
           0,
           0,
           0,
           '总交易单数' as "统计项目",
           count(*) as "统计数据"
      from (select userid
              from xxd_user t
             where t.regsource in ('2', '6', '7')) a
     inner join (select t.userid, trunc(g.addtime) rq, g.effectivemoney je
                   from xxd_borrow_tenderdetail g, xxd_borrow_tender t
                  where t.tenderid = g.tenderid
                    and g.addtime >= to_date(L_startdate, 'YYYYMM')
                    and g.addtime < to_date(L_enddate, 'YYYYMM')
                    and t.status in ('1', '2')
                 --and t.schemeid = '0'
                 union all
                 select p.userid, trunc(p.addtime), p.collectamount
                   from xxd_trade_pack p
                  where p.addtime >= to_date(L_startdate, 'YYYYMM')
                    and p.addtime < to_date(L_enddate, 'YYYYMM')) b
        on a.userid = b.userid
     group by to_char(rq, 'yyyymm');

  --手机端  总交易金额
  insert into TEMP_0601_QILIN
    select to_char(rq, 'yyyymm') 月份,
           101, --100标记web端,101标记手机端
           0,
           0,
           0,
           '总交易金额' as "统计项目",
           sum(je) as "统计数据"
      from (select userid
              from xxd_user t
             where t.regsource in ('2', '6', '7')) a
     inner join (select t.userid, trunc(g.addtime) rq, g.effectivemoney je
                   from xxd_borrow_tenderdetail g, xxd_borrow_tender t
                  where t.tenderid = g.tenderid
                    and g.addtime >= to_date(L_startdate, 'YYYYMM')
                    and g.addtime < to_date(L_enddate, 'YYYYMM')
                    and t.status in ('1', '2')
                 --and t.schemeid = '0'
                 union all
                 select p.userid, trunc(p.addtime), p.collectamount
                   from xxd_trade_pack p
                  where p.addtime >= to_date(L_startdate, 'YYYYMM')
                    and p.addtime < to_date(L_enddate, 'YYYYMM')) b
        on a.userid = b.userid
     group by to_char(rq, 'yyyymm');

  commit;
  /**--------------------------------以上每月总体统计结束-------------------------**/

  /*****************************************************************************************
                          part 2  散标出借部分
  *****************************************************************************************/

  begin

    loop
      --loop部分，统计上月贷出余额三组数据 （月初贷出存量单数，月初贷出存量用户数，月初贷出存量余额 type3=1）

      exit when V_startdate >= V_enddate;

      begin

        ---月初贷出存量单数
        insert into TEMP_0601_QILIN
          select to_char(V_startdate, 'YYYYMM'),
                 1,
                 0,
                 1,
                 0,
                 '月初贷出存量单数' as "统计项目",
                 count(distinct b.borrowid) "统计数据"
            from xxd_borrow_collection t, xxd_borrow b
           where t.addtime < V_startdate
             and nvl(t.repayyestime, sysdate) > V_startdate
             and t.borrowid = b.borrowid;

        ---月初贷出存量用户数
        insert into TEMP_0601_QILIN
          select to_char(V_startdate, 'YYYYMM'),
                 1,
                 0,
                 1,
                 0,
                 '月初贷出存量用户数' as "统计项目",
                 count(distinct b.userid) "统计数据"
            from xxd_borrow_collection t, xxd_borrow b
           where t.addtime < V_startdate
             and nvl(t.repayyestime, sysdate) > V_startdate
             and t.borrowid = b.borrowid;

        ----月初贷出存量余额
        insert into TEMP_0601_QILIN
          select to_char(V_startdate, 'YYYYMM'),
                 1,
                 0,
                 1,
                 0,
                 '月初贷出存量余额' as "统计项目",
                 sum(t.repayyesaccount) "统计数据"
            from xxd_borrow_collection t
           where t.addtime < V_startdate
             and nvl(t.repayyestime, sysdate) > V_startdate;

        /***********************以下部分按标的类型统计******************************************
         按标的类型分组统计
         TYPE2（1-新商贷，2-新网贷，3-新生贷，4-精英贷，5-新房贷，6-新车贷）
        **************************************************************************************/

        ----月初贷出存量单数
        insert into TEMP_0601_QILIN
          select to_char(V_startdate, 'YYYYMM'),
                 1,
                 decode(b.type, 9, 1, 12, 2, 8, 3, 11, 4, 10, 5, 14, 6) type2,
                 1,
                 0,
                 '月初贷出存量单数' as "统计项目",
                 count(distinct b.borrowid) "统计数据"
            from xxd_borrow_collection t, xxd_borrow b
           where t.addtime < V_startdate
             and nvl(t.repayyestime, sysdate) > V_startdate
             and t.borrowid = b.borrowid
             and b.type in (9, 12, 8, 11, 10, 14)
           group by b.type;

        ----月初贷出存量用户数
        insert into TEMP_0601_QILIN
          select to_char(V_startdate, 'YYYYMM'),
                 1,
                 decode(b.type, 9, 1, 12, 2, 8, 3, 11, 4, 10, 5, 14, 6) type2,
                 1,
                 0,
                 '月初贷出存量用户数' as "统计项目",
                 count(distinct b.userid) "统计数据"
            from xxd_borrow_collection t, xxd_borrow b
           where t.addtime < V_startdate
             and nvl(t.repayyestime, sysdate) > V_startdate
             and t.borrowid = b.borrowid
             and b.type in (9, 12, 8, 11, 10, 14)
           group by b.type;

        -----月初贷出存量余额
        insert into TEMP_0601_QILIN
          select to_char(V_startdate, 'YYYYMM'),
                 1,
                 decode(b.type, 9, 1, 12, 2, 8, 3, 11, 4, 10, 5, 14, 6) type2,
                 1,
                 0,
                 '月初贷出存量余额' as "统计项目",
                 sum(t.repayyesaccount) "统计数据"
            from xxd_borrow_collection t, xxd_borrow b
           where t.addtime < V_startdate
             and nvl(t.repayyestime, sysdate) > V_startdate
             and t.borrowid = b.borrowid
             and b.type in (9, 12, 8, 11, 10, 14)
           group by b.type;

        commit;

        ---插入 散标统计的  平均利率
        insert into TEMP_0601_QILIN
          select to_char(V_startdate, 'YYYYMM'),
                 1,
                 decode(b.type, 9, 1, 12, 2, 8, 3, 11, 4, 10, 5, 14, 6) 种类,
                 3,
                 case
                   when b.timelimit between 1 and 3 then
                    1
                   when b.timelimit between 4 and 7 then
                    2
                   when b.timelimit between 8 and 12 then
                    3
                   when b.timelimit between 13 and 24 then
                    4
                   else
                    5
                 end,
                 '平均利率' as "统计项目",
                 sum(b.account * b.apr / 100) / sum(b.account) as "统计数据"

            from xxd_borrow b
           where exists (select 1
                    from xxd_borrow_tender t
                   where t.addtime >= V_startdate
                     and t.addtime < add_months(V_startdate, 1)
                     and t.borrowid = b.borrowid
                     and t.status in (1, 2))
             and b.type in (9, 12, 8, 11, 10, 14)
           group by b.type,
                    case
                      when b.timelimit between 1 and 3 then
                       1
                      when b.timelimit between 4 and 7 then
                       2
                      when b.timelimit between 8 and 12 then
                       3
                      when b.timelimit between 13 and 24 then
                       4
                      else
                       5
                    end;
        commit;

        /************************插入新元宝一部分数据 （月初部分）**********************/

        -----------------------------总体月初统计------------------------------------------------
        --part1
        insert into TEMP_0601_QILIN
          select to_char(V_startdate, 'YYYYMM') "年月",
                 3,
                 0,
                 0,
                 0,
                 '仍在锁定期内的期数（月初数）' as "统计项目",
                 count(*) "统计数据"
            from xxd_optimize_userscheme a
            left join xxd_optimize_scheme b
              on a.schemeid = b.schemeid
           where a.addtime <= V_startdate
             and add_months(a.opendate, b.closeterm) > V_startdate
             and nvl(a.enddate, sysdate) > V_startdate;

        --part2
        insert into TEMP_0601_QILIN
          select to_char(V_startdate, 'YYYYMM') "年月",
                 3,
                 0,
                 0,
                 0,
                 '仍在锁定期内的金额（月初数）' as "统计项目",
                 sum(a.account) "统计数据"
            from xxd_optimize_userscheme a
            left join xxd_optimize_scheme b
              on a.schemeid = b.schemeid
           where a.addtime <= V_startdate
             and add_months(a.opendate, b.closeterm) > V_startdate
             and nvl(a.enddate, sysdate) > V_startdate;

        --part3
        insert into TEMP_0601_QILIN
          select to_char(V_startdate, 'YYYYMM') "年月",
                 3,
                 0,
                 0,
                 0,
                 '仍在锁定期内的用户数（月初数）' as "统计项目",
                 count(distinct(a.userid)) "统计数据"
            from xxd_optimize_userscheme a
            left join xxd_optimize_scheme b
              on a.schemeid = b.schemeid
           where a.addtime <= V_startdate
             and add_months(a.opendate, b.closeterm) > V_startdate
             and nvl(a.enddate, sysdate) > V_startdate;

        commit;

        -----------------------------明细月初统计-------------------------------------------------
        --part1
        insert into TEMP_0601_QILIN
          select to_char(V_startdate, 'YYYYMM') "年月",
                 3,
                 0,
                 0,
                 b.closeterm "封闭期限",
                 '仍在锁定期内的期数（月初数）' as "统计项目",
                 count(*) "统计数据"
            from xxd_optimize_userscheme a
            left join xxd_optimize_scheme b
              on a.schemeid = b.schemeid
           where a.addtime <= V_startdate
             and add_months(a.opendate, b.closeterm) > V_startdate
             and nvl(a.enddate, sysdate) > V_startdate
           group by b.closeterm;

        --part2
        insert into TEMP_0601_QILIN
          select to_char(V_startdate, 'YYYYMM') "年月",
                 3,
                 0,
                 0,
                 b.closeterm "封闭期限",
                 '仍在锁定期内的金额（月初数）' as "统计项目",
                 sum(a.account) "统计数据"
            from xxd_optimize_userscheme a
            left join xxd_optimize_scheme b
              on a.schemeid = b.schemeid
           where a.addtime <= V_startdate
             and add_months(a.opendate, b.closeterm) > V_startdate
             and nvl(a.enddate, sysdate) > V_startdate
           group by b.closeterm;

        --part3
        insert into TEMP_0601_QILIN
          select to_char(V_startdate, 'YYYYMM') "年月",
                 3,
                 0,
                 0,
                 b.closeterm "封闭期限",
                 '仍在锁定期内的用户数（月初数）' as "统计项目",
                 count(distinct(a.userid)) "统计数据"
            from xxd_optimize_userscheme a
            left join xxd_optimize_scheme b
              on a.schemeid = b.schemeid
           where a.addtime <= V_startdate
             and add_months(a.opendate, b.closeterm) > V_startdate
             and nvl(a.enddate, sysdate) > V_startdate
           group by b.closeterm;

      end;

      V_startdate := add_months(V_startdate, 1);

    end loop;

  end;

  commit;

  /************************以下数据分组统计***************************/

  ----以下部分，统计本月新增回款三组数据 （本月回款单数，本月回款用户数，本月回款金额, type3=2）

  -----本月回款单数
  insert into TEMP_0601_QILIN
    select to_char(repayyestime, 'YYYYMM'),
           1,
           0,
           2, --标记本月回款
           0,
           '本月回款单数' as "统计项目",
           count(distinct t.borrowid) as "统计数据"
      from xxd_borrow_collection t
     where t.repayyestime >= to_date(L_startdate, 'YYYYMM')
       and t.repayyestime <  to_date(L_enddate, 'YYYYMM')

     group by to_char(repayyestime, 'YYYYMM');

  ----本月回款用户数
  insert into TEMP_0601_QILIN
    select to_char(repayyestime, 'YYYYMM'),
           1,
           0,
           2,
           0,
           '本月回款用户数' as "统计项目",
           count(distinct b.userid) as "统计数据"
      from xxd_borrow_collection t, xxd_borrow b
     where t.repayyestime >= to_date(L_startdate, 'YYYYMM')
       and t.repayyestime <  to_date(L_enddate, 'YYYYMM')
       and t.borrowid = b.borrowid
     group by to_char(repayyestime, 'YYYYMM');

  ------本月回款金额
  insert into TEMP_0601_QILIN
    select to_char(repayyestime, 'YYYYMM'),
           1,
           0,
           2,
           0,
           '本月回款金额' as "统计项目",
           sum(t.repayyesaccount) as "统计数据"
      from xxd_borrow_collection t
     where t.repayyestime >= to_date(L_startdate, 'YYYYMM')
       and t.repayyestime <  to_date(L_enddate, 'YYYYMM')
     group by to_char(repayyestime, 'YYYYMM');

  commit;

  ----以下部分统计本月新增贷出三组数据（本月交易单数，本月交易用户数，本月交易金额 type3=3）


  ----本月交易单数
  insert into TEMP_0601_QILIN
    select to_char(t.addtime, 'YYYYMM'),
           1,
           0,
           3, --标记本月新增
           0,
           '本月交易单数' as "统计项目",
           count(distinct b.borrowid) as "统计数据"
      from xxd_borrow_tender t, xxd_borrow b
     where t.addtime >= to_date(L_startdate, 'YYYYMM')
       and t.addtime <  to_date(L_enddate, 'YYYYMM')
       and t.borrowid = b.borrowid
       and t.status in (1, 2)
     group by to_char(t.addtime, 'YYYYMM');

  ----本月交易用户数
  insert into TEMP_0601_QILIN
    select to_char(t.addtime, 'YYYYMM'),
           1,
           0,
           3,
           0,
           '本月交易用户数' as "统计项目",
           count(distinct b.userid) as "统计数据"
      from xxd_borrow_tender t, xxd_borrow b
     where t.addtime >= to_date(L_startdate, 'YYYYMM')
       and t.addtime <  to_date(L_enddate, 'YYYYMM')
       and t.borrowid = b.borrowid
       and t.status in (1, 2)
     group by to_char(t.addtime, 'YYYYMM');

  ------本月交易金额
  insert into TEMP_0601_QILIN
    select to_char(t.addtime, 'YYYYMM'),
           1,
           0,
           3,
           0,
           '本月交易金额' as "统计项目",
           sum(t.effectivemoney) as "统计数据"
      from xxd_borrow_tender t
     where t.addtime >= to_date(L_startdate, 'YYYYMM')
       and t.addtime <  to_date(L_enddate, 'YYYYMM')
       and t.status in (1, 2)
     group by to_char(t.addtime, 'YYYYMM');

  commit;

  /*******************************************************************************
   按标的类型统计
   type2（1-新商贷，2-新网贷，3-新生贷，4-精英贷，5-新房贷，6-新车贷）
   本月回款
  **********************************************************************************/

  ----本月回款单数 type3=2
  insert into TEMP_0601_QILIN
    select to_char(t.repayyestime, 'YYYYMM'),
           1,
           decode(b.type, 9, 1, 12, 2, 8, 3, 11, 4, 10, 5, 14, 6) type2,
           2,
           0,
           '本月回款单数' as "统计项目",
           count(distinct t.borrowid) as "统计数据"
      from xxd_borrow_collection t, xxd_borrow b
     where t.repayyestime >= to_date(L_startdate, 'YYYYMM')
       and t.repayyestime <  to_date(L_enddate, 'YYYYMM')
       and t.borrowid = b.borrowid
       and b.type in (9, 12, 8, 11, 10, 14)
     group by to_char(t.repayyestime, 'YYYYMM'), b.type;

  -- 本月回款用户数  type3=2
  insert into TEMP_0601_QILIN
    select to_char(t.repayyestime, 'YYYYMM'),
           1,
           decode(b.type, 9, 1, 12, 2, 8, 3, 11, 4, 10, 5, 14, 6) type2,
           2,
           0,
           '本月回款用户数' as "统计项目",
           count(distinct b.userid) as "统计数据"
      from xxd_borrow_collection t, xxd_borrow b
     where t.repayyestime >= to_date(L_startdate, 'YYYYMM')
       and t.repayyestime <  to_date(L_enddate, 'YYYYMM')
       and t.borrowid = b.borrowid
       and b.type in (9, 12, 8, 11, 10, 14)
     group by to_char(t.repayyestime, 'YYYYMM'), b.type;

  ----本月回款金额
  insert into TEMP_0601_QILIN
    select to_char(t.repayyestime, 'YYYYMM'),
           1,
           decode(b.type, 9, 1, 12, 2, 8, 3, 11, 4, 10, 5, 14, 6) type2,
           2,
           0,
           '本月回款金额' as "统计项目",
           sum(t.repayyesaccount) as "统计数据"
      from xxd_borrow_collection t, xxd_borrow b
     where t.repayyestime >= to_date(L_startdate, 'YYYYMM')
       and t.repayyestime <  to_date(L_enddate, 'YYYYMM')
       and t.borrowid = b.borrowid
       and b.type in (9, 12, 8, 11, 10, 14)
     group by to_char(t.repayyestime, 'YYYYMM'), b.type

    ;

  commit;

  /*******************************************************************************
   按标的类型统计
   type2（1-新商贷，2-新网贷，3-新生贷，4-精英贷，5-新房贷，6-新车贷）
   本月新增
  **********************************************************************************/

  /* 本月新增贷出在 标的类型下，没有按总体统计，只有期数统计，所以注释掉此部分
  --- 本月交易单数
  insert into TEMP_0601_QILIN
    select to_char(t.addtime, 'YYYYMM'),
           1,
           decode(b.type, 9, 1, 12, 2, 8, 3, 11, 4, 10, 5, 14, 6) type2,
           3,
           0,
           '本月交易单数' as "统计项目",
           count(distinct b.borrowid) as "统计数据"
      from xxd_borrow_tender t, xxd_borrow b
     where t.addtime >= to_date(L_startdate, 'YYYYMM')
       and t.addtime <  to_date(L_enddate, 'YYYYMM')
       and t.borrowid = b.borrowid
       and b.type in (9, 12, 8, 11, 10, 14)
       and t.status in (1, 2)
     group by to_char(t.addtime, 'YYYYMM'), b.type;

  -----本月交易用户数
  insert into TEMP_0601_QILIN
    select to_char(t.addtime, 'YYYYMM'),
           1,
           decode(b.type, 9, 1, 12, 2, 8, 3, 11, 4, 10, 5, 14, 6) type2,
           3,
           0,
           '本月交易用户数' as "统计项目",
           count(distinct b.userid) as "统计数据"
      from xxd_borrow_tender t, xxd_borrow b
     where t.addtime >= to_date(L_startdate, 'YYYYMM')
       and t.addtime <  to_date(L_enddate, 'YYYYMM')
       and t.borrowid = b.borrowid
       and b.type in (9, 12, 8, 11, 10, 14)
       and t.status in (1, 2)
     group by to_char(t.addtime, 'YYYYMM'), b.type;

  -----本月交易金额
  insert into TEMP_0601_QILIN
    select to_char(t.addtime, 'YYYYMM'),
           1,
           decode(b.type, 9, 1, 12, 2, 8, 3, 11, 4, 10, 5, 14, 6) type2,
           3,
           0,
           '本月交易金额' as "统计项目",
           sum(t.effectivemoney) as "统计数据"
      from xxd_borrow_tender t, xxd_borrow b
     where t.addtime >= to_date(L_startdate, 'YYYYMM')
       and t.addtime <  to_date(L_enddate, 'YYYYMM')
       and t.borrowid = b.borrowid
       and b.type in (9, 12, 8, 11, 10, 14)
       and t.status in (1, 2)
     group by to_char(t.addtime, 'YYYYMM'), b.type;

  commit;

  *****************************************************************/

  /***************************************************************************************
  按类型和期限统计
  type2  0-默认，1-新商贷，2-新网贷，3-新生贷，4-精英贷，5-新房贷，6-新车贷

  type4  0-默认，1-（1-3个月），2-（4-7个月），3-（8-12个月），4-（13-24个月），5-（24个月以上）
                 当新元宝时，锁定期存 3.6.12
   ****************************************************************************************/

  ---交易单数
  insert into TEMP_0601_QILIN
    select to_char(t.addtime, 'YYYYMM'),
           1,
           decode(b.type, 9, 1, 12, 2, 8, 3, 11, 4, 10, 5, 14, 6) 种类,

           3,

           case
             when b.timelimit between 1 and 3 then
              1
             when b.timelimit between 4 and 7 then
              2
             when b.timelimit between 8 and 12 then
              3
             when b.timelimit between 13 and 24 then
              4
             else
              5
           end timelimit,
           '交易单数' as "统计项目",
           count(distinct b.borrowid) as "统计数据"

      from xxd_borrow_tender t, xxd_borrow b
     where t.addtime >= to_date(L_startdate, 'YYYYMM')
       and t.addtime < to_date(L_enddate, 'YYYYMM')
       and t.borrowid = b.borrowid
       and b.type in (9, 12, 8, 11, 10, 14)
       and t.status in (1, 2)
     group by to_char(t.addtime, 'YYYYMM'),
              b.type,
              case
                when b.timelimit between 1 and 3 then
                 1
                when b.timelimit between 4 and 7 then
                 2
                when b.timelimit between 8 and 12 then
                 3
                when b.timelimit between 13 and 24 then
                 4
                else
                 5
              end;

  ----交易用户数
  insert into TEMP_0601_QILIN
    select to_char(t.addtime, 'YYYYMM'),
           1,
           decode(b.type, 9, 1, 12, 2, 8, 3, 11, 4, 10, 5, 14, 6) 种类,

           3,

           case
             when b.timelimit between 1 and 3 then
              1
             when b.timelimit between 4 and 7 then
              2
             when b.timelimit between 8 and 12 then
              3
             when b.timelimit between 13 and 24 then
              4
             else
              5
           end timelimit,
           '交易用户数' as "统计项目",
           count(distinct b.userid) as "统计数据"

      from xxd_borrow_tender t, xxd_borrow b
     where t.addtime >= to_date(L_startdate, 'YYYYMM')
       and t.addtime < to_date(L_enddate, 'YYYYMM')
       and t.borrowid = b.borrowid
       and b.type in (9, 12, 8, 11, 10, 14)
       and t.status in (1, 2)
     group by to_char(t.addtime, 'YYYYMM'),
              b.type,
              case
                when b.timelimit between 1 and 3 then
                 1
                when b.timelimit between 4 and 7 then
                 2
                when b.timelimit between 8 and 12 then
                 3
                when b.timelimit between 13 and 24 then
                 4
                else
                 5
              end;

  -----交易金额
  insert into TEMP_0601_QILIN
    select to_char(t.addtime, 'YYYYMM'),
           1,
           decode(b.type, 9, 1, 12, 2, 8, 3, 11, 4, 10, 5, 14, 6) 种类,

           3,

           case
             when b.timelimit between 1 and 3 then
              1
             when b.timelimit between 4 and 7 then
              2
             when b.timelimit between 8 and 12 then
              3
             when b.timelimit between 13 and 24 then
              4
             else
              5
           end timelimit,
           '交易金额' as "统计项目",
           sum(t.effectivemoney) as "统计数据"

      from xxd_borrow_tender t, xxd_borrow b
     where t.addtime >= to_date(L_startdate, 'YYYYMM')
       and t.addtime < to_date(L_enddate, 'YYYYMM')
       and t.borrowid = b.borrowid
       and b.type in (9, 12, 8, 11, 10, 14)
       and t.status in (1, 2)
     group by to_char(t.addtime, 'YYYYMM'),
              b.type,
              case
                when b.timelimit between 1 and 3 then
                 1
                when b.timelimit between 4 and 7 then
                 2
                when b.timelimit between 8 and 12 then
                 3
                when b.timelimit between 13 and 24 then
                 4
                else
                 5
              end;
  commit;

  /* ----平均利率,写入循环语句中  */

  /*******************************************************************************
           part 3  债券转让申请和交易数据汇总
  *******************************************************************************/
  ---总体
  ---当月交易单数
  insert into TEMP_0601_QILIN

    select to_char(a.addtime, 'yyyymm') 年月,
           2,
           0,
           0,
           0,
           '交易单数' as "统计项目",
           count(*) as "统计数据"
      from xxd_trade_pack a
      left join xxd_trade_request b
        on a.requestid = b.requestid
      left join xxd_borrow_tender c
        on b.tenderid = c.tenderid
      left join xxd_borrow d
        on c.borrowid = d.borrowid
     where a.addtime >= to_date(L_startdate, 'YYYYMM')
       and a.addtime < to_date(L_enddate, 'YYYYMM')
     group by to_char(a.addtime, 'yyyymm');

  ----当月交易金额
  insert into TEMP_0601_QILIN

    select to_char(a.addtime, 'yyyymm') 年月,
           2,
           0,
           0,
           0,
           '交易金额' as "统计项目",
           sum(b.amount) as "统计数据"
      from xxd_trade_pack a
      left join xxd_trade_request b
        on a.requestid = b.requestid
      left join xxd_borrow_tender c
        on b.tenderid = c.tenderid
      left join xxd_borrow d
        on c.borrowid = d.borrowid
     where a.addtime >= to_date(L_startdate, 'YYYYMM')
       and a.addtime < to_date(L_enddate, 'YYYYMM')
     group by to_char(a.addtime, 'yyyymm');

  commit;

  ----当月申请单数
  insert into TEMP_0601_QILIN
    select to_char(b.addtime, 'yyyymm') 年月,
           2,
           0,
           0,
           0,
           '申请单数' as "统计项目",
           count(distinct(b.requestid)) as "统计数据"
      from xxd_trade_request b ---sum(b.amount) 申请金额
      left join xxd_borrow_tender c
        on b.tenderid = c.tenderid
      left join xxd_borrow d
        on c.borrowid = d.borrowid
     where b.addtime >= to_date(L_startdate, 'YYYYMM')
       and b.addtime < to_date(L_enddate, 'YYYYMM')
     group by to_char(b.addtime, 'yyyymm');

  ----当月申请金额
  insert into TEMP_0601_QILIN
    select to_char(b.addtime, 'yyyymm') 年月,
           2,
           0,
           0,
           0,
           '申请金额' as "统计项目",
           sum(b.amount) as "统计数据"
      from xxd_trade_request b
      left join xxd_borrow_tender c
        on b.tenderid = c.tenderid
      left join xxd_borrow d
        on c.borrowid = d.borrowid
     where b.addtime >= to_date(L_startdate, 'YYYYMM')
       and b.addtime < to_date(L_enddate, 'YYYYMM')
     group by to_char(b.addtime, 'yyyymm');

  commit;

  /************************************************************************************
      债券转让交易数据 ,  按类型和期限统计
  type2  0-默认，1-新商贷，2-新网贷，3-新生贷，4-精英贷，5-新房贷，6-新车贷

  type4  0-默认，1-（1-3个月），2-（4-7个月），3-（8-12个月），4-（13-24个月），5-（24个月以上）
                 当新元宝时，锁定期存 3.6.12
  *************************************************************************************/
  ---part1
  insert into TEMP_0601_QILIN
    select to_char(a.addtime, 'yyyymm') 年月,
           2,
           decode(d.type, 9, 1, 12, 2, 8, 3, 11, 4) 标的类型,
           0,

           case
             when d.timelimit between 1 and 3 then
              1
             when d.timelimit between 4 and 7 then
              2
             when d.timelimit between 8 and 12 then
              3
             when d.timelimit between 13 and 24 then
              4
             else
              5
           end 期限,
           '交易单数' as "统计项目",
           count(*) as "统计数据"
      from xxd_trade_pack a
      left join xxd_trade_request b
        on a.requestid = b.requestid
      left join xxd_borrow_tender c
        on b.tenderid = c.tenderid
      left join xxd_borrow d
        on c.borrowid = d.borrowid
     where d.type in (8, 9, 11, 12)
       and a.addtime >= to_date(L_startdate, 'YYYYMM')
       and a.addtime < to_date(L_enddate, 'YYYYMM')
     group by to_char(a.addtime, 'yyyymm'),
              decode(d.type, 9, 1, 12, 2, 8, 3, 11, 4),
              case
                when d.timelimit between 1 and 3 then
                 1
                when d.timelimit between 4 and 7 then
                 2
                when d.timelimit between 8 and 12 then
                 3
                when d.timelimit between 13 and 24 then
                 4
                else
                 5
              end;

  ---part2
  insert into TEMP_0601_QILIN
    select to_char(a.addtime, 'yyyymm') 年月,
           2,
           decode(d.type, 9, 1, 12, 2, 8, 3, 11, 4) 标的类型,
           0,

           case
             when d.timelimit between 1 and 3 then
              1
             when d.timelimit between 4 and 7 then
              2
             when d.timelimit between 8 and 12 then
              3
             when d.timelimit between 13 and 24 then
              4
             else
              5
           end 期限,
           '交易金额' as "统计项目",
           sum(b.amount) as "统计数据"
      from xxd_trade_pack a
      left join xxd_trade_request b
        on a.requestid = b.requestid
      left join xxd_borrow_tender c
        on b.tenderid = c.tenderid
      left join xxd_borrow d
        on c.borrowid = d.borrowid
     where d.type in (8, 9, 11, 12)
       and a.addtime >= to_date(L_startdate, 'YYYYMM')
       and a.addtime < to_date(L_enddate, 'YYYYMM')
     group by to_char(a.addtime, 'yyyymm'),
              decode(d.type, 9, 1, 12, 2, 8, 3, 11, 4),
              case
                when d.timelimit between 1 and 3 then
                 1
                when d.timelimit between 4 and 7 then
                 2
                when d.timelimit between 8 and 12 then
                 3
                when d.timelimit between 13 and 24 then
                 4
                else
                 5
              end;

  ---part3
  insert into TEMP_0601_QILIN
    select to_char(a.addtime, 'yyyymm') 年月,
           2,
           decode(d.type, 9, 1, 12, 2, 8, 3, 11, 4) 标的类型,
           0,

           case
             when d.timelimit between 1 and 3 then
              1
             when d.timelimit between 4 and 7 then
              2
             when d.timelimit between 8 and 12 then
              3
             when d.timelimit between 13 and 24 then
              4
             else
              5
           end 期限,
           '交易平均利率' as "统计项目",
           sum(d.account * d.apr) / sum(d.account) as "统计数据"
      from xxd_trade_pack a
      left join xxd_trade_request b
        on a.requestid = b.requestid
      left join xxd_borrow_tender c
        on b.tenderid = c.tenderid
      left join xxd_borrow d
        on c.borrowid = d.borrowid
     where d.type in (8, 9, 11, 12)
       and a.addtime >= to_date(L_startdate, 'YYYYMM')
       and a.addtime < to_date(L_enddate, 'YYYYMM')
     group by to_char(a.addtime, 'yyyymm'),
              decode(d.type, 9, 1, 12, 2, 8, 3, 11, 4),
              case
                when d.timelimit between 1 and 3 then
                 1
                when d.timelimit between 4 and 7 then
                 2
                when d.timelimit between 8 and 12 then
                 3
                when d.timelimit between 13 and 24 then
                 4
                else
                 5
              end;
  commit;

  ---part4
  insert into TEMP_0601_QILIN
    select to_char(b.addtime, 'yyyymm') 年月,
           2,
           decode(d.type, 9, 1, 12, 2, 8, 3, 11, 4) 标的类型,
           0,
           case
             when d.timelimit between 1 and 3 then
              1
             when d.timelimit between 4 and 7 then
              2
             when d.timelimit between 8 and 12 then
              3
             when d.timelimit between 13 and 24 then
              4
             else
              5
           end 期限,
           '申请单数' as "统计项目",
           count(distinct(requestid)) as "统计数据"
      from xxd_trade_request b
      left join xxd_borrow_tender c
        on b.tenderid = c.tenderid
      left join xxd_borrow d
        on c.borrowid = d.borrowid
     where d.type in (8, 9, 11, 12)
       and b.addtime >= to_date(L_startdate, 'YYYYMM')
       and b.addtime < to_date(L_enddate, 'YYYYMM')
     group by to_char(b.addtime, 'yyyymm'),
              decode(d.type, 9, 1, 12, 2, 8, 3, 11, 4),
              case
                when d.timelimit between 1 and 3 then
                 1
                when d.timelimit between 4 and 7 then
                 2
                when d.timelimit between 8 and 12 then
                 3
                when d.timelimit between 13 and 24 then
                 4
                else
                 5
              end;

  -----part5
  insert into TEMP_0601_QILIN
    select to_char(b.addtime, 'yyyymm') 年月,
           2,
           decode(d.type, 9, 1, 12, 2, 8, 3, 11, 4) 标的类型,
           0,
           case
             when d.timelimit between 1 and 3 then
              1
             when d.timelimit between 4 and 7 then
              2
             when d.timelimit between 8 and 12 then
              3
             when d.timelimit between 13 and 24 then
              4
             else
              5
           end 期限,
           '申请金额' as "统计项目",
           sum(b.amount) as "统计数据"
      from xxd_trade_request b
      left join xxd_borrow_tender c
        on b.tenderid = c.tenderid
      left join xxd_borrow d
        on c.borrowid = d.borrowid
     where d.type in (8, 9, 11, 12)
       and b.addtime >= to_date(L_startdate, 'YYYYMM')
       and b.addtime < to_date(L_enddate, 'YYYYMM')
     group by to_char(b.addtime, 'yyyymm'),
              decode(d.type, 9, 1, 12, 2, 8, 3, 11, 4),
              case
                when d.timelimit between 1 and 3 then
                 1
                when d.timelimit between 4 and 7 then
                 2
                when d.timelimit between 8 and 12 then
                 3
                when d.timelimit between 13 and 24 then
                 4
                else
                 5
              end;

  -----part6
  insert into TEMP_0601_QILIN
    select to_char(b.addtime, 'yyyymm') 年月,
           2,
           decode(d.type, 9, 1, 12, 2, 8, 3, 11, 4) 标的类型,
           0,
           case
             when d.timelimit between 1 and 3 then
              1
             when d.timelimit between 4 and 7 then
              2
             when d.timelimit between 8 and 12 then
              3
             when d.timelimit between 13 and 24 then
              4
             else
              5
           end 期限,
           '申请平均利率' as "统计项目",
           sum(d.account * d.apr) / sum(d.account) as "统计数据"
      from xxd_trade_request b
      left join xxd_borrow_tender c
        on b.tenderid = c.tenderid
      left join xxd_borrow d
        on c.borrowid = d.borrowid
     where d.type in (8, 9, 11, 12)
       and b.addtime >= to_date(L_startdate, 'YYYYMM')
       and b.addtime < to_date(L_enddate, 'YYYYMM')
     group by to_char(b.addtime, 'yyyymm'),
              decode(d.type, 9, 1, 12, 2, 8, 3, 11, 4),
              case
                when d.timelimit between 1 and 3 then
                 1
                when d.timelimit between 4 and 7 then
                 2
                when d.timelimit between 8 and 12 then
                 3
                when d.timelimit between 13 and 24 then
                 4
                else
                 5
              end;
  commit;

  /***************************************************************************

          part 4   新元宝部分
  ****************************************************************************/

  --每月总体数据
  -------------------------------------月初部分写入循环语句中----------------------
  -------------------------------------退出部分-------------------------------------

  insert into TEMP_0601_QILIN
    select to_char(a.enddate, 'yyyymm') 年月,
           3,
           0,
           0,
           0,
           '本月退出产品个数' as "统计项目",
           count(*) as "统计数据"

      from xxd_optimize_userscheme a
      left join xxd_optimize_scheme b
        on a.schemeid = b.schemeid
     where to_char(a.enddate, 'yyyymm') is not null
       and a.enddate >= to_date(L_startdate, 'YYYYMM')
       and a.enddate < to_date(L_enddate, 'YYYYMM')
     group by to_char(a.enddate, 'yyyymm');

  -----
  insert into TEMP_0601_QILIN
    select to_char(a.enddate, 'yyyymm') 年月,
           3,
           0,
           0,
           0,
           '本月退出产品金额' as "统计项目",
           sum(a.account) as "统计数据"

      from xxd_optimize_userscheme a
      left join xxd_optimize_scheme b
        on a.schemeid = b.schemeid
     where to_char(a.enddate, 'yyyymm') is not null
       and a.enddate >= to_date(L_startdate, 'YYYYMM')
       and a.enddate <= to_date(L_enddate, 'YYYYMM')
     group by to_char(a.enddate, 'yyyymm');

  -----
  insert into TEMP_0601_QILIN
    select to_char(a.enddate, 'yyyymm') 年月,
           3,
           0,
           0,
           0,
           '本月退出涉及用户数' as "统计项目",
           count(distinct(a.userid)) as "统计数据"

      from xxd_optimize_userscheme a
      left join xxd_optimize_scheme b
        on a.schemeid = b.schemeid
     where to_char(a.enddate, 'yyyymm') is not null
       and a.enddate >= to_date(L_startdate, 'YYYYMM')
       and a.enddate < to_date(L_enddate, 'YYYYMM')
     group by to_char(a.enddate, 'yyyymm');

  -------------------------------------认购部分-------------------------------------
  insert into TEMP_0601_QILIN
    select to_char(a.addtime, 'yyyymm') 年月,
           3,
           0,
           0,
           0,
           '本月认购完成个数' as "统计项目",
           count(*) as "统计数据"

      from xxd_optimize_userscheme a
      left join xxd_optimize_scheme b
        on a.schemeid = b.schemeid
     where to_char(a.addtime, 'yyyymm') is not null
       and a.status in (1, 6, 7)
       and a.addtime >= to_date(L_startdate, 'YYYYMM')
       and a.addtime < to_date(L_enddate, 'YYYYMM')
     group by to_char(a.addtime, 'yyyymm');

  -------

  insert into TEMP_0601_QILIN
    select to_char(a.addtime, 'yyyymm') 年月,
           3,
           0,
           0,
           0,
           '本月认购完成金额' as "统计项目",
           sum(a.account) as "统计数据"

      from xxd_optimize_userscheme a
      left join xxd_optimize_scheme b
        on a.schemeid = b.schemeid
     where to_char(a.addtime, 'yyyymm') is not null
       and a.status in (1, 6, 7)
       and a.addtime >= to_date(L_startdate, 'YYYYMM')
       and a.addtime < to_date(L_enddate, 'YYYYMM')
     group by to_char(a.addtime, 'yyyymm');

  -----
  insert into TEMP_0601_QILIN
    select to_char(a.addtime, 'yyyymm') 年月,
           3,
           0,
           0,
           0,
           '本月认购完成涉及用户数' as "统计项目",
           count(distinct(a.userid)) as "统计数据"

      from xxd_optimize_userscheme a
      left join xxd_optimize_scheme b
        on a.schemeid = b.schemeid
     where to_char(a.addtime, 'yyyymm') is not null
       and a.status in (1, 6, 7)
       and a.addtime >= to_date(L_startdate, 'YYYYMM')
       and a.addtime < to_date(L_enddate, 'YYYYMM')
     group by to_char(a.addtime, 'yyyymm');

  ------
  insert into TEMP_0601_QILIN
    select to_char(a.addtime, 'yyyymm') 年月,
           3,
           0,
           0,
           0,
           '本月认购完成的平均年化收益' as "统计项目",
           sum(b.account * (b.minapr + b.maxapr) / 2) / sum(b.account) as "统计数据"

      from xxd_optimize_userscheme a
      left join xxd_optimize_scheme b
        on a.schemeid = b.schemeid
     where to_char(a.addtime, 'yyyymm') is not null
       and a.status in (1, 6, 7)
       and a.addtime >= to_date(L_startdate, 'YYYYMM')
       and a.addtime < to_date(L_enddate, 'YYYYMM')
     group by to_char(a.addtime, 'yyyymm');

  -----------
  -------------------------------------新增部分-------------------------------------
  insert into TEMP_0601_QILIN
    select to_char(a.presalebegin, 'yyyymm') 年月,
           3,
           0,
           0,
           0,
           '本月新增发行期数' as "统计项目",
           count(*) as "统计数据"
      from xxd_optimize_scheme a
     group by to_char(a.presalebegin, 'yyyymm'), a.closeterm
     order by to_char(a.presalebegin, 'yyyymm'), a.closeterm;
  -----
  insert into TEMP_0601_QILIN
    select to_char(a.presalebegin, 'yyyymm') 年月,
           3,
           0,
           0,
           0,
           '本月新增发行金额' as "统计项目",
           sum(account) as "统计数据"
      from xxd_optimize_scheme a
     where a.presalebegin >= to_date(L_startdate, 'YYYYMM')
       and a.presalebegin < to_date(L_enddate, 'YYYYMM')
     group by to_char(a.presalebegin, 'yyyymm');

  ------
  insert into TEMP_0601_QILIN
    select to_char(a.presalebegin, 'yyyymm') 年月,
           3,
           0,
           0,
           0,
           '本月新增发行的平均年化收益' as "统计项目",
           sum(account * (minapr + maxapr) / 2) / sum(account) as "统计数据"
      from xxd_optimize_scheme a
     where a.presalebegin >= to_date(L_startdate, 'YYYYMM')
       and a.presalebegin < to_date(L_enddate, 'YYYYMM')
     group by to_char(a.presalebegin, 'yyyymm');

  commit;

  --每月详细数据

  -------------------------------------月初部分写入循环语句中----------------------
  -------------------------------------退出部分-------------------------------------
  insert into TEMP_0601_QILIN
    select to_char(a.enddate, 'yyyymm') 年月,
           3,
           0,
           0,
           b.closeterm 封闭期限,
           '本月退出产品个数' as "统计项目",
           count(*) as "统计数据"

      from xxd_optimize_userscheme a
      left join xxd_optimize_scheme b
        on a.schemeid = b.schemeid
     where to_char(a.enddate, 'yyyymm') is not null
       and a.enddate >= to_date(L_startdate, 'YYYYMM')
       and a.enddate < to_date(L_enddate, 'YYYYMM')
     group by to_char(a.enddate, 'yyyymm'), b.closeterm
     order by to_char(a.enddate, 'yyyymm'), b.closeterm;

  -----
  insert into TEMP_0601_QILIN
    select to_char(a.enddate, 'yyyymm') 年月,
           3,
           0,
           0,
           b.closeterm 封闭期限,
           '本月退出产品金额' as "统计项目",
           sum(a.account) as "统计数据"

      from xxd_optimize_userscheme a
      left join xxd_optimize_scheme b
        on a.schemeid = b.schemeid
     where to_char(a.enddate, 'yyyymm') is not null
       and a.enddate >= to_date(L_startdate, 'YYYYMM')
       and a.enddate < to_date(L_enddate, 'YYYYMM')
     group by to_char(a.enddate, 'yyyymm'), b.closeterm
     order by to_char(a.enddate, 'yyyymm'), b.closeterm;

  -----
  insert into TEMP_0601_QILIN
    select to_char(a.enddate, 'yyyymm') 年月,
           3,
           0,
           0,
           b.closeterm 封闭期限,
           '本月退出涉及用户数' as "统计项目",
           count(distinct(a.userid)) as "统计数据"

      from xxd_optimize_userscheme a
      left join xxd_optimize_scheme b
        on a.schemeid = b.schemeid
     where to_char(a.enddate, 'yyyymm') is not null
       and a.enddate >= to_date(L_startdate, 'YYYYMM')
       and a.enddate < to_date(L_enddate, 'YYYYMM')
     group by to_char(a.enddate, 'yyyymm'), b.closeterm
     order by to_char(a.enddate, 'yyyymm'), b.closeterm;

  -------------------------------------认购部分-------------------------------------
  insert into TEMP_0601_QILIN
    select to_char(a.addtime, 'yyyymm') 年月,
           3,
           0,
           0,
           b.closeterm 封闭期限,
           '本月认购完成个数' as "统计项目",
           count(*) as "统计数据"

      from xxd_optimize_userscheme a
      left join xxd_optimize_scheme b
        on a.schemeid = b.schemeid
     where to_char(a.addtime, 'yyyymm') is not null
       and a.status in (1, 6, 7)
       and a.addtime >= to_date(L_startdate, 'YYYYMM')
       and a.addtime < to_date(L_enddate, 'YYYYMM')
     group by to_char(a.addtime, 'yyyymm'), b.closeterm
     order by to_char(a.addtime, 'yyyymm'), b.closeterm;

  -------

  insert into TEMP_0601_QILIN
    select to_char(a.addtime, 'yyyymm') 年月,
           3,
           0,
           0,
           b.closeterm 封闭期限,
           '本月认购完成金额' as "统计项目",
           sum(a.account) as "统计数据"

      from xxd_optimize_userscheme a
      left join xxd_optimize_scheme b
        on a.schemeid = b.schemeid
     where to_char(a.addtime, 'yyyymm') is not null
       and a.status in (1, 6, 7)
       and a.addtime >= to_date(L_startdate, 'YYYYMM')
       and a.addtime < to_date(L_enddate, 'YYYYMM')
     group by to_char(a.addtime, 'yyyymm'), b.closeterm
     order by to_char(a.addtime, 'yyyymm'), b.closeterm;

  -----
  insert into TEMP_0601_QILIN
    select to_char(a.addtime, 'yyyymm') 年月,
           3,
           0,
           0,
           b.closeterm 封闭期限,
           '本月认购完成涉及用户数' as "统计项目",
           count(distinct(a.userid)) as "统计数据"

      from xxd_optimize_userscheme a
      left join xxd_optimize_scheme b
        on a.schemeid = b.schemeid
     where to_char(a.addtime, 'yyyymm') is not null
       and a.status in (1, 6, 7)
       and a.addtime >= to_date(L_startdate, 'YYYYMM')
       and a.addtime < to_date(L_enddate, 'YYYYMM')
     group by to_char(a.addtime, 'yyyymm'), b.closeterm
     order by to_char(a.addtime, 'yyyymm'), b.closeterm;

  ------
  insert into TEMP_0601_QILIN
    select to_char(a.addtime, 'yyyymm') 年月,
           3,
           0,
           0,
           b.closeterm 封闭期限,
           '本月认购完成的平均年化收益' as "统计项目",
           sum(b.account * (b.minapr + b.maxapr) / 2) / sum(b.account) as "统计数据"

      from xxd_optimize_userscheme a
      left join xxd_optimize_scheme b
        on a.schemeid = b.schemeid
     where to_char(a.addtime, 'yyyymm') is not null
       and a.status in (1, 6, 7)
       and a.addtime >= to_date(L_startdate, 'YYYYMM')
       and a.addtime < to_date(L_enddate, 'YYYYMM')
     group by to_char(a.addtime, 'yyyymm'), b.closeterm
     order by to_char(a.addtime, 'yyyymm'), b.closeterm;

  -----------
  -------------------------------------新增部分-------------------------------------
  insert into TEMP_0601_QILIN
    select to_char(a.presalebegin, 'yyyymm') 年月,
           3,
           0,
           0,
           a.closeterm 封闭期限,
           '本月新增发行期数' as "统计项目",
           count(*) as "统计数据"
      from xxd_optimize_scheme a
     group by to_char(a.presalebegin, 'yyyymm'), a.closeterm
     order by to_char(a.presalebegin, 'yyyymm'), a.closeterm;
  -----
  insert into TEMP_0601_QILIN
    select to_char(a.presalebegin, 'yyyymm') 年月,
           3,
           0,
           0,
           a.closeterm 封闭期限,
           '本月新增发行金额' as "统计项目",
           sum(account) as "统计数据"
      from xxd_optimize_scheme a
     where a.presalebegin >= to_date(L_startdate, 'YYYYMM')
       and a.presalebegin < to_date(L_enddate, 'YYYYMM')
     group by to_char(a.presalebegin, 'yyyymm'), a.closeterm
     order by to_char(a.presalebegin, 'yyyymm'), a.closeterm;
  ------
  insert into TEMP_0601_QILIN
    select to_char(a.presalebegin, 'yyyymm') 年月,
           3,
           0,
           0,
           a.closeterm 封闭期限,
           '本月新增发行的平均年化收益' as "统计项目",
           sum(account * (minapr + maxapr) / 2) / sum(account) as "统计数据"
      from xxd_optimize_scheme a
     where a.presalebegin >= to_date(L_startdate, 'YYYYMM')
       and a.presalebegin < to_date(L_enddate, 'YYYYMM')
     group by to_char(a.presalebegin, 'yyyymm'), a.closeterm
     order by to_char(a.presalebegin, 'yyyymm'), a.closeterm;

  commit;

  /****************************************************************************************

               part 5  票小宝部分
  ***************************************************************************************/
  --part1
  insert into TEMP_0601_QILIN
    select to_char(addtime, 'yyyymm') 年月,
           4,
           0,
           0,
           0,
           '发行期数' as "统计项目",
           count(*) as "统计数据"
      from xxd_borrow
     where type = 13
       and addtime >= to_date(L_startdate, 'YYYYMM')
       and addtime < to_date(L_enddate, 'YYYYMM')
       and status in (2, 4, 5)
     group by to_char(addtime, 'yyyymm')
     order by to_char(addtime, 'yyyymm');

  ---part2
  insert into TEMP_0601_QILIN
    select to_char(addtime, 'yyyymm') 年月,
           4,
           0,
           0,
           0,
           '平均借款金额' as "统计项目",
           avg(account) as "统计数据"
      from xxd_borrow
     where type = 13
       and addtime >= to_date(L_startdate, 'YYYYMM')
       and addtime < to_date(L_enddate, 'YYYYMM')
       and status in (2, 4, 5)
     group by to_char(addtime, 'yyyymm')
     order by to_char(addtime, 'yyyymm');

  ----part3
  insert into TEMP_0601_QILIN
    select to_char(addtime, 'yyyymm') 年月,
           4,
           0,
           0,
           0,
           '平均年化收益' as "统计项目",
           sum(account * apr) / sum(account) as "统计数据"
      from xxd_borrow
     where type = 13
       and addtime >= to_date(L_startdate, 'YYYYMM')
       and addtime < to_date(L_enddate, 'YYYYMM')
       and status in (2, 4, 5)
     group by to_char(addtime, 'yyyymm')
     order by to_char(addtime, 'yyyymm');

  --- part4
  insert into TEMP_0601_QILIN
    select to_char(addtime, 'yyyymm') 年月,
           4,
           0,
           0,
           0,
           '平均投资周期' as "统计项目",
           avg(ROUND(TO_NUMBER(successtime - addtime) * 24 * 60 * 60)) || '秒' as "统计数据"
      from xxd_borrow
     where type = 13
       and addtime >= to_date(L_startdate, 'YYYYMM')
       and addtime < to_date(L_enddate, 'YYYYMM')
       and status in (2, 4, 5)
     group by to_char(addtime, 'yyyymm')
     order by to_char(addtime, 'yyyymm');

  -- 票小宝投标已经完成
  insert into TEMP_0601_QILIN
    select to_char(addtime, 'yyyymm') 年月,
           4,
           0,
           0,
           0,
           '投标已完成金额' as "统计项目",
           sum(account) as "统计数据"
      from xxd_borrow
     where type = 13
       and addtime >= to_date(L_startdate, 'YYYYMM')
       and addtime < to_date(L_enddate, 'YYYYMM')
       and status in (4, 5)
     group by to_char(addtime, 'yyyymm')
     order by to_char(addtime, 'yyyymm');

  -- 票小宝已还款期数和金额
  insert into TEMP_0601_QILIN
    select to_char(addtime, 'yyyymm') 年月,
           4,
           0,
           0,
           0,
           '还款完成期数' as "统计项目",
           count(*) as "统计数据"

      from xxd_borrow
     where type = 13
       and addtime >= to_date(L_startdate, 'YYYYMM')
       and addtime < to_date(L_enddate, 'YYYYMM')
       and status = 5
     group by to_char(addtime, 'yyyymm')
     order by to_char(addtime, 'yyyymm');

  --part7
  insert into TEMP_0601_QILIN
    select to_char(addtime, 'yyyymm') 年月,
           4,
           0,
           0,
           0,
           '还款完成金额' as "统计项目",
           sum(account) as "统计数据"

      from xxd_borrow
     where type = 13
       and addtime >= to_date(L_startdate, 'YYYYMM')
       and addtime < to_date(L_enddate, 'YYYYMM')
       and status = 5
     group by to_char(addtime, 'yyyymm')
     order by to_char(addtime, 'yyyymm');

  commit;

end SP_TEMP_QILIN;
/
